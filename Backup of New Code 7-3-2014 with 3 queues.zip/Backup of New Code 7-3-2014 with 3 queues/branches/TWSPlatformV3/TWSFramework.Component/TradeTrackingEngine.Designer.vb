﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TradeTrackingEngine
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(TradeTrackingEngine))
        Me.AxTws1 = New AxTWSLib.AxTws()
        Me.dgvTrades = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtMaxOpenOrders = New System.Windows.Forms.TextBox()
        Me.btnMaxOpenOrdersApply = New System.Windows.Forms.Button()
        Me.chkProfitDelta = New System.Windows.Forms.CheckBox()
        Me.Symbol = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Price = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Quantity = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Action = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CurrentPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProfitPercent = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PairSymbol = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PairPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PairQuantity = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PairAction = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PairCurrentPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PairProfitPercent = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalProfitPercent = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.AxTws1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvTrades, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'AxTws1
        '
        Me.AxTws1.Enabled = True
        Me.AxTws1.Location = New System.Drawing.Point(143, 182)
        Me.AxTws1.Name = "AxTws1"
        Me.AxTws1.OcxState = CType(resources.GetObject("AxTws1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxTws1.Size = New System.Drawing.Size(100, 50)
        Me.AxTws1.TabIndex = 14
        '
        'dgvTrades
        '
        Me.dgvTrades.AllowUserToAddRows = False
        Me.dgvTrades.AllowUserToDeleteRows = False
        Me.dgvTrades.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvTrades.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Symbol, Me.Price, Me.Quantity, Me.Action, Me.CurrentPrice, Me.ProfitPercent, Me.PairSymbol, Me.PairPrice, Me.PairQuantity, Me.PairAction, Me.PairCurrentPrice, Me.PairProfitPercent, Me.TotalProfitPercent})
        Me.dgvTrades.Location = New System.Drawing.Point(12, 12)
        Me.dgvTrades.Name = "dgvTrades"
        Me.dgvTrades.ReadOnly = True
        Me.dgvTrades.RowHeadersVisible = False
        Me.dgvTrades.Size = New System.Drawing.Size(1005, 507)
        Me.dgvTrades.TabIndex = 15
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(21, 529)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 13)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Max Open Orders"
        '
        'txtMaxOpenOrders
        '
        Me.txtMaxOpenOrders.Location = New System.Drawing.Point(116, 526)
        Me.txtMaxOpenOrders.Name = "txtMaxOpenOrders"
        Me.txtMaxOpenOrders.Size = New System.Drawing.Size(39, 20)
        Me.txtMaxOpenOrders.TabIndex = 17
        Me.txtMaxOpenOrders.Text = "1"
        '
        'btnMaxOpenOrdersApply
        '
        Me.btnMaxOpenOrdersApply.Location = New System.Drawing.Point(161, 525)
        Me.btnMaxOpenOrdersApply.Name = "btnMaxOpenOrdersApply"
        Me.btnMaxOpenOrdersApply.Size = New System.Drawing.Size(75, 23)
        Me.btnMaxOpenOrdersApply.TabIndex = 18
        Me.btnMaxOpenOrdersApply.Text = "Apply"
        Me.btnMaxOpenOrdersApply.UseVisualStyleBackColor = True
        '
        'chkProfitDelta
        '
        Me.chkProfitDelta.AutoSize = True
        Me.chkProfitDelta.Checked = True
        Me.chkProfitDelta.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkProfitDelta.Location = New System.Drawing.Point(242, 528)
        Me.chkProfitDelta.Name = "chkProfitDelta"
        Me.chkProfitDelta.Size = New System.Drawing.Size(204, 17)
        Me.chkProfitDelta.TabIndex = 19
        Me.chkProfitDelta.Text = "Maximum Profit Delta based decisions"
        Me.chkProfitDelta.UseVisualStyleBackColor = True
        '
        'Symbol
        '
        Me.Symbol.HeaderText = "Symbol"
        Me.Symbol.Name = "Symbol"
        Me.Symbol.ReadOnly = True
        Me.Symbol.Width = 75
        '
        'Price
        '
        Me.Price.HeaderText = "Price"
        Me.Price.MaxInputLength = 5
        Me.Price.Name = "Price"
        Me.Price.ReadOnly = True
        Me.Price.Width = 75
        '
        'Quantity
        '
        Me.Quantity.HeaderText = "Quantity"
        Me.Quantity.Name = "Quantity"
        Me.Quantity.ReadOnly = True
        Me.Quantity.Width = 75
        '
        'Action
        '
        Me.Action.HeaderText = "Action"
        Me.Action.Name = "Action"
        Me.Action.ReadOnly = True
        Me.Action.Width = 75
        '
        'CurrentPrice
        '
        Me.CurrentPrice.HeaderText = "CurrentPrice"
        Me.CurrentPrice.MaxInputLength = 5
        Me.CurrentPrice.Name = "CurrentPrice"
        Me.CurrentPrice.ReadOnly = True
        Me.CurrentPrice.Width = 75
        '
        'ProfitPercent
        '
        Me.ProfitPercent.HeaderText = "Profit %"
        Me.ProfitPercent.MaxInputLength = 5
        Me.ProfitPercent.Name = "ProfitPercent"
        Me.ProfitPercent.ReadOnly = True
        Me.ProfitPercent.Width = 75
        '
        'PairSymbol
        '
        Me.PairSymbol.HeaderText = "Pair Sym"
        Me.PairSymbol.Name = "PairSymbol"
        Me.PairSymbol.ReadOnly = True
        Me.PairSymbol.Width = 75
        '
        'PairPrice
        '
        Me.PairPrice.HeaderText = "Price"
        Me.PairPrice.MaxInputLength = 5
        Me.PairPrice.Name = "PairPrice"
        Me.PairPrice.ReadOnly = True
        Me.PairPrice.Width = 75
        '
        'PairQuantity
        '
        Me.PairQuantity.HeaderText = "Quantity"
        Me.PairQuantity.Name = "PairQuantity"
        Me.PairQuantity.ReadOnly = True
        Me.PairQuantity.Width = 75
        '
        'PairAction
        '
        Me.PairAction.HeaderText = "Action"
        Me.PairAction.Name = "PairAction"
        Me.PairAction.ReadOnly = True
        Me.PairAction.Width = 75
        '
        'PairCurrentPrice
        '
        Me.PairCurrentPrice.HeaderText = "CurrentPrice"
        Me.PairCurrentPrice.MaxInputLength = 5
        Me.PairCurrentPrice.Name = "PairCurrentPrice"
        Me.PairCurrentPrice.ReadOnly = True
        Me.PairCurrentPrice.Width = 75
        '
        'PairProfitPercent
        '
        Me.PairProfitPercent.HeaderText = "Profit %"
        Me.PairProfitPercent.MaxInputLength = 5
        Me.PairProfitPercent.Name = "PairProfitPercent"
        Me.PairProfitPercent.ReadOnly = True
        Me.PairProfitPercent.Width = 75
        '
        'TotalProfitPercent
        '
        Me.TotalProfitPercent.HeaderText = "Total Profit %"
        Me.TotalProfitPercent.MaxInputLength = 5
        Me.TotalProfitPercent.Name = "TotalProfitPercent"
        Me.TotalProfitPercent.ReadOnly = True
        '
        'TradeTrackingEngine
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1029, 552)
        Me.Controls.Add(Me.chkProfitDelta)
        Me.Controls.Add(Me.btnMaxOpenOrdersApply)
        Me.Controls.Add(Me.txtMaxOpenOrders)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dgvTrades)
        Me.Controls.Add(Me.AxTws1)
        Me.Name = "TradeTrackingEngine"
        Me.Text = "TradeTrackingEngine"
        CType(Me.AxTws1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvTrades, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents AxTws1 As AxTWSLib.AxTws
    Friend WithEvents dgvTrades As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtMaxOpenOrders As System.Windows.Forms.TextBox
    Friend WithEvents btnMaxOpenOrdersApply As System.Windows.Forms.Button
    Friend WithEvents chkProfitDelta As System.Windows.Forms.CheckBox
    Friend WithEvents Symbol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Price As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Quantity As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Action As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CurrentPrice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProfitPercent As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PairSymbol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PairPrice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PairQuantity As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PairAction As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PairCurrentPrice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PairProfitPercent As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TotalProfitPercent As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
