﻿Public Class PairSecurity
    Private _symbol As String
    Public Property Symbol() As String
        Get
            Return _symbol
        End Get
        Set(ByVal value As String)
            _symbol = value
        End Set
    End Property

    Private _initialChange As Double
    Public Property InitialChange() As Double
        Get
            Return _initialChange
        End Get
        Set(ByVal value As Double)
            _initialChange = value
        End Set
    End Property

    Private _currentChange As Double
    Public Property CurrentChange() As Double
        Get
            Return _currentChange
        End Get
        Set(ByVal value As Double)
            _currentChange = value
        End Set
    End Property

    Private _action As String
    Public Property Action() As String
        Get
            Return _action
        End Get
        Set(ByVal value As String)
            _action = value
        End Set
    End Property

    Private _currentPrice As Double
    Public Property CurrentPrice() As Double
        Get
            Return _currentPrice
        End Get
        Set(ByVal value As Double)
            _currentPrice = value
        End Set
    End Property




End Class
