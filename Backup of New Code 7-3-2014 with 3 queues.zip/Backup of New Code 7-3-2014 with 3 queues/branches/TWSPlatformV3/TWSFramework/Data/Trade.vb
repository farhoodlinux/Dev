﻿Imports TWSFramework.Enums

Namespace Data
    Public Class Trade
        Private _tradeId As Integer
        Public Property TradeId() As Integer
            Get
                Return _tradeId
            End Get
            Set(ByVal value As Integer)
                _tradeId = value
            End Set
        End Property

        Private _orderId As Integer
        Public Property OrderId() As Integer
            Get
                Return _orderId
            End Get
            Set(ByVal value As Integer)
                _orderId = value
            End Set
        End Property


        Private _symbol As String
        Public Property Symbol() As String
            Get
                Return _symbol
            End Get
            Set(ByVal value As String)
                _symbol = value
            End Set
        End Property

        Private _tradeType As Enums.TradeType
        Public Property TradeType() As Enums.TradeType
            Get
                Return _tradeType
            End Get
            Set(ByVal value As Enums.TradeType)
                _tradeType = value
            End Set
        End Property

        Private _tradePrice As Double
        Public Property TradePrice() As Double
            Get
                Return _tradePrice
            End Get
            Set(ByVal value As Double)
                _tradePrice = value
            End Set
        End Property

        Private _tradeVolume As Integer
        Public Property TradeVolume() As Integer
            Get
                Return _tradeVolume
            End Get
            Set(ByVal value As Integer)
                _tradeVolume = value
            End Set
        End Property

        Private _tradeTime As DateTime
        Public Property TradeTime() As DateTime
            Get
                Return _tradeTime
            End Get
            Set(ByVal value As DateTime)
                _tradeTime = value
            End Set
        End Property

        Private _tradeStatus As TradeStatus
        Public Property TradeStatus() As TradeStatus
            Get
                Return _tradeStatus
            End Get
            Set(ByVal value As TradeStatus)
                _tradeStatus = value
            End Set
        End Property

        Private _closePrice As Double
        Public Property ClosePrice() As Double
            Get
                Return _closePrice
            End Get
            Set(ByVal value As Double)
                _closePrice = value
            End Set
        End Property

        Private _closeTime As DateTime
        Public Property CloseTime() As DateTime
            Get
                Return _closeTime
            End Get
            Set(ByVal value As DateTime)
                _closeTime = value
            End Set
        End Property

        Private _profitAmount As Double
        Public Property ProfitAmount() As Double
            Get
                Return _profitAmount
            End Get
            Set(ByVal value As Double)
                _profitAmount = value
            End Set
        End Property

        Private _profitPercent As Double
        Public Property ProfitPercent() As Double
            Get
                Return _profitPercent
            End Get
            Set(ByVal value As Double)
                _profitPercent = value
            End Set
        End Property

        Private _pairedSecuritySymbol As String
        Public Property PairedSecuritySymbol() As String
            Get
                Return _pairedSecuritySymbol
            End Get
            Set(ByVal value As String)
                _pairedSecuritySymbol = value
            End Set
        End Property

        Private _pairedSecurityQuantity As Integer
        Public Property PairedSecurityQuantity() As Integer
            Get
                Return _pairedSecurityQuantity
            End Get
            Set(ByVal value As Integer)
                _pairedSecurityQuantity = value
            End Set
        End Property

        Private _pairedSecurityPrice As Double
        Public Property PairedSecurityPrice() As Double
            Get
                Return _pairedSecurityPrice
            End Get
            Set(ByVal value As Double)
                _pairedSecurityPrice = value
            End Set
        End Property

        Private _pairedSecurityClosePrice As Double
        Public Property PairedSecurityClosePrice() As Double
            Get
                Return _pairedSecurityClosePrice
            End Get
            Set(ByVal value As Double)
                _pairedSecurityClosePrice = value
            End Set
        End Property

        Private _pairedSecurityProfitAmount As Double
        Public Property PairedSecurityProfitAmount() As Double
            Get
                Return _pairedSecurityProfitAmount
            End Get
            Set(ByVal value As Double)
                _pairedSecurityProfitAmount = value
            End Set
        End Property

        Private _pairedSecurityProfitPercent As Double
        Public Property PairedSecurityProfitPercent() As Double
            Get
                Return _pairedSecurityProfitPercent
            End Get
            Set(ByVal value As Double)
                _pairedSecurityProfitPercent = value
            End Set
        End Property

        Private _totalProfitAmount As Double
        Public Property TotalProfitAmount() As Double
            Get
                Return _totalProfitAmount
            End Get
            Set(ByVal value As Double)
                _totalProfitAmount = value
            End Set
        End Property

        Private _totalProfitPercent As Double
        Public Property TotalProfitPercent() As Double
            Get
                Return _totalProfitPercent
            End Get
            Set(ByVal value As Double)
                _totalProfitPercent = value
            End Set
        End Property

    End Class
End Namespace