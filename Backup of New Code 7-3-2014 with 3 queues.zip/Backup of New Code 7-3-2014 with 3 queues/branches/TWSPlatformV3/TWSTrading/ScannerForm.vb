﻿Imports TWSFramework.Analysis
Imports AxTWSLib
Imports System.Collections.Generic
Imports TWSFramework.Components
Imports TWSFramework.Component
Imports TWSFramework.Data
Imports DataAccessLayer
Imports System.Threading
Imports System.Windows.Forms
Imports TWSFramework

Public Class ScannerForm
    Private Shared mut As New Mutex()
#Region "Form Properties"
    Private _appSettings As AppSettings

    Private ReadOnly Property NumberOfRows As Integer
        Get
            Return _appSettings.ScannerNumberOfRows
        End Get
    End Property

    Private ReadOnly Property APIHostAddress As String
        Get
            Return _appSettings.APIHostAddress
        End Get
    End Property

    Private ReadOnly Property APIPort As Integer
        Get
            Return _appSettings.APIPort
        End Get
    End Property

    Private ReadOnly Property MinCommon As Integer
        Get
            Return _appSettings.ScannerMinimumCommon
        End Get
    End Property

    Private ReadOnly Property SnapshotGapMilliseconds As Integer
        Get
            Return _appSettings.SnapshotGapMs
        End Get
    End Property

    Private _analyzer As IAnalysisEngine
    Private ReadOnly Property Analyzer As IAnalysisEngine
        Get
            Return AnalyzerEngine.Analyzer
        End Get
    End Property

    Private _analysisHistoryManager As AnalysisHistoryManager
    Private ReadOnly Property AnalysisHistoryManager As AnalysisHistoryManager
        Get
            If _analysisHistoryManager Is Nothing Then
                _analysisHistoryManager = New AnalysisHistoryManager()
            End If
            Return _analysisHistoryManager
        End Get
    End Property

    Private ReadOnly Property Trader As IntelligentTrader
        Get
            Return IntelligentTrader.Instance
        End Get
    End Property
#End Region

#Region "Buffer Objects"
    Private _scannerDataBuffer As Dictionary(Of Integer, List(Of TWSLib.IContractDetails))
    Private Property ScannerDataBuffer() As Dictionary(Of Integer, List(Of TWSLib.IContractDetails))
        Get
            Return _scannerDataBuffer
        End Get
        Set(ByVal value As Dictionary(Of Integer, List(Of TWSLib.IContractDetails)))
            _scannerDataBuffer = value
        End Set
    End Property

    Private _marketDataBuffer As Dictionary(Of Integer, TWSLib.IContract)
    Private Property MarketDataBuffer() As Dictionary(Of Integer, TWSLib.IContract)
        Get
            Return _marketDataBuffer
        End Get
        Set(ByVal value As Dictionary(Of Integer, TWSLib.IContract))
            _marketDataBuffer = value
        End Set
    End Property

    'Private _marketDataDoubleBuffer As Dictionary(Of Integer, Dictionary(Of Integer, TWSLib.IContract))
    'Private Property MarketDataDoubleBuffer() As Dictionary(Of Integer, Dictionary(Of Integer, TWSLib.IContract))
    '    Get
    '        Return _marketDataDoubleBuffer
    '    End Get

    '    Set(ByVal value As Dictionary(Of Integer, Dictionary(Of Integer, TWSLib.IContract)))
    '        _marketDataDoubleBuffer = value
    '    End Set
    'End Property

    'Private _marketDataGridBuffer As Dictionary(Of Integer, DataGridView)
    'Private Property MarketDataGridBuffer() As Dictionary(Of Integer, DataGridView)
    '    Get
    '        Return _marketDataGridBuffer
    '    End Get
    '    Set(ByVal value As Dictionary(Of Integer, DataGridView))
    '        _marketDataGridBuffer = value
    '    End Set
    'End Property

    Private _marketRequestIds As List(Of Integer)
    Private Property MarketRequestIds() As List(Of Integer)
        Get
            Return _marketRequestIds
        End Get
        Set(ByVal value As List(Of Integer))
            _marketRequestIds = value
        End Set
    End Property

    Private _startWindowForm As StartWindow
    Public Property StartWindowForm() As StartWindow
        Get
            Return _startWindowForm
        End Get
        Set(ByVal value As StartWindow)
            _startWindowForm = value
        End Set
    End Property

    Private _scannerSubscriptions As Dictionary(Of Integer, ScannerSubscription)
    Private Property ScannerSubscriptions() As Dictionary(Of Integer, ScannerSubscription)
        Get
            Return _scannerSubscriptions
        End Get
        Set(ByVal value As Dictionary(Of Integer, ScannerSubscription))
            _scannerSubscriptions = value
        End Set
    End Property

    Private _scannerStatusDictionary As Dictionary(Of Integer, Boolean)
    Public Property ScannerStatusDictionary() As Dictionary(Of Integer, Boolean)
        Get
            Return _scannerStatusDictionary
        End Get
        Set(ByVal value As Dictionary(Of Integer, Boolean))
            _scannerStatusDictionary = value
        End Set
    End Property

    Private _commonSymbols As List(Of String)
    Public Property CommonSymbols() As List(Of String)
        Get
            Return _commonSymbols
        End Get
        Set(ByVal value As List(Of String))
            _commonSymbols = value
        End Set
    End Property

    'Private _commonSymbolsSnapshots As List(Of List(Of String))
    'Public Property CommonSymbolsSnapshots() As List(Of List(Of String))
    '    Get
    '        Return _commonSymbolsSnapshots
    '    End Get
    '    Set(ByVal value As List(Of List(Of String)))
    '        _commonSymbolsSnapshots = value
    '    End Set
    'End Property


    Private _analysisRowsDictionary As Dictionary(Of String, Integer)
    Public Property AnalysisRowsDictionary() As Dictionary(Of String, Integer)
        Get
            Return _analysisRowsDictionary
        End Get
        Set(ByVal value As Dictionary(Of String, Integer))
            _analysisRowsDictionary = value
        End Set
    End Property

#End Region

#Region "Ax-Tws Event Handlers and Related Functions"

    Private Sub axTws1_scannerDataEx(ByVal sender As Object, ByVal e As AxTWSLib._DTwsEvents_scannerDataExEvent) Handles AxTws1.scannerDataEx
        Dim contractDetails = ScannerDataBuffer(e.reqId)
        contractDetails.Add(e.contractDetails)
    End Sub

    Private Sub axTws1_scannerDataEnd(ByVal sender As Object, ByVal e As AxTWSLib._DTwsEvents_scannerDataEndEvent) Handles AxTws1.scannerDataEnd
        'axTws1.cancelScannerSubscription(e.reqId)
        Dim contractDetails = ScannerDataBuffer(e.reqId)
        ScannerDataBuffer(e.reqId) = New List(Of TWSLib.IContractDetails)
        Dim subscription = ScannerSubscriptions(e.reqId)
        mut.WaitOne()
        Dim gridColumn = dgvScannerData.Columns(subscription.ScannerName.Replace(" ", ""))

        For rowIndex = 0 To contractDetails.Count - 1
            Dim value = DirectCast(DirectCast(contractDetails(rowIndex), Object), Object).summary.symbol
            dgvScannerData.Rows(rowIndex).Cells(gridColumn.Index).Value = value.ToString()
        Next
        ScannerStatusDictionary(e.reqId) = True
        FindCommons()
        mut.ReleaseMutex()
        'System.Threading.Thread.Sleep(1000)
        'SetUpScanner(axTws1, subscription, e.reqId)
    End Sub

    Private Sub axTws1_tickPrice(sender As System.Object, e As AxTWSLib._DTwsEvents_tickPriceEvent) Handles AxTws1.tickPrice
        'If e.id > 100 Then
        If e.id = "SPY".GetHashCode() Then
            SpecialTradeOccurred("SPY", e)
            Return
        End If
        If e.id = "QQQ".GetHashCode() Then
            SpecialTradeOccurred("QQQ", e)
            Return
        End If
        HandleCommonMarketDataPrice(e)

        'End If
    End Sub

    Private Sub axTws1_tickSize(sender As System.Object, e As AxTWSLib._DTwsEvents_tickSizeEvent) Handles AxTws1.tickSize
        If e.id = "SPY".GetHashCode() Or e.id = "QQQ".GetHashCode() Then
            Return
        End If
        HandleCommonMarketDataSize(e)
    End Sub

    Private Sub AxTws1_errMsg(ByVal sender As System.Object, ByVal e As AxTWSLib._DTwsEvents_errMsgEvent) Handles AxTws1.errMsg
        'StartWindowForm.ErrorMsg.Text = StartWindowForm.ErrorMsg.Text & e.errorCode & ":" & e.errorMsg
        txtDebug.Text = txtDebug.Text & e.errorCode & ":" & e.errorMsg & vbCrLf
        txtDebug.ScrollToCaret()
    End Sub

#End Region

#Region "Form Event Handlers"
    Public Sub New()
        ' This call is required by the designer.
        InitializeComponent()
        CheckForIllegalCrossThreadCalls = False
        AddHandler Analyzer.AnalysisReady, AddressOf Analyzer_AnalysisReady
    End Sub

    Private Sub ScannerForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        StopEverything()
    End Sub

    Private Sub BtnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnStart.Click
        IntelligentTrader.Instance.TradingEngine = New TradingEngine()
        Start()
    End Sub

    Private Sub btnStartMock_Click(sender As System.Object, e As System.EventArgs) Handles btnStartMock.Click
        Start()
    End Sub

    Private Sub btnTradeTracker_Click(sender As System.Object, e As System.EventArgs)
        CType(TradeTrackingEngine.Instance, Form).Show()
    End Sub

    Private Sub Start()
        Dim dataLayerObject As New DataLayer()
        _appSettings = dataLayerObject.GetAppSettings(False)
        Dim scanners As List(Of ScannerSubscription)
        ScannerSubscriptions = New Dictionary(Of Integer, ScannerSubscription)
        ScannerDataBuffer = New Dictionary(Of Integer, List(Of TWSLib.IContractDetails))
        MarketDataBuffer = New Dictionary(Of Integer, TWSLib.IContract)
        'MarketDataGridBuffer = New Dictionary(Of Integer, DataGridView)
        'MarketDataDoubleBuffer = New Dictionary(Of Integer, Dictionary(Of Integer, TWSLib.IContract))
        ScannerStatusDictionary = New Dictionary(Of Integer, Boolean)
        AnalysisRowsDictionary = New Dictionary(Of String, Integer)
        CommonSymbols = New List(Of String)
        dgvScannerData.Rows.Clear()
        dgvScannerData.Columns.Clear()
        scanners = dataLayerObject.GetScannersFromDatabase(True)
        AxTws1.connect(APIHostAddress, APIPort, 2)
        Dim index As Integer = 0
        For Each scanner In scanners
            dgvScannerData.Columns.Add(scanner.ScannerName.Replace(" ", ""), scanner.ScannerName)
            scanner.NumberOfRows = NumberOfRows
            ScannerSubscriptions.Add(scanner.RequestID, scanner)
            ScannerDataBuffer.Add(scanner.RequestID, New List(Of TWSLib.IContractDetails))
            SetUpScanner(AxTws1, scanner, scanner.RequestID)
            ScannerStatusDictionary.Add(scanner.RequestID, False)
            'SetUpMarketDataGrid(index, scanner.RequestID)
            index = index + 1
        Next

        dgvScannerData.Rows.Add(NumberOfRows)
        BtnStart.Enabled = False
        btnStartMock.Enabled = False
        BtnStop.Enabled = True

        Dim timer1 = New System.Windows.Forms.Timer()
        timer1.Interval = SnapshotGapMilliseconds
        AddHandler timer1.Tick, AddressOf Me.timer_Tick
        timer1.Start()
        Trader.StartTrader()
        dgvConstantSymbols.Rows.Add("QQQ", "", "", "", "")
        dgvConstantSymbols.Rows.Add("SPY", "", "", "", "")
        SetUpMarketData("QQQ", "QQQ".GetHashCode())
        SetUpMarketData("SPY", "SPY".GetHashCode())
    End Sub

    Private Sub SpecialTradeOccurred(ByVal symbol As String, ByVal tickPrice As _DTwsEvents_tickPriceEvent)

        If (Not IntelligentTrader.Instance.MarketData.ContainsKey(symbol)) Then
            IntelligentTrader.Instance.MarketData.Add(symbol, New MarketDataItem)
            IntelligentTrader.Instance.MarketData(symbol).Symbol = symbol
        End If

        For Each row As DataGridViewRow In dgvConstantSymbols.Rows
            If row.Cells("colConstantSymbol").Value.ToString().Equals(symbol, StringComparison.OrdinalIgnoreCase) Then
                Select Case tickPrice.tickType
                    Case TWSFramework.Enums.PriceTickType.Bid
                        row.Cells("colConstantBid").Value = tickPrice.price.ToString("F")
                        row.Cells("colConstantBid").Tag = tickPrice.price
                        IntelligentTrader.Instance.MarketData(symbol).Bid = tickPrice.price
                    Case TWSFramework.Enums.PriceTickType.Ask
                        row.Cells("colConstantAsk").Value = tickPrice.price.ToString("F")
                        row.Cells("colConstantAsk").Tag = tickPrice.price
                        IntelligentTrader.Instance.MarketData(symbol).Ask = tickPrice.price
                    Case TWSFramework.Enums.PriceTickType.Last
                        row.Cells("colConstantLast").Value = tickPrice.price.ToString("F")
                        row.Cells("colConstantLast").Tag = tickPrice.price
                        row.Cells("colConstantAsk").Style.BackColor = Drawing.Color.White
                        row.Cells("colConstantBid").Style.BackColor = Drawing.Color.White
                        IntelligentTrader.Instance.MarketData(symbol).Last = tickPrice.price
                        If Not row.Cells("colConstantBid").Tag Is Nothing Then
                            Dim bidPrice As Double = CType(row.Cells("colConstantBid").Tag, Double)
                            If tickPrice.price = bidPrice Then
                                row.Cells("colConstantBid").Style.BackColor = Drawing.Color.LightGreen
                            End If
                        End If
                        If Not row.Cells("colConstantAsk").Tag Is Nothing Then
                            Dim askPrice As Double = CType(row.Cells("colConstantAsk").Tag, Double)
                            If tickPrice.price = askPrice Then
                                row.Cells("colConstantAsk").Style.BackColor = Drawing.Color.LightGreen
                            End If
                        End If


                        If Not row.Cells("colConstantChange").Tag Is Nothing Then
                            Dim closePrice = CType(row.Cells("colConstantChange").Tag, Double)
                            Dim change As Double = (((tickPrice.price - closePrice) / closePrice))
                            row.Cells("colConstantChange").Value = change.ToString("P")
                            If symbol = "SPY" Then
                                IntelligentTrader.Instance.SpyChange = change
                            End If
                            If symbol = "QQQ" Then
                                IntelligentTrader.Instance.QqqChange = change
                            End If
                            IntelligentTrader.Instance.MarketData(symbol).Change = change
                        End If

                    Case TWSFramework.Enums.PriceTickType.Close
                        row.Cells("colConstantChange").Tag = tickPrice.price
                        IntelligentTrader.Instance.MarketData(symbol).Close = tickPrice.price
                End Select
                Exit For
            End If
        Next
    End Sub

    Private Sub SetMarketDataGrid()
        CancelCommonMarketData()
        MarketDataBuffer = New Dictionary(Of Integer, TWSLib.IContract)
        AnalysisRowsDictionary = New Dictionary(Of String, Integer)
        dgvMarketData.Rows.Clear()
        dgvMarketData.Rows.Add(CommonSymbols.Count)
        dgvPercentages.Rows.Clear()
        dgvPercentages.Rows.Add(CommonSymbols.Count)
        Dim reqId As Integer = 1
        For Each sym In CommonSymbols
            dgvMarketData.Rows(reqId - 1).Cells("Symbol").Value = sym
            dgvPercentages.Rows(reqId - 1).Cells("grdPercentagesClmSymbol").Value = sym
            AnalysisRowsDictionary.Add(sym, reqId - 1)
            SetUpMarketData(sym, reqId)
            reqId = reqId + 1
        Next

        For Each sym In CommonSymbols
            Analyzer.RaiseEvents(sym)
        Next

        CommonSymbols = New List(Of String)

    End Sub

    Private Sub timer_Tick(ByVal sender As Object, ByVal e As EventArgs)
        Dim timer = CType(sender, System.Windows.Forms.Timer)
        timer.Stop()
        If BtnStart.Enabled Then
            timer.Dispose()
            Return
        End If
        If CommonSymbols.Count < 1 Then
            timer.Start()
            Return
        End If
        mut.WaitOne()
        SetMarketDataGrid()
        mut.ReleaseMutex()
        timer.Start()
    End Sub

    Private Sub BtnStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnStop.Click
        StopEverything()
        BtnStart.Enabled = True
        btnStartMock.Enabled = True
        BtnStop.Enabled = False
    End Sub
#End Region

#Region "Custom Event Handlers"
    Private Sub Analyzer_AnalysisReady(ByVal symbol As String, ByVal size As Integer, ByVal result As MarketAnalysisResult)
        'For Each row As DataGridViewRow In dgvPercentages.Rows
        '    If row.Cells("grdPercentagesClmSymbol").Value.ToString().Equals(symbol, StringComparison.OrdinalIgnoreCase) Then
        '        InsertAnalysisValues(row, size, result)
        '        Exit For
        '    End If
        'Next
        AnalysisHistoryManager.Add(symbol, result)
        'If symbol = "AONE" Then
        '    If Not aOneGraph.LineExists(1) Then
        '        aOneGraph.AddLine(1, Drawing.Color.Red)
        '    End If
        '    aOneGraph.Push(CType(Math.Floor(result.AverageTimeGap.TotalMilliseconds), Integer), 1)
        '    aOneGraph.UpdateGraph()
        'End If
        If Not AnalysisRowsDictionary.ContainsKey(symbol) Then
            Return
        End If
        InsertAnalysisValues(dgvPercentages.Rows(AnalysisRowsDictionary(symbol)), size, result)
    End Sub

    Private Sub InsertAnalysisValues(ByVal row As DataGridViewRow, ByVal size As Integer, ByVal result As MarketAnalysisResult)
        Select Case size
            Case 25
                row.Cells("grdPercentagesClm10BelowBid").Value = result.BelowBid
                row.Cells("grdPercentagesClm10AtBid").Value = result.AtBid
                row.Cells("grdPercentagesClm10BidToAsk").Value = result.BidToAsk
                row.Cells("grdPercentagesClm10AtAsk").Value = result.AtAsk
                row.Cells("grdPercentagesClm10AboveAsk").Value = result.AboveAsk
                row.Cells("grdPercentagesClm10AvgTime").Value = result.AverageTimeGap.TotalMilliseconds.ToString()
                row.Cells("grdPercentagesClm10AvgPrice").Value = result.AveragePrice.ToString()
                row.Cells("grdPercentagesClm10AvgVolume").Value = result.AverageVolume.ToString()
            Case 100
                row.Cells("grdPercentagesClm100BelowBid").Value = result.BelowBid
                row.Cells("grdPercentagesClm100AtBid").Value = result.AtBid
                row.Cells("grdPercentagesClm100BidToAsk").Value = result.BidToAsk
                row.Cells("grdPercentagesClm100AtAsk").Value = result.AtAsk
                row.Cells("grdPercentagesClm100AboveAsk").Value = result.AboveAsk
                row.Cells("grdPercentagesClm100AvgTime").Value = result.AverageTimeGap.TotalMilliseconds.ToString()
                row.Cells("grdPercentagesClm100AvgPrice").Value = result.AveragePrice.ToString()
                row.Cells("grdPercentagesClm100AvgVolume").Value = result.AverageVolume.ToString()
                'Case 500
                '    row.Cells("grdPercentagesClm500BelowBid").Value = result.BelowBid
                '    row.Cells("grdPercentagesClm500AtBid").Value = result.AtBid
                '    row.Cells("grdPercentagesClm500BidToAsk").Value = result.BidToAsk
                '    row.Cells("grdPercentagesClm500AtAsk").Value = result.AtAsk
                '    row.Cells("grdPercentagesClm500AboveAsk").Value = result.AboveAsk
                '    row.Cells("grdPercentagesClm500AvgTime").Value = result.AverageTimeGap.TotalMilliseconds.ToString()
        End Select
    End Sub
#End Region

#Region "Functions"
    Private Sub SetUpScanner(ByVal axTws As AxTWSLib.AxTws, ByVal scannerSubscription As ScannerSubscription, ByVal requestId As Integer)
        Dim scanner As TWSLib.IScannerSubscription = axTws.createScannerSubscription()
        'Convert "our" scanner subscription to the IScannerScubsciption that TWS API can understand
        scannerSubscription.RevertToTWSObject(scanner)
        axTws.reqScannerSubscriptionEx(requestId, scanner)
    End Sub

    Private Sub FindCommons()
        dgvCommon.Rows.Clear()
        Dim valDict = New Dictionary(Of String, Integer)
        For Each column As DataGridViewColumn In dgvScannerData.Columns
            For Each row As DataGridViewRow In dgvScannerData.Rows
                If Not row.Cells(column.Index).Value Is Nothing Then
                    Dim symbol = row.Cells(column.Index).Value.ToString().ToUpper()
                    If (valDict.ContainsKey(symbol)) Then
                        valDict(symbol) = valDict(symbol) + 1
                    Else
                        valDict.Add(symbol, 1)
                    End If
                End If
            Next
        Next
        'Dim commons = New List(Of String)
        For Each key In valDict.Keys
            If valDict(key) >= MinCommon Then
                If Not CommonSymbols.Contains(key) Then
                    CommonSymbols.Add(key)
                End If
                dgvCommon.Rows.Add(key)
            End If
        Next
        'CancelCommonMarketData()
        'MarketDataBuffer = New Dictionary(Of Integer, TWSLib.IContract)
        'Dim reqId As Integer = 100
        'For Each sym In commons
        '    dgvCommon.Rows.Add(sym)
        '    SetUpMarketData(sym, reqId)
        '    reqId = reqId + 1
        'Next
    End Sub

    Private Sub SetUpMarketData(ByVal symbol As String, ByVal requestId As Integer)
        Dim contract As TWSFramework.Data.Contract
        contract = New TWSFramework.Data.Contract()
        contract.LocalSymbol = symbol
        contract.SecType = TWSFramework.Enums.SecurityType.Stk
        contract.Exchange = "SMART"
        contract.Currency = "USD"

        Dim genericTicks = "100,101,104,106,165,221,225,236"

        Dim twsContract As TWSLib.IContract = AxTws1.createContract()

        contract.RevertToTWSObject(twsContract)
        If symbol = "QQQ" Or symbol = "SPY" Then
        Else
            MarketDataBuffer.Add(requestId, twsContract)
        End If
        AxTws1.reqMktDataEx(requestId, twsContract, genericTicks, False)

    End Sub

    Private Sub HandleCommonMarketDataPrice(ByVal e As AxTWSLib._DTwsEvents_tickPriceEvent)
        mut.WaitOne()
        If Not MarketDataBuffer.ContainsKey(e.id) Then
            AxTws1.cancelMktData(e.id)
            Return
        End If
        Dim tickPriceDataItem As TickPriceData = New TickPriceData()

        tickPriceDataItem.LoadDataFromObject(e)

        Dim contract = MarketDataBuffer(tickPriceDataItem.RequestID)
        If tickPriceDataItem.TickType = TWSFramework.Enums.PriceTickType.Bid Then
            Analyzer.SetBid(contract.localSymbol, tickPriceDataItem.Price)
        End If

        If tickPriceDataItem.TickType = TWSFramework.Enums.PriceTickType.Ask Then
            Analyzer.SetAsk(contract.localSymbol, tickPriceDataItem.Price)
        End If

        If tickPriceDataItem.TickType = TWSFramework.Enums.PriceTickType.Last Then
            Analyzer.SetLast(contract.localSymbol, tickPriceDataItem.Price)
        End If

        If (Not IntelligentTrader.Instance.MarketData.ContainsKey(contract.localSymbol)) Then
            IntelligentTrader.Instance.MarketData.Add(contract.localSymbol, New MarketDataItem)
            IntelligentTrader.Instance.MarketData(contract.localSymbol).Symbol = contract.localSymbol
        End If

        'Optimization Required Here to store values in tags.
        For Each row As DataGridViewRow In dgvMarketData.Rows
            If row.Cells("Symbol").Value.ToString().Equals(contract.localSymbol, StringComparison.OrdinalIgnoreCase) Then
                Select Case e.tickType
                    Case TWSFramework.Enums.PriceTickType.Bid
                        row.Cells("Bid").Value = tickPriceDataItem.Price.ToString("F")
                        row.Cells("Bid").Tag = tickPriceDataItem.Price
                        IntelligentTrader.Instance.MarketData(contract.localSymbol).Bid = tickPriceDataItem.Price
                    Case TWSFramework.Enums.PriceTickType.Ask
                        row.Cells("Ask").Value = tickPriceDataItem.Price.ToString("F")
                        row.Cells("Ask").Tag = tickPriceDataItem.Price
                        IntelligentTrader.Instance.MarketData(contract.localSymbol).Ask = tickPriceDataItem.Price
                    Case TWSFramework.Enums.PriceTickType.Last
                        row.Cells("Last").Value = tickPriceDataItem.Price.ToString("F")
                        row.Cells("Last").Tag = tickPriceDataItem.Price
                        row.Cells("Ask").Style.BackColor = Drawing.Color.White
                        row.Cells("Bid").Style.BackColor = Drawing.Color.White
                        If Not row.Cells("Bid").Tag Is Nothing Then
                            Dim bidPrice As Double = CType(row.Cells("Bid").Tag, Double)
                            If tickPriceDataItem.Price = bidPrice Then
                                row.Cells("Bid").Style.BackColor = Drawing.Color.LightGreen
                            End If
                        End If
                        If Not row.Cells("Ask").Tag Is Nothing Then
                            Dim askPrice As Double = CType(row.Cells("Ask").Tag, Double)
                            If tickPriceDataItem.Price = askPrice Then
                                row.Cells("Ask").Style.BackColor = Drawing.Color.LightGreen
                            End If
                        End If

                        IntelligentTrader.Instance.MarketData(contract.localSymbol).Last = tickPriceDataItem.Price

                        If Not row.Cells("Change").Tag Is Nothing Then
                            Dim closePrice = CType(row.Cells("Change").Tag, Double)
                            row.Cells("Change").Value = (((tickPriceDataItem.Price - closePrice) / closePrice)).ToString("P")
                            IntelligentTrader.Instance.MarketData(contract.localSymbol).Change = (((tickPriceDataItem.Price - closePrice) / closePrice))
                        End If

                    Case TWSFramework.Enums.PriceTickType.Close
                        row.Cells("Change").Tag = tickPriceDataItem.Price
                        IntelligentTrader.Instance.MarketData(contract.localSymbol).Last = tickPriceDataItem.Price
                End Select
                Exit For
            End If
        Next
        mut.ReleaseMutex()
    End Sub

    Private Sub HandleCommonMarketDataSize(ByVal e As AxTWSLib._DTwsEvents_tickSizeEvent)
        mut.WaitOne()
        If Not MarketDataBuffer.ContainsKey(e.id) Then
            AxTws1.cancelMktData(e.id)
            Return
        End If
        Dim tickSizeDataItem As TickSizeData = New TickSizeData()
        tickSizeDataItem.LoadDataFromObject(e)

        Dim contract = MarketDataBuffer(tickSizeDataItem.RequestID)

        If (Not IntelligentTrader.Instance.MarketData.ContainsKey(contract.localSymbol)) Then
            IntelligentTrader.Instance.MarketData.Add(contract.localSymbol, New MarketDataItem)
            IntelligentTrader.Instance.MarketData(contract.localSymbol).Symbol = contract.localSymbol
        End If

        For Each row As DataGridViewRow In dgvMarketData.Rows
            If row.Cells("Symbol").Value.ToString().Equals(contract.localSymbol, StringComparison.OrdinalIgnoreCase) Then
                Select Case tickSizeDataItem.TickType
                    Case TWSFramework.Enums.SizeTickType.LastSize
                        row.Cells("Volume").Value = tickSizeDataItem.Size.ToString()
                        IntelligentTrader.Instance.MarketData(contract.localSymbol).LastVolume = tickSizeDataItem.Size
                    Case TWSFramework.Enums.SizeTickType.OPTION_CALL_OPEN_INTEREST
                        row.Cells("colOptCallOpenInterest").Value = tickSizeDataItem.Size.ToString()
                        IntelligentTrader.Instance.MarketData(contract.localSymbol).CallOpenInterest = tickSizeDataItem.Size
                    Case TWSFramework.Enums.SizeTickType.OPTION_CALL_VOLUME
                        row.Cells("colOptCallVolume").Value = tickSizeDataItem.Size.ToString()
                        IntelligentTrader.Instance.MarketData(contract.localSymbol).CallVolume = tickSizeDataItem.Size
                    Case TWSFramework.Enums.SizeTickType.OPTION_PUT_OPEN_INTEREST
                        row.Cells("colOptPutOpenInterest").Value = tickSizeDataItem.Size.ToString()
                        IntelligentTrader.Instance.MarketData(contract.localSymbol).PutOpenInterest = tickSizeDataItem.Size
                    Case TWSFramework.Enums.SizeTickType.OPTION_PUT_VOLUME
                        row.Cells("colOptPutVolume").Value = tickSizeDataItem.Size.ToString()
                        IntelligentTrader.Instance.MarketData(contract.localSymbol).PutVolume = tickSizeDataItem.Size
                End Select
                Exit For
            End If
        Next
        mut.ReleaseMutex()
        If tickSizeDataItem.TickType = TWSFramework.Enums.SizeTickType.LastSize Then
            Analyzer.TradeOccurred(contract.localSymbol, tickSizeDataItem.Size)
        End If
    End Sub
#End Region

#Region "Stop Functions"
    Private Sub StopEverything()
        mut.WaitOne()
        CancelSubscriptions()
        CancelCommonMarketData()
        AxTws1.disconnect()
        Trader.StopTrader()
        mut.ReleaseMutex()
    End Sub

    Private Sub CancelSubscriptions()
        If ScannerSubscriptions Is Nothing Then
            Return
        End If
        For Each ss In ScannerSubscriptions
            AxTws1.cancelScannerSubscription(ss.Value.RequestID)
        Next
        ScannerSubscriptions = New Dictionary(Of Integer, ScannerSubscription)
        BtnStart.Enabled = True
        BtnStop.Enabled = False
    End Sub

    Private Sub CancelCommonMarketData()
        If MarketDataBuffer Is Nothing Then
            Return
        End If
        For Each key In MarketDataBuffer.Keys
            AxTws1.cancelMktData(key)
        Next
        MarketDataBuffer = New Dictionary(Of Integer, TWSLib.IContract)
    End Sub
#End Region

    Private Sub chkPairSec_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkPairSec.CheckedChanged
        IntelligentTrader.Instance.UsePairSecurities = chkPairSec.Checked
    End Sub
End Class