﻿
Public Class AppSettings
    Private _tradeCloseTime As DateTime
    Public Property TradeCloseTime() As DateTime
        Get
            Return _tradeCloseTime
        End Get
        Set(ByVal value As DateTime)
            _tradeCloseTime = value
        End Set
    End Property

    Private _sellShortCloseProfitAbove As Double
    Public Property SellShortCloseProfitAbove() As Double
        Get
            Return _sellShortCloseProfitAbove
        End Get
        Set(ByVal value As Double)
            _sellShortCloseProfitAbove = value
        End Set
    End Property

    Private _sellShortCloseProfitBelow As Double
    Public Property SellShortCloseProfitBelow() As Double
        Get
            Return _sellShortCloseProfitBelow
        End Get
        Set(ByVal value As Double)
            _sellShortCloseProfitBelow = value
        End Set
    End Property

    Private _sellShortDeltaCloseProfitBelow As Double
    Public Property SellShortDeltaCloseProfitBelow() As Double
        Get
            Return _sellShortDeltaCloseProfitBelow
        End Get
        Set(ByVal value As Double)
            _sellShortDeltaCloseProfitBelow = value
        End Set
    End Property

    Private _buyLongCloseProfitAbove As Double
    Public Property BuyLongCloseProfitAbove() As Double
        Get
            Return _buyLongCloseProfitAbove
        End Get
        Set(ByVal value As Double)
            _buyLongCloseProfitAbove = value
        End Set
    End Property

    Private _buyLongCloseProfitBelow As Double
    Public Property BuyLongCloseProfitBelow() As Double
        Get
            Return _buyLongCloseProfitBelow
        End Get
        Set(ByVal value As Double)
            _buyLongCloseProfitBelow = value
        End Set
    End Property

    Private _buyLongDeltaCloseProfitBelow As Double
    Public Property BuyLongDeltaCloseProfitBelow() As Double
        Get
            Return _buyLongDeltaCloseProfitBelow
        End Get
        Set(ByVal value As Double)
            _buyLongDeltaCloseProfitBelow = value
        End Set
    End Property

    Private _scannerNumberOfRows As Integer
    Public Property ScannerNumberOfRows() As Integer
        Get
            Return _scannerNumberOfRows
        End Get
        Set(ByVal value As Integer)
            _scannerNumberOfRows = value
        End Set
    End Property

    Private _apiHostAddress As String
    Public Property APIHostAddress() As String
        Get
            Return _apiHostAddress
        End Get
        Set(ByVal value As String)
            _apiHostAddress = value
        End Set
    End Property


    Private _apiPort As Integer
    Public Property APIPort() As Integer
        Get
            Return _apiPort
        End Get
        Set(ByVal value As Integer)
            _apiPort = value
        End Set
    End Property

    Private _scannerMinimumCommon As Integer
    Public Property ScannerMinimumCommon() As Integer
        Get
            Return _scannerMinimumCommon
        End Get
        Set(ByVal value As Integer)
            _scannerMinimumCommon = value
        End Set
    End Property

    Private _snapshotGapMs As Integer
    Public Property SnapshotGapMs() As Integer
        Get
            Return _snapshotGapMs
        End Get
        Set(ByVal value As Integer)
            _snapshotGapMs = value
        End Set
    End Property

    Private _buySum25AtAskAboveAskMoreThan As Double
    Public Property BuySum25AtAskAboveAskMoreThan() As Double
        Get
            Return _buySum25AtAskAboveAskMoreThan
        End Get
        Set(ByVal value As Double)
            _buySum25AtAskAboveAskMoreThan = value
        End Set
    End Property

    Private _buy100AtAskMoreThan As Double
    Public Property Buy100AtAskMoreThan() As Double
        Get
            Return _buy100AtAskMoreThan
        End Get
        Set(ByVal value As Double)
            _buy100AtAskMoreThan = value
        End Set
    End Property

    Private _sellSum25AtBidBelowBidMoreThan As Double
    Public Property SellSum25AtBidBelowBidMoreThan() As Double
        Get
            Return _sellSum25AtBidBelowBidMoreThan
        End Get
        Set(ByVal value As Double)
            _sellSum25AtBidBelowBidMoreThan = value
        End Set
    End Property

    Private _sell100AtBidMoreThan As Double
    Public Property Sell100AtBidMoreThan() As Double
        Get
            Return _sell100AtBidMoreThan
        End Get
        Set(ByVal value As Double)
            _sell100AtBidMoreThan = value
        End Set
    End Property

    Private _quantityPriceFactor As Double
    Public Property QuantityPriceFactor() As Double
        Get
            Return _quantityPriceFactor
        End Get
        Set(ByVal value As Double)
            _quantityPriceFactor = value
        End Set
    End Property

    Private _securitySpecificDeltaProfitThreshold As Double
    Public Property SecuritySpectficDeltaProfitThreshold() As Double
        Get
            Return _securitySpecificDeltaProfitThreshold
        End Get
        Set(ByVal value As Double)
            _securitySpecificDeltaProfitThreshold = value
        End Set
    End Property

    Private _securitySpecificDeltaProfitValue As Double
    Public Property SecuritySpecificDeltaProfitValue() As Double
        Get
            Return _securitySpecificDeltaProfitValue
        End Get
        Set(ByVal value As Double)
            _securitySpecificDeltaProfitValue = value
        End Set
    End Property




End Class
