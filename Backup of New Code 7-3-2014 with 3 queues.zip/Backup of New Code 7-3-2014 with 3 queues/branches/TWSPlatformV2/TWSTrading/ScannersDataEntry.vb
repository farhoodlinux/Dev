﻿Imports System.ComponentModel
Imports System.Text
Imports System.Windows.Forms
Imports TWSFramework.Data
Imports DataAccessLayer
Imports TWSFramework
Imports TWSFramework.Enums
Imports System.Collections.Generic

Partial Public Class ScannersDataEntry
    Inherits Form
    Public Sub New()
        InitializeComponent()
        SetComboboxes()
        ClearData()
        SetDataSource()
    End Sub

    Private Sub SetComboboxes()
        cmbInstrument.DataSource = System.Enum.GetNames(GetType(TWSFramework.Enums.InstrumentType))
        Dim itemsSource = System.Enum.GetNames(GetType(TWSFramework.Enums.LocationType))
        cmbScanCode.DataSource = System.Enum.GetNames(GetType(TWSFramework.Enums.ScanCodeType))
        cmbStockType.DataSource = System.Enum.GetNames(GetType(TWSFramework.Enums.StockTypeFilter))
        For Each item In itemsSource
            chkListBoxLocation.Items.Add(item)
        Next


    End Sub

    Private Sub SetDataSource()
        Dim scanners = New DataLayer().GetScannersFromDatabase(False)
        If scanners Is Nothing Then
            Return
        End If
        If scanners.Count = 0 Then
            Return
        End If

        dgvScanners.DataSource = scanners


        For Each col As DataGridViewColumn In dgvScanners.Columns
            col.Visible = False
        Next

        dgvScanners.Columns("RequestId").Width = 30
        dgvScanners.Columns("RequestId").Visible = True
        dgvScanners.Columns("Enabled").Visible = True
        dgvScanners.Columns("ScannerName").Visible = True
        dgvScanners.Columns("NumberOfRows").Visible = True
        dgvScanners.Columns("Instrument").Visible = True
        dgvScanners.Columns("ScanCode").Visible = True
        dgvScanners.Columns("PriceAbove").Visible = True
        dgvScanners.Columns("PriceBelow").Visible = True
        dgvScanners.Columns("MarketCapAbove").Visible = True
        dgvScanners.Columns("MarketCapBelow").Visible = True
        dgvScanners.Columns("StockTypeFilter").Visible = True
        dgvScanners.Columns("LocationTypesString").Visible = True
        dgvScanners.Columns("RequestId").DisplayIndex = 0
        dgvScanners.Columns("ScannerName").DisplayIndex = 1
        dgvScanners.Columns("ScanCode").DisplayIndex = 2
        dgvScanners.Columns("LocationTypesString").DisplayIndex = 3
        dgvScanners.Columns("PriceAbove").DisplayIndex = 4
        dgvScanners.Columns("PriceBelow").DisplayIndex = 5
        dgvScanners.Columns("Instrument").DisplayIndex = 6
        dgvScanners.Columns("StockTypeFilter").DisplayIndex = 7
        dgvScanners.Columns("MarketCapAbove").DisplayIndex = 8
        dgvScanners.Columns("MarketCapBelow").DisplayIndex = 9
        dgvScanners.Columns("NumberOfRows").DisplayIndex = 10
        dgvScanners.Columns("Enabled").DisplayIndex = 11
        dgvScanners.Columns("LocationTypesString").HeaderText = "Locations"
        dgvScanners.Columns("NumberOfRows").HeaderText = "No. Of Rows"
        dgvScanners.Columns("RequestId").HeaderText = "Id"
        dgvScanners.Columns("Enabled").Width = 60

        CopyRowForEditing(dgvScanners.Rows(0))
    End Sub

    Private Sub CopyRowForEditing(row As DataGridViewRow)
        txtMinPrice.Text = row.Cells("PriceAbove").Value.ToString()
        txtMaxPrice.Text = row.Cells("PriceBelow").Value.ToString()
        txtRequestId.Text = row.Cells("RequestId").Value.ToString()
        txtScannerName.Text = row.Cells("ScannerName").Value.ToString()
        txtMarketCapAbove.Text = row.Cells("MarketCapAbove").Value.ToString()
        txtMarketCapBelow.Text = row.Cells("MarketCapBelow").Value.ToString()
        cmbStockType.SelectedItem = (CType(CInt(Fix(row.Cells("StockTypeFilter").Value)), StockTypeFilter)).ToString()
        cmbScanCode.SelectedItem = (CType(CInt(Fix(row.Cells("ScanCode").Value)), ScanCodeType)).ToString()
        'cmbLocation.SelectedItem = (CType(CInt(Fix(row.Cells("Location").Value)), LocationType)).ToString()
        cmbInstrument.SelectedItem = (CType(CInt(Fix(row.Cells("Instrument").Value)), InstrumentType)).ToString()
        chkEnabled.Checked = CBool(row.Cells("Enabled").Value)
        chkListBoxLocation.ClearSelected()
        For Each location1 In row.Cells("LocationTypesString").Value.ToString().Split(",")
            chkListBoxLocation.SetItemChecked(chkListBoxLocation.FindStringExact(location1), True)
        Next
        btnUpdate.Text = "Update"
        btnDelete.Enabled = True
    End Sub

    Private Sub dgvScanners_CellMouseClick(ByVal sender As Object, ByVal e As DataGridViewCellMouseEventArgs) Handles dgvScanners.CellMouseClick
        If e.RowIndex < 0 Then
            Return
        End If
        Dim row = dgvScanners.Rows(e.RowIndex)
        CopyRowForEditing(row)
    End Sub

    Private Sub ClearData()
        btnUpdate.Text = "Add Scanner"
        txtMinPrice.Text = "0"
        txtMaxPrice.Text = "0"
        txtRequestId.Text = "0"
        txtScannerName.Text = ""
        txtMarketCapBelow.Text = "0"
        txtMarketCapAbove.Text = txtMarketCapBelow.Text
        cmbInstrument.SelectedIndex = 0
        'cmbLocation.SelectedIndex = 0
        cmbScanCode.SelectedIndex = 0
        cmbStockType.SelectedIndex = 0
        chkListBoxLocation.ClearSelected()
        btnDelete.Enabled = False
    End Sub

    Private Sub btnClear_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnClear.Click
        ClearData()
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpdate.Click
        Try
            Dim minPrice = Double.Parse(txtMinPrice.Text)
            Dim maxPrice = Double.Parse(txtMaxPrice.Text)
            Dim marketCapAbove = Double.Parse(txtMarketCapAbove.Text)
            Dim marketCapBelow = Double.Parse(txtMarketCapBelow.Text)
            Dim scanner = New ScannerSubscription() With
                          {
                              .PriceAbove = minPrice,
                              .PriceBelow = maxPrice,
                              .MarketCapAbove = marketCapAbove,
                              .MarketCapBelow = marketCapBelow,
                              .RequestID = Integer.Parse(txtRequestId.Text),
                              .ScannerName = txtScannerName.Text,
                              .NumberOfRows = 1,
                              .StockTypeFilter = CType(System.Enum.Parse(GetType(TWSFramework.Enums.StockTypeFilter), cmbStockType.Text), TWSFramework.Enums.StockTypeFilter),
                              .Instrument = CType(System.Enum.Parse(GetType(TWSFramework.Enums.InstrumentType), cmbInstrument.Text), TWSFramework.Enums.InstrumentType),
                              .ScanCode = CType(System.Enum.Parse(GetType(TWSFramework.Enums.ScanCodeType), cmbScanCode.Text), TWSFramework.Enums.ScanCodeType),
                              .Enabled = chkEnabled.Checked
                          }
            scanner.LocationTypes = New List(Of LocationType)
            For Each location1 In chkListBoxLocation.CheckedItems
                scanner.LocationTypes.Add(CType(System.Enum.Parse(GetType(TWSFramework.Enums.LocationType), location1.ToString()), TWSFramework.Enums.LocationType))
            Next
            If scanner.LocationTypes.Count = 0 Then
                MessageBox.Show("Please select the locations", "Invalid Data")
                Return
            End If

            CType(New DataLayer(), DataLayer).WriteToDatabase(scanner)
            ClearData()
            SetDataSource()
        Catch
            MessageBox.Show("Invalid Data, Please enter correct values for all the fields!", "Invalid Data")
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As System.Object, e As System.EventArgs) Handles btnDelete.Click
        If MessageBox.Show("Are you sure you want to delete this scanner?", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = Windows.Forms.DialogResult.OK Then
            Dim RequestID = Integer.Parse(txtRequestId.Text)
            CType(New DataLayer(), DataLayer).DeleteScanner(RequestID)
            ClearData()
            SetDataSource()
        End If
    End Sub
End Class