﻿Public Class Pipe
    Private _id As Integer
    Private _size As Integer

    Private _data As Collections.Queue

    Public Sub New(ByVal pID As Integer, ByVal pSize As Integer)
        _id = pID
        If _size < 1 Then
            ' RAISE EXCEPTION ON WRONG SIZE
        End If
        _data = New Collections.Queue(_size)
    End Sub

    Public ReadOnly Property id() As Integer
        Get
            Return _id
        End Get
    End Property

    Public ReadOnly Property ReadData() As Collections.Queue
        Get
            Return _data
        End Get
    End Property

    Public Sub AddNewData(ByVal pDataElement As Single)
        _data.Enqueue(pDataElement)
    End Sub
End Class
