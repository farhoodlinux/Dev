Imports TWSFramework
Imports TWSFramework.Events

Public Class FrmMain

    Private WithEvents ErrManager As ErrorManager
    Private WithEvents MarketManager As MarketManager
    Private _NextValidOrderID As Integer



    Private Sub Start_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Start.Click

        MarketManager.Connect("", 7496, 3)

    End Sub


    Private Sub FrmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ErrManager = New ErrorManager
        MarketManager = New MarketManager
        _NextValidOrderID = -1

    End Sub


    Private Sub ErrData(ByVal sender As Object, ByVal e As ErrorEventArgs) Handles ErrManager.ErrorEvent
        ErrorMsg.Items.Add(e.data.ErrFormat())
    End Sub


    Private Sub btnStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStop.Click
        MarketManager.Disconnect()
    End Sub


    Private Sub Scanners_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Scanners.Click

        Dim scannerform As New Scanners
        scannerform.Show()
    End Sub


    Private Sub ErrorMsg_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ErrorMsg.SelectedIndexChanged

    End Sub



    Private Sub btnTEST_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTEST.Click
        Dim FT As New frmTEST
        FT.Show()
        FT.init()
    End Sub

    Private Sub btnTestMarketD_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTestMarketD.Click
        Dim MdataT As New TestMarketData

        MdataT.Show()

    End Sub
End Class
