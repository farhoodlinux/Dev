﻿Public Class TestMarketData


    Private _Symbol As String
    Private _requestID As Integer
    Private WithEvents _marketMgr As TWSFramework.MarketManager


    Public Sub New()
        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        _marketMgr = New TWSFramework.MarketManager()
    End Sub


    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        Dim contract As TWSFramework.Data.Contract
        Dim a As MarketEngine.Pipe

        a = New MarketEngine.Pipe(1, 100)

        _Symbol = txtSymbol.Text

        btnStop.Enabled = True
        txtSymbol.Enabled = False
        btnStart.Enabled = False

        contract = New TWSFramework.Data.Contract()
        contract.LocalSymbol = _Symbol
        contract.SecType = TWSFramework.Enums.SecurityType.Stk
        contract.Exchange = "SMART"
        contract.Currency = "USD"

        Dim tickTypes As New List(Of String)
        tickTypes.Add("100")
        tickTypes.Add("104")
        tickTypes.Add("106")
        tickTypes.Add("165")
        tickTypes.Add("221")
        tickTypes.Add("225")

        _requestID = _marketMgr.GetMarketData(contract, tickTypes, False)
    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStop.Click

        btnStart.Enabled = True
        txtSymbol.Enabled = True
        btnStop.Enabled = False

        _marketMgr.CancelMarketData(_requestID)

        txtBidSize.Text = ""
        txtBid.Text = ""
        txtAsk.Text = ""
        txtAskSize.Text = ""
        txtLast.Text = ""
        txtTotalVolume.Text = ""
    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub MarketManager_MarketDataEvent(ByVal sender As Object, ByVal e As TWSFramework.Events.MarketDataEventArgs) Handles _marketMgr.MarketDataEvent
        Select Case e.MarketType
            Case TWSFramework.Enums.MarketDataType.Computation

            Case TWSFramework.Enums.MarketDataType.EFP
            Case TWSFramework.Enums.MarketDataType.Generic
            Case TWSFramework.Enums.MarketDataType.Price
                If e.PriceData.TickType = TWSFramework.Enums.PriceTickType.Ask Then
                    txtAsk.Text = e.PriceData.Price.ToString()
                ElseIf e.PriceData.TickType = TWSFramework.Enums.PriceTickType.Bid Then
                    txtBid.Text = e.PriceData.Price.ToString()
                ElseIf e.PriceData.TickType = TWSFramework.Enums.PriceTickType.Last Then
                    txtLast.Text = e.PriceData.Price.ToString()
                End If
            Case TWSFramework.Enums.MarketDataType.Size
                If e.SizeData.TickType = TWSFramework.Enums.SizeTickType.Bid Then
                    txtBidSize.Text = e.SizeData.Size.ToString()
                ElseIf e.SizeData.TickType = TWSFramework.Enums.SizeTickType.AskSize Then
                    txtAskSize.Text = e.SizeData.Size.ToString()
                ElseIf e.SizeData.TickType = TWSFramework.Enums.SizeTickType.Volume Then
                    txtTotalVolume.Text = e.SizeData.Size.ToString()
                ElseIf e.SizeData.TickType = TWSFramework.Enums.SizeTickType.LastSize Then
                    txtLastSize.Text = e.SizeData.Size.ToString()
                End If
            Case TWSFramework.Enums.MarketDataType.StringValue
        End Select
    End Sub

End Class