<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Start = New System.Windows.Forms.Button
        Me.ErrorMsg = New System.Windows.Forms.ListBox
        Me.Scanners = New System.Windows.Forms.Button
        Me.btnStop = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.btnTestMarketD = New System.Windows.Forms.Button
        Me.btnTEST = New System.Windows.Forms.Button
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Start
        '
        Me.Start.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Start.Location = New System.Drawing.Point(79, 12)
        Me.Start.Name = "Start"
        Me.Start.Size = New System.Drawing.Size(75, 23)
        Me.Start.TabIndex = 0
        Me.Start.Text = "Start"
        Me.Start.UseVisualStyleBackColor = True
        '
        'ErrorMsg
        '
        Me.ErrorMsg.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ErrorMsg.FormattingEnabled = True
        Me.ErrorMsg.Location = New System.Drawing.Point(0, 0)
        Me.ErrorMsg.Name = "ErrorMsg"
        Me.ErrorMsg.Size = New System.Drawing.Size(836, 407)
        Me.ErrorMsg.TabIndex = 1
        '
        'Scanners
        '
        Me.Scanners.Location = New System.Drawing.Point(79, 81)
        Me.Scanners.Name = "Scanners"
        Me.Scanners.Size = New System.Drawing.Size(75, 23)
        Me.Scanners.TabIndex = 2
        Me.Scanners.Text = "Scanners"
        Me.Scanners.UseVisualStyleBackColor = True
        '
        'btnStop
        '
        Me.btnStop.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnStop.Location = New System.Drawing.Point(79, 41)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(75, 23)
        Me.btnStop.TabIndex = 3
        Me.btnStop.Text = "Stop"
        Me.btnStop.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnTestMarketD)
        Me.Panel1.Controls.Add(Me.btnTEST)
        Me.Panel1.Controls.Add(Me.Start)
        Me.Panel1.Controls.Add(Me.btnStop)
        Me.Panel1.Controls.Add(Me.Scanners)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel1.Location = New System.Drawing.Point(670, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(166, 413)
        Me.Panel1.TabIndex = 4
        '
        'btnTestMarketD
        '
        Me.btnTestMarketD.Location = New System.Drawing.Point(52, 139)
        Me.btnTestMarketD.Name = "btnTestMarketD"
        Me.btnTestMarketD.Size = New System.Drawing.Size(102, 23)
        Me.btnTestMarketD.TabIndex = 5
        Me.btnTestMarketD.Text = "Test Market Data"
        Me.btnTestMarketD.UseVisualStyleBackColor = True
        '
        'btnTEST
        '
        Me.btnTEST.Location = New System.Drawing.Point(79, 110)
        Me.btnTEST.Name = "btnTEST"
        Me.btnTEST.Size = New System.Drawing.Size(75, 23)
        Me.btnTEST.TabIndex = 4
        Me.btnTEST.Text = "T E S T"
        Me.btnTEST.UseVisualStyleBackColor = True
        '
        'FrmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(836, 413)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.ErrorMsg)
        Me.Name = "FrmMain"
        Me.Text = "Main Window"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Start As System.Windows.Forms.Button
    Friend WithEvents ErrorMsg As System.Windows.Forms.ListBox
    Friend WithEvents Scanners As System.Windows.Forms.Button
    Friend WithEvents btnStop As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnTEST As System.Windows.Forms.Button
    Friend WithEvents btnTestMarketD As System.Windows.Forms.Button

End Class
