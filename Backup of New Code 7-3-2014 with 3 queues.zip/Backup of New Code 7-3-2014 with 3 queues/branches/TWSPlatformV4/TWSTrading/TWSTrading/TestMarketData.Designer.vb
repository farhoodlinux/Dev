﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TestMarketData
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtBid = New System.Windows.Forms.TextBox
        Me.txtBidSize = New System.Windows.Forms.TextBox
        Me.txtAsk = New System.Windows.Forms.TextBox
        Me.txtAskSize = New System.Windows.Forms.TextBox
        Me.txtLast = New System.Windows.Forms.TextBox
        Me.txtLastSize = New System.Windows.Forms.TextBox
        Me.txtTotalVolume = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtSymbol = New System.Windows.Forms.TextBox
        Me.btnStart = New System.Windows.Forms.Button
        Me.btnStop = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'txtBid
        '
        Me.txtBid.Location = New System.Drawing.Point(25, 65)
        Me.txtBid.Name = "txtBid"
        Me.txtBid.Size = New System.Drawing.Size(83, 20)
        Me.txtBid.TabIndex = 0
        '
        'txtBidSize
        '
        Me.txtBidSize.Location = New System.Drawing.Point(114, 65)
        Me.txtBidSize.Name = "txtBidSize"
        Me.txtBidSize.Size = New System.Drawing.Size(83, 20)
        Me.txtBidSize.TabIndex = 1
        '
        'txtAsk
        '
        Me.txtAsk.Location = New System.Drawing.Point(203, 65)
        Me.txtAsk.Name = "txtAsk"
        Me.txtAsk.Size = New System.Drawing.Size(83, 20)
        Me.txtAsk.TabIndex = 2
        '
        'txtAskSize
        '
        Me.txtAskSize.Location = New System.Drawing.Point(292, 65)
        Me.txtAskSize.Name = "txtAskSize"
        Me.txtAskSize.Size = New System.Drawing.Size(83, 20)
        Me.txtAskSize.TabIndex = 3
        '
        'txtLast
        '
        Me.txtLast.Location = New System.Drawing.Point(381, 65)
        Me.txtLast.Name = "txtLast"
        Me.txtLast.Size = New System.Drawing.Size(83, 20)
        Me.txtLast.TabIndex = 4
        '
        'txtLastSize
        '
        Me.txtLastSize.Location = New System.Drawing.Point(470, 65)
        Me.txtLastSize.Name = "txtLastSize"
        Me.txtLastSize.Size = New System.Drawing.Size(83, 20)
        Me.txtLastSize.TabIndex = 5
        '
        'txtTotalVolume
        '
        Me.txtTotalVolume.Location = New System.Drawing.Point(559, 65)
        Me.txtTotalVolume.Name = "txtTotalVolume"
        Me.txtTotalVolume.Size = New System.Drawing.Size(83, 20)
        Me.txtTotalVolume.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(25, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(22, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Bid"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(111, 49)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Bid Size"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(200, 49)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(25, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Ask"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(289, 49)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Ask Size"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(378, 49)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(27, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Last"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(467, 49)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(50, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Last Size"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(556, 49)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Total Volume"
        '
        'txtSymbol
        '
        Me.txtSymbol.Location = New System.Drawing.Point(25, 12)
        Me.txtSymbol.Name = "txtSymbol"
        Me.txtSymbol.Size = New System.Drawing.Size(83, 20)
        Me.txtSymbol.TabIndex = 14
        '
        'btnStart
        '
        Me.btnStart.Location = New System.Drawing.Point(115, 12)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(41, 20)
        Me.btnStart.TabIndex = 15
        Me.btnStart.Text = "Start"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'btnStop
        '
        Me.btnStop.Location = New System.Drawing.Point(162, 12)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(41, 20)
        Me.btnStop.TabIndex = 16
        Me.btnStop.Text = "Stop"
        Me.btnStop.UseVisualStyleBackColor = True
        '
        'TestMarketData
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(837, 320)
        Me.Controls.Add(Me.btnStop)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.txtSymbol)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtTotalVolume)
        Me.Controls.Add(Me.txtLastSize)
        Me.Controls.Add(Me.txtLast)
        Me.Controls.Add(Me.txtAskSize)
        Me.Controls.Add(Me.txtAsk)
        Me.Controls.Add(Me.txtBidSize)
        Me.Controls.Add(Me.txtBid)
        Me.Name = "TestMarketData"
        Me.Text = "TestMarketData"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtBid As System.Windows.Forms.TextBox
    Friend WithEvents txtBidSize As System.Windows.Forms.TextBox
    Friend WithEvents txtAsk As System.Windows.Forms.TextBox
    Friend WithEvents txtAskSize As System.Windows.Forms.TextBox
    Friend WithEvents txtLast As System.Windows.Forms.TextBox
    Friend WithEvents txtLastSize As System.Windows.Forms.TextBox
    Friend WithEvents txtTotalVolume As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtSymbol As System.Windows.Forms.TextBox
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents btnStop As System.Windows.Forms.Button
End Class
