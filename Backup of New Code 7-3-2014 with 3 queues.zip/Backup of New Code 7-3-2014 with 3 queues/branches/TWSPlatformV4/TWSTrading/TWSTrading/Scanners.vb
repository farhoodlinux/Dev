Imports TWSFramework
Imports TWSFramework.Events
Imports TWSFramework.Data
Public Class Scanners
    Private WithEvents MarketManager As MarketManager
    Private WithEvents MyScannerSubscription As TWSFramework.ScannerSubscription

    Private iLoops As Integer = 0
    Private _Securities As List(Of IntersectionData) = New List(Of IntersectionData)



    'Private RequestId As Integer

    Private ScannerCount As Integer = 1
    Private Allscanners As List(Of ScannerFlatData)
    Private SortedScanner As List(Of ScannerFlatData)

    Private RegisteredScanners As Dictionary(Of Integer, TWSFramework.ScannerSubscription) = New Dictionary(Of Integer, TWSFramework.ScannerSubscription)
    Private AllScanerData As Dictionary(Of Integer, List(Of TWSFramework.Data.ScannerData)) = New Dictionary(Of Integer, List(Of TWSFramework.Data.ScannerData))



    Private Sub ScanButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScanButton.Click
        StartScanners()
    End Sub


    Private Sub Scanners_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        MarketManager = New MarketManager
        Allscanners = New List(Of ScannerFlatData)()

    End Sub


    Private Sub Scannerdata(ByVal sender As Object, ByVal e As ScannerDataEventArgs) Handles MarketManager.ScannerDataEvent

        'If (ScannerGrid.Columns.Count = 0) Then
        'ScannerGrid.Columns.Add(Utilities.CreateGridDataColumn("LocalSymbol", "Symbol"))
        'ScannerGrid.Columns.Add(Utilities.CreateGridDataColumn("MarketName"))
        'ScannerGrid.Columns.Add(Utilities.CreateGridDataColumn("SecType", "Seurity Type"))
        'ScannerGrid.Columns.Add(Utilities.CreateGridDataColumn("No_Times_In_List", "No. of scanners"))
        'ScannerGrid.Columns.Add(Utilities.CreateGridDataColumn("Scanner_List", "Scanner List"))
        'End If


        If (e.id = 1) Then
            txtBox.Text = ""
            txtBox.Refresh()
            Application.DoEvents()
            txtBox.SuspendLayout()
        ElseIf (e.id = 2) Then
            txtBox2.Text = ""
            txtBox2.Refresh()
            Application.DoEvents()
            txtBox2.SuspendLayout()
        Else
            txtBox3.Text = ""
            txtBox3.Refresh()
            Application.DoEvents()
            txtBox3.SuspendLayout()
        End If

        'e.id

        Try
            AllScanerData(e.id).Clear()

            For Each data As ScannerData In e.data
                Dim s As String
                s = data.RequestID & " | " & data.GetFlattenedData.LocalSymbol & " | " & data.GetFlattenedData.MarketName & Chr(13) & Chr(10)
                If (e.id = 1) Then
                    txtBox.Text = txtBox.Text & s
                ElseIf (e.id = 2) Then
                    txtBox2.Text = txtBox2.Text & s
                Else
                    txtBox3.Text = txtBox3.Text & s
                End If
            Next

            AllScanerData(e.id).AddRange(e.data)

            txtBox.ResumeLayout()
            txtBox.Refresh()
            Application.DoEvents()

            iLoops = iLoops + 1
            txtLoops.Text = iLoops.ToString

            ' Me.ScannerGrid.DataSource = AllScanerData(e.id)
            'Me.ScannerGrid.Refresh()

            _Securities.Clear()
            _Securities = SortScanners(AllScanerData)

            Me.ScannerGrid.DataSource = _Securities
            Me.ScannerGrid.Refresh()

        Catch ex As Exception
            MsgBox(ex.Message.ToString(), MsgBoxStyle.Critical)
        End Try
    End Sub


    Private Function SortScanners(ByVal data As Dictionary(Of Integer, List(Of ScannerData))) As List(Of IntersectionData)
        Dim ResList As List(Of IntersectionData) = New List(Of IntersectionData)
        Dim comp As String
        Dim iHits As Integer

        Try
            'Go Throug all Scanners first time

            ' Iterate through a dictionary
            For Each ScData1 As KeyValuePair(Of Integer, List(Of ScannerData)) In data
                'Go Through all securities of the first pass
                For Each stock1 As ScannerData In ScData1.Value
                    comp = stock1.GetFlattenedData.MarketName & " | " & stock1.GetFlattenedData.LocalSymbol
                    iHits = 1

                    'Go through all scanners again and count how many have the same security
                    '*******************************************************************************************
                    For Each ScData2 As KeyValuePair(Of Integer, List(Of ScannerData)) In data
                        'If this is different scanner
                        If (ScData1.Key <> ScData2.Key) Then
                            'Go Through all securities of the second pass
                            For Each stock2 As ScannerData In ScData2.Value
                                'If found the Same Security, increase Hit Counter
                                If comp = stock2.GetFlattenedData.MarketName & " | " & stock2.GetFlattenedData.LocalSymbol Then
                                    iHits = iHits + 1
                                End If
                            Next stock2
                            My.Application.DoEvents()
                        End If
                    Next ScData2

                    'If there was more then 1 entry in all scanners...
                    If iHits > 1 Then
                        'If  not yet in the results list
                        Dim NewResult As IntersectionData = New IntersectionData(stock1.GetFlattenedData.Exchange, stock1.GetFlattenedData.MarketName, stock1.GetFlattenedData.LocalSymbol, iHits)
                        If Not Find(ResList, NewResult) Then
                            'Add to the resulta
                            ResList.Add(NewResult)
                        End If
                    End If
                    My.Application.DoEvents()

                Next stock1

            Next ScData1

            ResList.Sort()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error in SortScanners")
        End Try

        Return ResList
    End Function

    Private Function Find(ByVal pList As List(Of IntersectionData), ByVal pValue As IntersectionData) As Boolean
        Dim result As Boolean = False

        ' Iterate through a collection
        For Each val As IntersectionData In pList
            If (val.Exchange.Equals(pValue.Exchange) And val.Symbol.Equals(pValue.Symbol)) Then
                result = True
                Return result
            End If
        Next
        Return result

    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub StartScanners()

        Dim RequestId As Integer
        Dim NewScanerData As List(Of ScannerData)

        ' Create a subscription for 
        MyScannerSubscription = New ScannerSubscription(10, Enums.InstrumentType.Stk, Enums.LocationType.Stk_Us, Enums.StockTypeFilter.All, Enums.ScanCodeType.Most_Active, 0, 1000)
        RequestId = MarketManager.ScanSecurities(MyScannerSubscription)
        RegisteredScanners.Add(RequestId, MyScannerSubscription)
        NewScanerData = New List(Of ScannerData)
        AllScanerData.Add(RequestId, NewScanerData)


        Application.DoEvents()
        'System.Threading.Thread.Sleep(5000)

        'MyScannerSubscription = New ScannerSubscription(5, Enums.InstrumentType.Stk, Enums.LocationType.Stk_Us, Enums.StockTypeFilter.All, Enums.ScanCodeType.Most_Active, 5, 500)
        'RequestId = MarketManager.ScanSecurities(MyScannerSubscription)
        'RegisteredScanners.Add(RequestId, MyScannerSubscription)
        'NewScanerData = New List(Of ScannerData)
        'AllScanerData.Add(RequestId, NewScanerData)

        'Application.DoEvents()
        'System.Threading.Thread.Sleep(5000)

        'MyScannerSubscription = New ScannerSubscription(3, Enums.InstrumentType.Stk, Enums.LocationType.Stk_Us, Enums.StockTypeFilter.All, Enums.ScanCodeType.Most_Active, 3, 300)
        'RequestId = MarketManager.ScanSecurities(MyScannerSubscription)
        'RegisteredScanners.Add(RequestId, MyScannerSubscription)
        'NewScanerData = New List(Of ScannerData)
        'AllScanerData.Add(RequestId, NewScanerData)

    End Sub

End Class