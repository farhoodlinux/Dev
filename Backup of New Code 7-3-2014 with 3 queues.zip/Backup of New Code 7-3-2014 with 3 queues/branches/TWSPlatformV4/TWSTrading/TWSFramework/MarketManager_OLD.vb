Imports TWSFramework.Data
Imports TWSFramework.Events

Public Class MarketManager_OLD
    Private _scannerData As List(Of ScannerData)
    Private _currentEventCount As Integer
    Private TWSForm As TWSComponent
    Private _EventCount As Integer
    Private _ErrorData As List(Of ErrorData)

    Shared RegistredScanres As New Dictionary(Of Integer, ScannerData)

    Public Event ScannerDataEvent As ScannerDataReturned

    Public Property ErrorData() As List(Of ErrorData)
        Get

            Return _ErrorData
        End Get

        Set(ByVal value As List(Of ErrorData))
            _ErrorData = value
        End Set
    End Property

    Public Sub New()

        TWSForm = TWSComponent.getinstance
        TWSForm.SetMarketManager(Me)

    End Sub



    ''' <summary>
    ''' Connects to the TWS API
    ''' </summary>
    ''' <param name="host">The host to connect to</param>
    ''' <param name="port">The port to connect to the host on</param>
    ''' <param name="clientID">The id of the client that is connecting</param>
    ''' <remarks></remarks>
    Public Sub Connect(ByVal host As String, ByVal port As Integer, ByVal clientID As Integer)

        If TWSForm.AxTws1.serverVersion <= 0 Then
            TWSForm.AxTws1.connect(host, port, clientID)

        End If
    End Sub

    ''' <summary>
    ''' Disconnects from the TWS API
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Disconnect()
        TWSForm.AxTws1.disconnect()
    End Sub

    ''' <summary>
    ''' Starts the scanner looking for securities that meet the criteria of the
    ''' ScannerSubscription
    ''' object this method also specifies how many records should be returned
    ''' before the scanner event fires
    ''' </summary>
    ''' <param name="scanner">The ScannerSubscription object that defines what securities to search for</param>
    '''   ''' <returns>An integer that represents the request id used for the scan</returns>
    ''' <remarks></remarks>
    Public Function ScanSecurities(ByVal scanner As scannersubscription) As Integer


        Dim requestIdentity As Integer = TWSForm.GetNextValidID

        Dim twsScanner As TWSLib.IScannerSubscription = TWSForm.AxTws1.createScannerSubscription()
        scanner.RevertToTWSObject(twsScanner)
        TWSForm.AxTws1.reqScannerSubscriptionEx(requestIdentity, twsScanner)
        _EventCount = scanner.NumberOfRows
        Return requestIdentity
    End Function


    Public Sub cancelscansecurities(ByVal RequestId As Integer)

        TWSForm.AxTws1.cancelScannerSubscription(RequestId)

    End Sub

    Public Function RequestMarketData(ByVal contract As Contract, ByVal tickTypes As String, ByVal snapshot As Boolean) As Integer
        Dim requestIdentity As Integer = RequestID
        Dim twsContract As TWSLib.IContract = TWSForm.AxTws1.createContract()
        contract.RevertToTWSObject(twsContract)
        TWSForm.AxTws1.reqMktDataEx(requestIdentity, twsContract, tickTypes, Utilities.ConvertBoolToInt(snapshot))
    End Function

#Region " Class Properties "

    ''' <summary>
    ''' Used to get the next ID for use in a transaction
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private ReadOnly Property RequestID() As Integer
        Get
            Return IdentityCreator.GetNextTransactionID()
        End Get
    End Property

#End Region

    ''' <summary>
    ''' This sub called from AxTws1.scannerDataEx handler.
    ''' Mark Scanner buffer as full, copy data to Scanners, 
    ''' and raise event to indicated that scanner has new data   
    ''' </summary>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Friend Sub APIScannerDataEnd(ByVal e As AxTWSLib._DTwsEvents_scannerDataEndEvent)

    End Sub

    ''' <summary>
    ''' This sub called from AxTws1.scannerDataEx handler
    ''' </summary>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Friend Sub APIScannerData(ByVal e As AxTWSLib._DTwsEvents_scannerDataExEvent)


        If _scannerData Is Nothing Then
            _scannerData = New List(Of ScannerData)()
            _scannerData.
        End If

        ' Here we have _eventCount -1 since the else should be the last
        ' line run before sending the multi-data event
        If _currentEventCount < (_EventCount - 1) Then
            Dim scanData As New ScannerData()
            scanData.LoadDataFromObject(e)

            _scannerData.Add(scanData)

            _currentEventCount += 1
        Else
            ' We've reached our event count so fire the event now
            Dim scanData As New ScannerData()
            scanData.LoadDataFromObject(e)

            _scannerData.Add(scanData)

            Dim ScanEvent As New ScannerDataEventArgs()
            ScanEvent.data = _scannerData
            ScanEvent.id = 


            RaiseEvent ScannerDataEvent(Me, ScanEvent)

            _scannerData.Clear()
            _currentEventCount = 0
        End If

    End Sub

    Friend Sub APIMarketData(ByVal e As Object)

    End Sub

    Private Sub MarketManager_ScannerDataEvent(ByVal sender As Object, ByVal e As Events.ScannerDataEventArgs) Handles Me.ScannerDataEvent
        Dim i As Integer
        i = 1
    End Sub
End Class
