Imports TWSFramework.Data
Imports TWSFramework.Enums
Namespace Events

    ''' <summary>
    ''' This class houses all of the data objects that come back from the
    ''' market data request
    ''' </summary>
    ''' <remarks></remarks>
    Public Class MarketDataEventArgs
        Inherits EventArgs

        Private _tickPrice As TickPriceData = Nothing
        Private _tickSize As TickSizeData = Nothing
        Private _tickComputation As TickComputationData = Nothing
        Private _tickGeneric As TickGenericData = Nothing
        Private _tickString As TickStringData = Nothing
        Private _tickEfp As TickEFPData = Nothing

        Private _marketType As MarketDataType

        Public Sub New()

        End Sub

        ''' <summary>
        ''' This constructor passes the type of market data that will be housed
        ''' </summary>
        ''' <param name="marketType">The type of data that resides within the object</param>
        ''' <remarks></remarks>
        Public Sub New(ByVal marketType As MarketDataType)
            _marketType = marketType
        End Sub

        ''' <summary>
        ''' The type of market data that resides within the object
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property MarketType() As MarketDataType
            Get
                Return _marketType
            End Get
            Set(ByVal value As MarketDataType)
                _marketType = value
            End Set
        End Property

        ''' <summary>
        ''' This is set if the data coming back from the market request is
        ''' price data
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property PriceData() As TickPriceData
            Get
                Return _tickPrice
            End Get
            Set(ByVal value As TickPriceData)
                _tickPrice = value
            End Set
        End Property

        ''' <summary>
        ''' This is set if the data coming back from the market request is size
        ''' data
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property SizeData() As TickSizeData
            Get
                Return _tickSize
            End Get
            Set(ByVal value As TickSizeData)
                _tickSize = value
            End Set
        End Property

        ''' <summary>
        ''' This is set if the data coming back from the market request is
        ''' computational data
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ComputationData() As TickComputationData
            Get
                Return _tickComputation
            End Get
            Set(ByVal value As TickComputationData)
                _tickComputation = value
            End Set
        End Property

        ''' <summary>
        ''' This is set if the data coming back from the market request is
        ''' generic data
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property GenericData() As TickGenericData
            Get
                Return _tickGeneric
            End Get
            Set(ByVal value As TickGenericData)
                _tickGeneric = value
            End Set
        End Property

        ''' <summary>
        ''' This is set if the data coming back from the market request is
        ''' string data
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property StringData() As TickStringData
            Get
                Return _tickString
            End Get
            Set(ByVal value As TickStringData)
                _tickString = value
            End Set
        End Property

        ''' <summary>
        ''' This is set if the data coming back from the market request is efp
        ''' data
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property EfpData() As TickEFPData
            Get
                Return _tickEfp
            End Get
            Set(ByVal value As TickEFPData)
                _tickEfp = value
            End Set
        End Property

    End Class

End Namespace