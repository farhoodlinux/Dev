﻿Namespace Data

    ''' <summary>
    ''' Houses data returned from the market "Efp" event
    ''' </summary>
    ''' <remarks></remarks>
    Public Class TickEFPData
        Implements IDataStructure

        Private _holdDays As Integer
        Private _requestID, _tickType As Long
        Private _basisPoints, _totalDividends As Double
        Private _dividendImpact, _dividendsToExpiry As Double
        Private _formattedBasisPoints, _futureExpiry As String

#Region " Class Properties "

        ''' <summary>
        ''' The id of the request from the API
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property RequestID() As Long
            Get
                Return _requestID
            End Get
            Set(ByVal value As Long)
                _requestID = value
            End Set
        End Property

        ''' <summary>
        ''' The type of data being returned
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property TickType() As Long
            Get
                Return _tickType
            End Get
            Set(ByVal value As Long)
                _tickType = value
            End Set
        End Property

        ''' <summary>
        ''' Definition required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property HoldDays() As Integer
            Get
                Return _holdDays
            End Get
            Set(ByVal value As Integer)
                _holdDays = value
            End Set
        End Property

        ''' <summary>
        ''' Definition required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property BasisPoints() As Double
            Get
                Return _basisPoints
            End Get
            Set(ByVal value As Double)
                _basisPoints = value
            End Set
        End Property

        ''' <summary>
        ''' Definition required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property TotalDividends() As Double
            Get
                Return _totalDividends
            End Get
            Set(ByVal value As Double)
                _totalDividends = value
            End Set
        End Property

        ''' <summary>
        ''' Definition required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property DividendImpact() As Double
            Get
                Return _dividendImpact
            End Get
            Set(ByVal value As Double)
                _dividendImpact = value
            End Set
        End Property

        ''' <summary>
        ''' Definition required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property DividendsToExpiry() As Double
            Get
                Return _dividendsToExpiry
            End Get
            Set(ByVal value As Double)
                _dividendsToExpiry = value
            End Set
        End Property

        ''' <summary>
        ''' Definition required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property FormattedBasisPoints() As String
            Get
                Return _formattedBasisPoints
            End Get
            Set(ByVal value As String)
                _formattedBasisPoints = value
            End Set
        End Property

        ''' <summary>
        ''' Definition required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property FutureExpiry() As String
            Get
                Return _futureExpiry
            End Get
            Set(ByVal value As String)
                _futureExpiry = value
            End Set
        End Property

#End Region

#Region " IDataStructure Implementation "

        ''' <summary>
        ''' Takes the tick efp event data object and uses that to load the
        ''' objects data
        ''' </summary>
        ''' <param name="data">The data to use to load the object</param>
        ''' <remarks></remarks>
        Public Sub LoadDataFromObject(ByVal data As Object) Implements IDataStructure.LoadDataFromObject
            If Not TypeOf (data) Is AxTWSLib._DTwsEvents_tickEFPEvent Then
                Throw New Exception(Messages.InvalidTypeMessage("LoadDataFromObject", "_DTwsEvents_tickEFPEvent"))
            End If

            Dim efpData As AxTWSLib._DTwsEvents_tickEFPEvent = data
            RequestID = efpData.tickerId
            TickType = efpData.field
            BasisPoints = efpData.basisPoints
            FormattedBasisPoints = efpData.formattedBasisPoints
            TotalDividends = efpData.totalDividends
            HoldDays = efpData.holdDays
            FutureExpiry = efpData.futureExpiry
            DividendImpact = efpData.dividendImpact
            DividendsToExpiry = efpData.dividendsToExpiry
        End Sub

        Public Sub RevertToTWSObject(ByRef data As Object) Implements IDataStructure.RevertToTWSObject

        End Sub

        Public Function ValidateData() As Boolean Implements IDataStructure.ValidateData
            Return True
        End Function

        Public ReadOnly Property ValidateErrorMessage() As String Implements IDataStructure.ValidateErrorMessage
            Get
                Return ""
            End Get
        End Property

#End Region

    End Class

End Namespace
