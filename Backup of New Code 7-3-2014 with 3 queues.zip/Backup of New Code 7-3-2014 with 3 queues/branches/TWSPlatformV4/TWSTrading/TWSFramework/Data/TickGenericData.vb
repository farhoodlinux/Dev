﻿Imports TWSFramework.Enums

Namespace Data

    ''' <summary>
    ''' Houses data returned from the market "generic" event
    ''' </summary>
    ''' <remarks></remarks>
    Public Class TickGenericData
        Implements IDataStructure

        Private _requestID As Long
        Private _value As Double

        Private _tickType As GenericTickType

#Region " Class Properties "

        ''' <summary>
        ''' The id of the request from the TWS API
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property RequestID() As Long
            Get
                Return _requestID
            End Get
            Set(ByVal value As Long)
                _requestID = value
            End Set
        End Property

        ''' <summary>
        ''' The value of the data returned from TWS
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Value() As Double
            Get
                Return _value
            End Get
            Set(ByVal value As Double)
                _value = value
            End Set
        End Property

        ''' <summary>
        ''' The type of data being returned
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property TickType() As GenericTickType
            Get
                Return _tickType
            End Get
            Set(ByVal value As GenericTickType)
                _tickType = value
            End Set
        End Property

#End Region

#Region " IDataStructure Implementation "

        ''' <summary>
        ''' Loads data from the tick generic event object into the class
        ''' </summary>
        ''' <param name="data">The data to load into the class</param>
        ''' <remarks></remarks>
        Public Sub LoadDataFromObject(ByVal data As Object) Implements IDataStructure.LoadDataFromObject
            If Not TypeOf (data) Is AxTWSLib._DTwsEvents_tickGenericEvent Then
                Throw New Exception(Messages.InvalidTypeMessage("LoadDataFromObject", "_DTwsEvents_tickGenericEvent"))
            End If

            Dim genericData As AxTWSLib._DTwsEvents_tickGenericEvent = data
            RequestID = genericData.id
            Value = genericData.value
            TickType = CType(genericData.tickType, GenericTickType)
        End Sub

        Public Sub RevertToTWSObject(ByRef data As Object) Implements IDataStructure.RevertToTWSObject

        End Sub

        Public Function ValidateData() As Boolean Implements IDataStructure.ValidateData
            Return True
        End Function

        Public ReadOnly Property ValidateErrorMessage() As String Implements IDataStructure.ValidateErrorMessage
            Get
                Return ""
            End Get
        End Property

#End Region

    End Class

End Namespace
