﻿Imports TWSFramework

Namespace Data
    ''' <summary>
    ''' Interface that defines the methods and properties that data object
    ''' will contain
    ''' </summary>
    ''' <remarks></remarks>
    Public Interface IDataStructure
        ''' <summary>
        ''' This property houses the error message if validation of the data
        ''' fails
        ''' </summary>
        ''' <value></value>
        ''' <returns>A string that houses the error message returned by a validation failure</returns>
        ''' <remarks>This is a read only property</remarks>
        ReadOnly Property ValidateErrorMessage() As String

        ''' <summary>
        ''' Performs the data validation for a particular data object
        ''' </summary>
        ''' <returns>A boolean indicating if the validation was successful</returns>
        ''' <remarks>If the validation failed then the ValidationErrorMessage property will be set</remarks>
        Function ValidateData() As Boolean

        ''' <summary>
        ''' Takes a TWS interface data object and loads our .Net data object
        ''' with that data
        ''' </summary>
        ''' <param name="data">The TWS interface object that contains the data</param>
        ''' <remarks></remarks>
        Sub LoadDataFromObject(ByVal data As Object)

        ''' <summary>
        ''' Takes the data in it's .Net form and changes back into it TWS API
        ''' form
        ''' </summary>
        ''' <remarks>
        ''' This method should be made internal to keep the user from being
        ''' able to call it; this should only be used by the framework itself
        ''' </remarks>
        Sub RevertToTWSObject(ByRef data As Object)
    End Interface

End Namespace