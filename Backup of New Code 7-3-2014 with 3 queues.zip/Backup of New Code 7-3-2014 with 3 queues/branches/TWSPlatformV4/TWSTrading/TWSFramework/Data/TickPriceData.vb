﻿Imports TWSFramework.Enums



Namespace Data

    ''' <summary>
    ''' Houses data returned from the market "Price" event
    ''' </summary>
    ''' <remarks></remarks>
    Public Class TickPriceData
        Implements IDataStructure

        Private _requestID As Long
        Private _price As Double
        Private _canAutoExecute As Boolean

        Private _tickType As PriceTickType

#Region " Class Properties "

        ''' <summary>
        ''' The id of the request to the TWS API
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property RequestID() As Long
            Get
                Return _requestID
            End Get
            Set(ByVal value As Long)
                _requestID = value
            End Set
        End Property

        ''' <summary>
        ''' The price returned from the system
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Price() As Double
            Get
                Return _price
            End Get
            Set(ByVal value As Double)
                _price = value
            End Set
        End Property

        ''' <summary>
        ''' Definition required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CanAutoExecute() As Boolean
            Get
                Return _canAutoExecute
            End Get
            Set(ByVal value As Boolean)
                _canAutoExecute = value
            End Set
        End Property

        ''' <summary>
        ''' Determines what type of price data has been returned
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property TickType() As PriceTickType
            Get
                Return _tickType
            End Get
            Set(ByVal value As PriceTickType)
                _tickType = value
            End Set
        End Property

#End Region

#Region " IDataStructure Implementation "

        ''' <summary>
        ''' Takes a tick price event object that houses data from the API and
        ''' loads the class with it
        ''' </summary>
        ''' <param name="data">The data object to load the classes data with</param>
        ''' <remarks></remarks>
        Public Sub LoadDataFromObject(ByVal data As Object) Implements IDataStructure.LoadDataFromObject
            If Not TypeOf (data) Is AxTWSLib._DTwsEvents_tickPriceEvent Then
                Throw New Exception(Messages.InvalidTypeMessage("LoadDataFromObject", "_DTwsEvents_tickPriceEvent"))
            End If

            Dim priceData As AxTWSLib._DTwsEvents_tickPriceEvent '= data
            priceData = CType(data, AxTWSLib._DTwsEvents_tickPriceEvent)

            RequestID = priceData.id
            Price = priceData.price
            CanAutoExecute = Utilities.ConvertIntToBool(priceData.canAutoExecute)
            TickType = CType(priceData.tickType, PriceTickType)
        End Sub

        Public Sub RevertToTWSObject(ByRef data As Object) Implements IDataStructure.RevertToTWSObject

        End Sub

        Public Function ValidateData() As Boolean Implements IDataStructure.ValidateData
            Return True
        End Function

        Public ReadOnly Property ValidateErrorMessage() As String Implements IDataStructure.ValidateErrorMessage
            Get
                Return ""
            End Get
        End Property

#End Region

    End Class

End Namespace
