﻿Imports TWSFramework.Enums

Namespace Data

    ''' <summary>
    ''' Houses data returned from the market "Size" event
    ''' </summary>
    ''' <remarks></remarks>
    Public Class TickSizeData
        Implements IDataStructure

        Private _requestID, _size As Long

        Private _tickType As SizeTickType

#Region " Public Properties "

        ''' <summary>
        ''' The id from the request to the TWS API
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property RequestID() As Long
            Get
                Return _requestID
            End Get
            Set(ByVal value As Long)
                _requestID = value
            End Set
        End Property

        ''' <summary>
        ''' The value returned from the call to the API
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Size() As Long
            Get
                Return _size
            End Get
            Set(ByVal value As Long)
                _size = value
            End Set
        End Property

        ''' <summary>
        ''' Determines the type of the value
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property TickType() As SizeTickType
            Get
                Return _tickType
            End Get
            Set(ByVal value As SizeTickType)
                _tickType = value
            End Set
        End Property

#End Region

#Region " IDataStructure Implementation "

        ''' <summary>
        ''' Takes a tick size event data object a loads the class with that
        ''' data
        ''' </summary>
        ''' <param name="data">The object used to load the class</param>
        ''' <remarks></remarks>
        Public Sub LoadDataFromObject(ByVal data As Object) Implements IDataStructure.LoadDataFromObject
            If Not TypeOf (data) Is AxTWSLib._DTwsEvents_tickSizeEvent Then
                Throw New Exception(Messages.InvalidTypeMessage("LoadDataFromObject", "_DTwsEvents_tickSizeEvent"))
            End If

            Dim sizeData As AxTWSLib._DTwsEvents_tickSizeEvent = data
            RequestID = sizeData.id
            Size = sizeData.size
            TickType = CType(sizeData.tickType, SizeTickType)
        End Sub

        Public Sub RevertToTWSObject(ByRef data As Object) Implements IDataStructure.RevertToTWSObject

        End Sub

        Public Function ValidateData() As Boolean Implements IDataStructure.ValidateData
            Return True
        End Function

        Public ReadOnly Property ValidateErrorMessage() As String Implements IDataStructure.ValidateErrorMessage
            Get
                Return ""
            End Get
        End Property

#End Region

    End Class

End Namespace