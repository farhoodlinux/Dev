﻿Imports TWSFramework.Enums

Namespace Data

    ''' <summary>
    ''' Houses data returned from the market "String" event
    ''' </summary>
    ''' <remarks></remarks>
    Public Class TickStringData
        Implements IDataStructure

        Private _requestID, _tickType As Long
        Private _value As String

#Region " Class Properties "

        ''' <summary>
        ''' The id of the request made to TWS
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property RequestID() As Long
            Get
                Return _requestID
            End Get
            Set(ByVal value As Long)
                _requestID = value
            End Set
        End Property

        ''' <summary>
        ''' The value returned from the API
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Value() As String
            Get
                Return _value
            End Get
            Set(ByVal value As String)
                _value = value
            End Set
        End Property

        ''' <summary>
        ''' Determines what type of value has been returned
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property TickType() As Long
            Get
                Return _tickType
            End Get
            Set(ByVal value As Long)
                _tickType = value
            End Set
        End Property

#End Region

#Region " IDataStructure Implementation "

        ''' <summary>
        ''' Takes a tick string Event object and loads the data in the class
        ''' with it
        ''' </summary>
        ''' <param name="data">The data object to use when loading data</param>
        ''' <remarks></remarks>
        Public Sub LoadDataFromObject(ByVal data As Object) Implements IDataStructure.LoadDataFromObject
            If Not TypeOf (data) Is AxTWSLib._DTwsEvents_tickStringEvent Then
                Throw New Exception(Messages.InvalidTypeMessage("LoadDataFromObject", "_DTwsEvents_tickStringEvent"))
            End If

            Dim stringData As AxTWSLib._DTwsEvents_tickStringEvent = data
            RequestID = stringData.id
            Value = stringData.value
            TickType = stringData.tickType
        End Sub

        Public Sub RevertToTWSObject(ByRef data As Object) Implements IDataStructure.RevertToTWSObject

        End Sub

        Public Function ValidateData() As Boolean Implements IDataStructure.ValidateData
            Return True
        End Function

        Public ReadOnly Property ValidateErrorMessage() As String Implements IDataStructure.ValidateErrorMessage
            Get
                Return ""
            End Get
        End Property

#End Region

    End Class

End Namespace