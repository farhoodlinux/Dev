﻿Imports TWSFramework.Enums

Namespace Data

    ''' <summary>
    ''' Houses data returned from the market "Computation" event
    ''' </summary>
    ''' <remarks></remarks>
    Public Class TickComputationData
        Implements IDataStructure

        Private _requestID As Long
        Private _impliedVolume, _modelPrice, _delta, _pvDividend As Double

        Private _tickType As ComputationTickType

#Region " Class Properties "

        ''' <summary>
        ''' The id of the request to the TWS API
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property RequestID() As Long
            Get
                Return _requestID
            End Get
            Set(ByVal value As Long)
                _requestID = value
            End Set
        End Property

        ''' <summary>
        ''' Definition required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ImpliedVolume() As Double
            Get
                Return _impliedVolume
            End Get
            Set(ByVal value As Double)
                _impliedVolume = value
            End Set
        End Property

        ''' <summary>
        ''' Definition required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ModelPrice() As Double
            Get
                Return _modelPrice
            End Get
            Set(ByVal value As Double)
                _modelPrice = value
            End Set
        End Property

        ''' <summary>
        ''' Definition required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Delta() As Double
            Get
                Return _delta
            End Get
            Set(ByVal value As Double)
                _delta = value
            End Set
        End Property

        ''' <summary>
        ''' Definition required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property PVDividend() As Double
            Get
                Return _pvDividend
            End Get
            Set(ByVal value As Double)
                _pvDividend = value
            End Set
        End Property

        ''' <summary>
        ''' The type of data that is being sent
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property TickType() As ComputationTickType
            Get
                Return _tickType
            End Get
            Set(ByVal value As ComputationTickType)
                _tickType = value
            End Set
        End Property

#End Region

#Region " IDataStructure Implementation "

        ''' <summary>
        ''' Takes a tick option computation event object and load the class
        ''' with the data contained within
        ''' </summary>
        ''' <param name="data">The data to use to load the class with</param>
        ''' <remarks></remarks>
        Public Sub LoadDataFromObject(ByVal data As Object) Implements IDataStructure.LoadDataFromObject
            If Not TypeOf (data) Is AxTWSLib._DTwsEvents_tickOptionComputationEvent Then
                Throw New Exception(Messages.InvalidTypeMessage("LoadDataFromObject", "_DTwsEvents_tickOptionComputationEvent"))
            End If

            Dim computationData As AxTWSLib._DTwsEvents_tickOptionComputationEvent = data
            RequestID = computationData.id
            ImpliedVolume = computationData.impliedVol
            ModelPrice = computationData.modelPrice
            Delta = computationData.delta
            PVDividend = computationData.pvDividend
            TickType = CType(computationData.tickType, ComputationTickType)
        End Sub

        Public Sub RevertToTWSObject(ByRef data As Object) Implements IDataStructure.RevertToTWSObject

        End Sub

        Public Function ValidateData() As Boolean Implements IDataStructure.ValidateData
            Return True
        End Function

        Public ReadOnly Property ValidateErrorMessage() As String Implements IDataStructure.ValidateErrorMessage
            Get
                Return ""
            End Get
        End Property

#End Region

    End Class

End Namespace
