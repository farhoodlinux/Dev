﻿''' <summary>
''' This class will contain messages that will be displayed throughout the
''' framework
''' </summary>
''' <remarks></remarks>
Friend Class Messages

    Private Const INVALID_TYPE_MESSAGE As String = "Error in {0}: The object passed to this method must be of type {1}"

    ''' <summary>
    ''' This message is the "Invalid Type Passed to Method" message
    ''' </summary>
    ''' <param name="methodName">The method the message is sent from</param>
    ''' <param name="methodType">The type that should have been passed</param>
    ''' <returns>A message string to be displayed</returns>
    ''' <remarks></remarks>
    Friend Shared Function InvalidTypeMessage(ByVal methodName As String, ByVal methodType As String) As String
        Return String.Format(INVALID_TYPE_MESSAGE, methodName, methodType)
    End Function
End Class
