Imports TWSFramework.Data

Public Class TWSComponent
    Private Shared TWSForm As TWSComponent
    Private MktMgr As MarketManager
    Private ErrManager As ErrorManager
    Private _NextValidID As Integer


    ''' <summary>
    ''' 
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetNextValidID() As Integer
        Dim res As Integer
        res = Me._NextValidID
        Me._NextValidID = Me._NextValidID + 1

        Return res
    End Function


    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="X"></param>
    ''' <remarks></remarks>
    Public Sub SetMarketManager(ByVal X As MarketManager)

        MktMgr = X

    End Sub


    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="X"></param>
    ''' <remarks></remarks>
    Public Sub SetErrormanager(ByVal X As ErrorManager)

        ErrManager = X

    End Sub

    Private Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Public Shared Function getinstance() As TWSComponent

        If TWSForm Is Nothing Then
            TWSForm = New TWSComponent
        End If

        Return TWSForm

    End Function

    Private Sub AxTws1_connectionClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles AxTws1.connectionClosed
        'TODO:  This event raised after connection with TWS client was closed
    End Sub


    ''' <summary>
    ''' Returns the next valid order id upon connection - triggered by the connect() and
    ''' reqNextValidId() methods
    ''' </summary>
    ''' <param name="eventSender"></param>
    ''' <param name="eventArgs"></param>
    ''' <remarks></remarks>
    Private Sub Tws1_nextValidId(ByVal eventSender As System.Object, ByVal eventArgs As AxTWSLib._DTwsEvents_nextValidIdEvent) Handles AxTws1.nextValidId
        If eventArgs.id > _NextValidID Then
            _NextValidID = eventArgs.id
        Else
            _NextValidID = _NextValidID + 10
        End If

    End Sub


    ''' <summary>
    ''' Handles AxTws1.scannerDataEx and call MktMgr.APIScannerData to process data
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub AxTws1_scannerDataEx(ByVal sender As System.Object, ByVal e As AxTWSLib._DTwsEvents_scannerDataExEvent) Handles AxTws1.scannerDataEx

        'TODO:  see if new thread can be used for processing
        MktMgr.APIScannerData(e)

    End Sub

    ''' <summary>
    ''' Handles AxTws1.scannerDataEnd and call  MktMgr.APIScannerDataEnd to process data
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub AxTws1_scannerDataEnd(ByVal sender As Object, ByVal e As AxTWSLib._DTwsEvents_scannerDataEndEvent) Handles AxTws1.scannerDataEnd

        'TODO:  see if new thread can be used for processing
        MktMgr.APIScannerDataEnd(e)

    End Sub


    Private Sub TWSComponent_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub


    Private Sub AxTws1_errMsg(ByVal sender As System.Object, ByVal e As AxTWSLib._DTwsEvents_errMsgEvent) Handles AxTws1.errMsg

        Dim _errordata As New ErrorData
        _errordata.LoadDataFromObject(e)
        ErrManager.APIErrorData(_errordata)

    End Sub

#Region " Market Data Events "

    Private Sub AxTws1_tickEFP(ByVal sender As System.Object, ByVal e As AxTWSLib._DTwsEvents_tickEFPEvent) Handles AxTws1.tickEFP

    End Sub

    Private Sub AxTws1_tickGeneric(ByVal sender As System.Object, ByVal e As AxTWSLib._DTwsEvents_tickGenericEvent) Handles AxTws1.tickGeneric

    End Sub

    Private Sub AxTws1_tickOptionComputation(ByVal sender As System.Object, ByVal e As AxTWSLib._DTwsEvents_tickOptionComputationEvent) Handles AxTws1.tickOptionComputation

    End Sub

    Private Sub AxTws1_tickPrice(ByVal sender As System.Object, ByVal e As AxTWSLib._DTwsEvents_tickPriceEvent) Handles AxTws1.tickPrice

    End Sub

    Private Sub AxTws1_tickSize(ByVal sender As System.Object, ByVal e As AxTWSLib._DTwsEvents_tickSizeEvent) Handles AxTws1.tickSize

    End Sub

    Private Sub AxTws1_tickString(ByVal sender As System.Object, ByVal e As AxTWSLib._DTwsEvents_tickStringEvent) Handles AxTws1.tickString

    End Sub

#End Region

End Class