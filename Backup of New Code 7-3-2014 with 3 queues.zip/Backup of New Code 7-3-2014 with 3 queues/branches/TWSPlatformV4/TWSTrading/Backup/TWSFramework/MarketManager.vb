Imports TWSFramework.Data
Imports TWSFramework.Events

Public Class MarketManager
    Private _TWSForm As TWSComponent

    ''' <summary>list of buffers for registered scanners</summary>
    Private _buffers As Dictionary(Of Integer, ScannerBuffer)

    Public RegistredScanres As Dictionary(Of Integer, ScannerBuffer) 'TODO: replace string with real type of scanner


    Public Sub New()
        _TWSForm = TWSComponent.getinstance
        _TWSForm.SetMarketManager(Me)
        _buffers = New Dictionary(Of Integer, ScannerBuffer)

        RegistredScanres = New Dictionary(Of Integer, ScannerBuffer) 'TODO: replace string with real type of scanner
    End Sub


#Region "TWS Connection related code ...  "

    ''' <summary>
    ''' Connects to the TWS API
    ''' </summary>
    ''' <param name="host">The host to connect to</param>
    ''' <param name="port">The port to connect to the host on</param>
    ''' <param name="clientID">The id of the client that is connecting</param>
    ''' <remarks></remarks>
    Public Sub Connect(ByVal host As String, ByVal port As Integer, ByVal clientID As Integer)
        'Check if already connected
        If _TWSForm.AxTws1.serverVersion <= 0 Then
            'If not connected yet, connect
            _TWSForm.AxTws1.connect(host, port, clientID)
        End If
    End Sub




    ''' <summary>
    ''' Disconnects from the TWS API
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Disconnect()
        'Check if there still exist open scanners
        'TODO Close all open scanners

        'Disconect from client
        _TWSForm.AxTws1.disconnect()
    End Sub

#End Region



#Region "TWS scanners related code ...  "

    ''' <summary>
    ''' Starts the scanner looking for securities that meet the criteria of the
    ''' ScannerSubscription
    ''' object this method also specifies how many records should be returned
    ''' before the scanner event fires
    ''' </summary>
    ''' <param name="scanner">The ScannerSubscription object that defines what securities to search for</param>
    '''   ''' <returns>An integer that represents the request id used for the scan</returns>
    ''' <remarks></remarks>
    Public Function ScanSecurities(ByVal scanner As scannersubscription) As Integer
        Dim newRequestID As Integer
        Dim twsScanner As TWSLib.IScannerSubscription

        'Get new request ID
        newRequestID = _TWSForm.GetNextValidID

        'Add new buffer
        _buffers.Add(newRequestID, New ScannerBuffer)
        RegistredScanres.Add(newRequestID, New ScannerBuffer)
        RegistredScanres(newRequestID).RequestID = newRequestID

        'Create new request
        twsScanner = _TWSForm.AxTws1.createScannerSubscription()

        'set request parameters
        scanner.RevertToTWSObject(twsScanner)

        'request 
        _TWSForm.AxTws1.reqScannerSubscriptionEx(newRequestID, twsScanner)


        'set MaxSize of the buffer to number of requested rows
        _buffers(newRequestID).MaxSize = scanner.NumberOfRows

        Return newRequestID
    End Function




    ''' <summary>
    ''' This sub called from AxTws1.scannerDataEx handler.
    ''' Mark Scanner buffer as full, copy data to Scanners, 
    ''' and raise event to indicated that scanner has new data   
    ''' </summary>
    ''' <param name="pEventArgs"></param>
    ''' <remarks></remarks>
    Friend Sub APIScannerDataEnd(ByVal pEventArgs As AxTWSLib._DTwsEvents_scannerDataEndEvent)
        If (_buffers(pEventArgs.reqId) Is Nothing) Then
            'TODO: raise error here  -  buffer must exist for registered scanner
        Else
            If (_buffers(pEventArgs.reqId).Size <> _buffers(pEventArgs.reqId).MaxSize) Then
                'TODO: raise error here  -  for some reason buffer has a wrong size
            Else
                'try to see if it works 
                _buffers(pEventArgs.reqId).IsReady = True
                RegistredScanres(pEventArgs.reqId).SetData(_buffers(pEventArgs.reqId))
                _buffers(pEventArgs.reqId).Clear()

                Dim ScanEvent As New ScannerDataEventArgs(RegistredScanres(pEventArgs.reqId))
                RaiseEvent ScannerDataEvent(Me, ScanEvent)

            End If
        End If
    End Sub




    ''' <summary>
    ''' This sub called from AxTws1.scannerDataEx handler
    ''' </summary>
    ''' <param name="pEventArgs"></param>
    ''' <remarks></remarks>
    Friend Sub APIScannerData(ByVal pEventArgs As AxTWSLib._DTwsEvents_scannerDataExEvent)
        Dim scanData As New ScannerData()

        If (_buffers(pEventArgs.reqId) Is Nothing) Then
            'TODO: raise error here  -  buffer must exist for registered scanner
        Else
            If (_buffers(pEventArgs.reqId).Size + 1 > _buffers(pEventArgs.reqId).MaxSize) Then
                'TODO: raise error here  -  for some reason buffer is too small
                '    _buffers(pEventArgs.reqId).IsReady = True
                '    RegistredScanres(pEventArgs.reqId) = _buffers(pEventArgs.reqId)

                '    Dim ScanEvent As New ScannerDataEventArgs(_buffers(pEventArgs.reqId))
                '    RaiseEvent ScannerDataEvent(Me, ScanEvent)

                '    _buffers(pEventArgs.reqId).Clear()
            Else
                scanData.LoadDataFromObject(pEventArgs)
                _buffers(pEventArgs.reqId).AddData(scanData)
            End If
        End If

        'mktDataStr = "id=" & EventArgs.reqId & " rank=" & EventArgs.rank & " conId=" & Contract.ConID & _
        '             " symbol=" & Contract.Symbol & " secType=" & Contract.SecType & " currency=" & Contract.Currency & _
        '             " localSymbol=" & Contract.LocalSymbol & " marketName=" & ContractDetails.MarketName & _
        '             " tradingClass=" & ContractDetails.TradingClass & " distance=" & EventArgs.distance & _
        '             " benchmark=" & EventArgs.benchmark & " projection=" & EventArgs.projection & _
        '             " legsStr=" & EventArgs.legsStr
    End Sub

#End Region



#Region "Events "
    Public Event ScannerDataEvent As ScannerDataReturned

#End Region



End Class
