Imports TWSFramework.Enums
Namespace Data

    ''' <summary>
    ''' This class has flattened the data from the ScannerData object so that
    ''' all of it can be view in a data display object
    ''' </summary>
    ''' <remarks></remarks>
    Public Class ScannerFlatData

#Region " Member Data "

        Private _requestID, _rank As Integer
        Private _distance, _benchmark, _projection, _legsStr As String

        ' Contract Details Data
        Private _marketName, _tradingClass, _orderTypes, _validExchanges As String
        Private _cusip, _ratings, _descAppend, _bondType, _couponType As String
        Private _maturity, _issueDate, _nextOptionDate, _nextOptionType As String
        Private _notes As String
        Private _priceMagnifier As Integer
        Private _minTick, _coupon As Double
        Private _callable, _putable, _convertible, _nextOptionPartial As Boolean

        'Contract Data
        Private _symbol, _expiry, _right, _multiplier, _exchange As String
        Private _currency, _localSymbol, _primaryExch, _comboLegsDescrip As String
        Private _secType As String
        Private _conID As Integer
        Private _strike As Double
        Private _includeExpired As Boolean
        Private _comboLegs As Object

        'My Data
        Private _scannertype As ScanCodeType
        Private _No_Times_In_List As Integer
        Private _Scanner_list As String


#End Region

#Region " Constructor Methods "

        Public Sub New()

        End Sub

        ''' <summary>
        ''' This constructor passes the ScannerData object to flatten
        ''' </summary>
        ''' <param name="scanner"></param>
        ''' <remarks></remarks>
        Public Sub New(ByVal scanner As ScannerData)
            FlattenDataObject(scanner)
        End Sub

#End Region

#Region " Public Properties "

        Public Property RequestID() As Integer
            Get
                Return _requestID
            End Get
            Set(ByVal value As Integer)
                _requestID = value
            End Set
        End Property

        Public Property Rank() As Integer
            Get
                Return _rank
            End Get
            Set(ByVal value As Integer)
                _rank = value
            End Set
        End Property

        Public Property Distance() As String
            Get
                Return _distance
            End Get
            Set(ByVal value As String)
                _distance = value
            End Set
        End Property

        Public Property Benchmark() As String
            Get
                Return _benchmark
            End Get
            Set(ByVal value As String)
                _benchmark = value
            End Set
        End Property

        Public Property Projection() As String
            Get
                Return _projection
            End Get
            Set(ByVal value As String)
                _projection = value
            End Set
        End Property

        Public Property LegsStr() As String
            Get
                Return _legsStr
            End Get
            Set(ByVal value As String)
                _legsStr = value
            End Set
        End Property

        Public Property MarketName() As String
            Get
                Return _marketName
            End Get
            Set(ByVal value As String)
                _marketName = value
            End Set
        End Property

        Public Property TradingClass() As String
            Get
                Return _tradingClass
            End Get
            Set(ByVal value As String)
                _tradingClass = value
            End Set
        End Property

        Public Property OrderTypes() As String
            Get
                Return _orderTypes
            End Get
            Set(ByVal value As String)
                _orderTypes = value
            End Set
        End Property

        Public Property ValidExchanges() As String
            Get
                Return _validExchanges
            End Get
            Set(ByVal value As String)
                _validExchanges = value
            End Set
        End Property

        Public Property Cusip() As String
            Get
                Return _cusip
            End Get
            Set(ByVal value As String)
                _cusip = value
            End Set
        End Property

        Public Property Ratings() As String
            Get
                Return _ratings
            End Get
            Set(ByVal value As String)
                _ratings = value
            End Set
        End Property

        Public Property DescAppend() As String
            Get
                Return _descAppend
            End Get
            Set(ByVal value As String)
                _descAppend = value
            End Set
        End Property

        Public Property BondType() As String
            Get
                Return _bondType
            End Get
            Set(ByVal value As String)
                _bondType = value
            End Set
        End Property

        Public Property CouponType() As String
            Get
                Return _couponType
            End Get
            Set(ByVal value As String)
                _couponType = value
            End Set
        End Property

        Public Property Maturity() As String
            Get
                Return _maturity
            End Get
            Set(ByVal value As String)
                _maturity = value
            End Set
        End Property

        Public Property IssueDate() As String
            Get
                Return _issueDate
            End Get
            Set(ByVal value As String)
                _issueDate = value
            End Set
        End Property

        Public Property NextOptionDate() As String
            Get
                Return _nextOptionDate
            End Get
            Set(ByVal value As String)
                _nextOptionDate = value
            End Set
        End Property

        Public Property NextOptionType() As String
            Get
                Return _nextOptionType
            End Get
            Set(ByVal value As String)
                _nextOptionType = value
            End Set
        End Property

        Public Property Notes() As String
            Get
                Return _notes
            End Get
            Set(ByVal value As String)
                _notes = value
            End Set
        End Property

        Public Property PriceMagnifier() As Integer
            Get
                Return _priceMagnifier
            End Get
            Set(ByVal value As Integer)
                _priceMagnifier = value
            End Set
        End Property

        Public Property MinTick() As Double
            Get
                Return _minTick
            End Get
            Set(ByVal value As Double)
                _minTick = value
            End Set
        End Property

        Public Property Coupon() As Double
            Get
                Return _coupon
            End Get
            Set(ByVal value As Double)
                _coupon = value
            End Set
        End Property

        Public Property Callable() As Boolean
            Get
                Return _callable
            End Get
            Set(ByVal value As Boolean)
                _callable = value
            End Set
        End Property

        Public Property Putable() As Boolean
            Get
                Return _putable
            End Get
            Set(ByVal value As Boolean)
                _putable = value
            End Set
        End Property

        Public Property Convertible() As Boolean
            Get
                Return _convertible
            End Get
            Set(ByVal value As Boolean)
                _convertible = value
            End Set
        End Property

        Public Property NextOptionPartial() As Boolean
            Get
                Return _nextOptionPartial
            End Get
            Set(ByVal value As Boolean)
                _nextOptionPartial = value
            End Set
        End Property

        Public Property Symbol() As String
            Get
                Return _symbol
            End Get
            Set(ByVal value As String)
                _symbol = value
            End Set
        End Property

        Public Property Expiry() As String
            Get
                Return _expiry
            End Get
            Set(ByVal value As String)
                _expiry = value
            End Set
        End Property

        Public Property Right() As String
            Get
                Return _right
            End Get
            Set(ByVal value As String)
                _right = value
            End Set
        End Property

        Public Property Multiplier() As String
            Get
                Return _multiplier
            End Get
            Set(ByVal value As String)
                _multiplier = value
            End Set
        End Property

        Public Property Exchange() As String
            Get
                Return _exchange
            End Get
            Set(ByVal value As String)
                _exchange = value
            End Set
        End Property

        Public Property Currency() As String
            Get
                Return _currency
            End Get
            Set(ByVal value As String)
                _currency = value
            End Set
        End Property

        Public Property LocalSymbol() As String
            Get
                Return _localSymbol
            End Get
            Set(ByVal value As String)
                _localSymbol = value
            End Set
        End Property

        Public Property PrimaryExch() As String
            Get
                Return _primaryExch
            End Get
            Set(ByVal value As String)
                _primaryExch = value
            End Set
        End Property

        Public Property ComboLegsDescrip() As String
            Get
                Return _comboLegsDescrip
            End Get
            Set(ByVal value As String)
                _comboLegsDescrip = value
            End Set
        End Property

        Public Property SecType() As String
            Get
                Return _secType
            End Get
            Set(ByVal value As String)
                _secType = value
            End Set
        End Property

        Public Property ConID() As Integer
            Get
                Return _conID
            End Get
            Set(ByVal value As Integer)
                _conID = value
            End Set
        End Property

        Public Property Strike() As Double
            Get
                Return _strike
            End Get
            Set(ByVal value As Double)
                _strike = value
            End Set
        End Property

        Public Property IncludeExpired() As Boolean
            Get
                Return _includeExpired
            End Get
            Set(ByVal value As Boolean)
                _includeExpired = value
            End Set
        End Property

        Public Property ComboLegs() As Object
            Get
                Return _comboLegs
            End Get
            Set(ByVal value As Object)
                _comboLegs = value
            End Set
        End Property
        Public Property scannertype() As ScanCodeType
            Get
                Return _scannertype
            End Get
            Set(ByVal value As ScanCodeType)
                _scannertype = value
            End Set
        End Property
        Public Property No_Times_In_List() As Integer
            Get
                Return _No_Times_In_List
            End Get
            Set(ByVal value As Integer)
                _No_Times_In_List = value
            End Set
        End Property
        Public Property Scanner_List() As String
            Get
                Return _Scanner_list
            End Get
            Set(ByVal value As String)
                _Scanner_list = value
            End Set
        End Property

#End Region

#Region " Public Methods "

        ''' <summary>
        ''' Removes the data from objects contained within the ScannerData
        ''' object and stores it in a flat format
        ''' </summary>
        ''' <param name="scanner">The data object to flatten</param>
        ''' <remarks>Flattening refers to the act of removing data stored in object and storing them all in one object</remarks>
        Public Sub FlattenDataObject(ByVal scanner As ScannerData)
            RequestID = scanner.RequestID
            Rank = scanner.Rank
            Distance = scanner.Distance
            Benchmark = scanner.Benchmark
            Projection = scanner.Projection
            LegsStr = scanner.LegsStr

            'Contract Details Data
            MarketName = scanner.ContractDetails.MarketName
            TradingClass = scanner.ContractDetails.TradingClass
            OrderTypes = scanner.ContractDetails.OrderTypes
            ValidExchanges = scanner.ContractDetails.ValidExchanges
            Cusip = scanner.ContractDetails.Cusip
            Ratings = scanner.ContractDetails.Ratings
            DescAppend = scanner.ContractDetails.DescAppend
            BondType = scanner.ContractDetails.BondType
            CouponType = scanner.ContractDetails.CouponType
            Maturity = scanner.ContractDetails.Maturity
            IssueDate = scanner.ContractDetails.IssueDate
            NextOptionDate = scanner.ContractDetails.NextOptionDate
            NextOptionType = scanner.ContractDetails.NextOptionType
            Notes = scanner.ContractDetails.Notes
            PriceMagnifier = scanner.ContractDetails.PriceMagnifier
            MinTick = scanner.ContractDetails.MinTick
            Coupon = scanner.ContractDetails.Coupon
            Callable = scanner.ContractDetails.Callable
            Putable = scanner.ContractDetails.Putable
            Convertible = scanner.ContractDetails.Convertible
            NextOptionPartial = scanner.ContractDetails.NextOptionPartial

            'Contract Data
            Symbol = scanner.ContractDetails.Summary.Symbol
            Expiry = scanner.ContractDetails.Summary.Expiry
            Right = scanner.ContractDetails.Summary.Right
            Multiplier = scanner.ContractDetails.Summary.Multiplier
            Exchange = scanner.ContractDetails.Summary.Exchange
            Currency = scanner.ContractDetails.Summary.Currency
            LocalSymbol = scanner.ContractDetails.Summary.LocalSymbol
            PrimaryExch = scanner.ContractDetails.Summary.PrimaryExch
            ComboLegsDescrip = scanner.ContractDetails.Summary.ComboLegsDescrip
            SecType = CStr(scanner.ContractDetails.Summary.SecType)
            ConID = scanner.ContractDetails.Summary.ConID
            Strike = scanner.ContractDetails.Summary.Strike
            IncludeExpired = scanner.ContractDetails.Summary.IncludeExpired
            ComboLegs = scanner.ContractDetails.Summary.ComboLegs
        End Sub

#End Region

    End Class
End Namespace
