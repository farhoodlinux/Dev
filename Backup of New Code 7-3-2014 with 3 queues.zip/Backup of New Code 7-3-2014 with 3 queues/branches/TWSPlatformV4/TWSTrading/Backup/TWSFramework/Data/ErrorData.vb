Namespace Data

    Public Class ErrorData


        Private _requestID, _errorCode As Integer
        Private _errorMessage, _validateErrorMessage As String

        ''' <summary>
        ''' The id of the request that returned an error
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property RequestID() As Integer
            Get
                Return _requestID
            End Get
            Set(ByVal value As Integer)
                _requestID = value
            End Set
        End Property

        ''' <summary>
        ''' The error code returned from TWS
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ErrorCode() As Integer
            Get
                Return _errorCode
            End Get
            Set(ByVal value As Integer)
                _errorCode = value
            End Set
        End Property

        ''' <summary>
        ''' The error message returned from TWS
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ErrorMessage() As String
            Get
                Return _errorMessage
            End Get
            Set(ByVal value As String)
                _errorMessage = value
            End Set
        End Property

        ''' <summary>
        ''' Loads the class with data from a TWS API interface data object
        ''' </summary>
        ''' <param name="data">The _DTwsEvents_errMsgEvent object that contains the data to load</param>
        ''' <remarks></remarks>
        Public Sub LoadDataFromObject(ByVal data As AxTWSLib._DTwsEvents_errMsgEvent)

            RequestID = data.id
            ErrorCode = data.errorCode
            ErrorMessage = data.errorMsg

        End Sub

        Public Function ErrFormat() As String

            Return "requestID  " & RequestID.ToString & "  ErrorCode " & ErrorCode.ToString & "  " & ErrorMessage

        End Function


    End Class

End Namespace

