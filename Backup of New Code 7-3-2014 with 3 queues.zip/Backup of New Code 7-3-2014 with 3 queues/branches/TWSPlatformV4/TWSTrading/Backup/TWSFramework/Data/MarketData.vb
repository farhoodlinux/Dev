Imports TWSFramework.Enums

Public Class MarketData
    Private _tickerID, _tickSize As Integer
    Private _tickPrice As Decimal
    Private _tickValue As String
    Private _canAutoExecute As Boolean

    Private _priceTickType As PriceTickType
    Private _sizeTickType As SizeTickType
    Private _genericTickType As GenericTickType
    Private _marketDataType As MarketDataType

#Region " Class Properties "

    Public Property TickerID() As Integer
        Get
            Return _tickerID
        End Get
        Set(ByVal value As Integer)
            _tickerID = value
        End Set
    End Property

    Public Property TickSize() As Integer
        Get
            Return _tickSize
        End Get
        Set(ByVal value As Integer)
            _tickSize = value
        End Set
    End Property

    Public Property TickPrice() As Decimal
        Get
            Return _tickPrice
        End Get
        Set(ByVal value As Decimal)
            _tickPrice = value
        End Set
    End Property

    Public Property TickValue() As String
        Get
            Return _tickValue
        End Get
        Set(ByVal value As String)
            _tickValue = value
        End Set
    End Property

    Public Property CanAutoExecute() As Boolean
        Get
            Return _canAutoExecute
        End Get
        Set(ByVal value As Boolean)
            _canAutoExecute = value
        End Set
    End Property

    Public Property PriceTickType() As PriceTickType
        Get
            Return _priceTickType
        End Get
        Set(ByVal value As PriceTickType)
            _priceTickType = value
        End Set
    End Property

    Public Property SizeTickType() As SizeTickType
        Get
            Return _sizeTickType
        End Get
        Set(ByVal value As SizeTickType)
            _sizeTickType = value
        End Set
    End Property

    Public Property GenericTickType() As GenericTickType
        Get
            Return _genericTickType
        End Get
        Set(ByVal value As GenericTickType)
            _genericTickType = value
        End Set
    End Property

    Public Property MarketDataType() As MarketDataType
        Get
            Return _marketDataType
        End Get
        Set(ByVal value As MarketDataType)
            _marketDataType = value
        End Set
    End Property

#End Region


End Class
