Imports TWSFramework.Enums
Namespace Data

    Public Class ScannerData


#Region " Member Variables "

        Private _validateErrorMessage, _distance, _benchmark, _projection As String
        Private _legsStr As String
        Private _requestID, _rank As Integer

        Private _conDetails As ContractDetails

#End Region

#Region " Class Constructors "

        ''' <summary>
        ''' The default constructor initializes member variables
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()
            _validateErrorMessage = ""
        End Sub

#End Region

#Region " Class Properties "

        ''' <summary>
        ''' The id of the transaction submitted to the TWS API
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property RequestID() As Integer
            Get
                Return _requestID
            End Get
            Set(ByVal value As Integer)
                _requestID = value
            End Set
        End Property

        ''' <summary>
        ''' The order that this item should be displayed in a list
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Rank() As Integer
            Get
                Return _rank
            End Get
            Set(ByVal value As Integer)
                _rank = value
            End Set
        End Property

        ''' <summary>
        ''' ''' object that houses all of the information about the security
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ContractDetails() As ContractDetails
            Get
                Return _conDetails
            End Get
            Set(ByVal value As ContractDetails)
                _conDetails = value
            End Set
        End Property

        ''' <summary>
        ''' Explaination required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Distance() As String
            Get
                Return _distance
            End Get
            Set(ByVal value As String)
                _distance = value
            End Set
        End Property

        ''' <summary>
        ''' Explaination required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Benchmark() As String
            Get
                Return _benchmark
            End Get
            Set(ByVal value As String)
                _benchmark = value
            End Set
        End Property

        ''' <summary>
        ''' Explaination required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Projection() As String
            Get
                Return _projection
            End Get
            Set(ByVal value As String)
                _projection = value
            End Set
        End Property

        ''' <summary>
        ''' Describes the combo legs when the scan is returning EFP
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property LegsStr() As String
            Get
                Return _legsStr
            End Get
            Set(ByVal value As String)
                _legsStr = value
            End Set
        End Property

#End Region

#Region " Class Methods "

        Public Function GetFlattenedData() As ScannerFlatData
            Dim data As New ScannerFlatData(Me)
            Return data
        End Function

#End Region

#Region " Load Data"


        Friend Sub LoadDataFromObject(ByVal scandata As AxTWSLib._DTwsEvents_scannerDataExEvent)


            Dim conDetails As New ContractDetails()
            conDetails.LoadDataFromObject(scandata.contractDetails)

            RequestID = scandata.reqId
            Rank = scandata.rank
            ContractDetails = conDetails
            Distance = scandata.distance
            Benchmark = scandata.benchmark
            Projection = scandata.projection
            LegsStr = scandata.legsStr


            'mktDataStr = "id=" & EventArgs.reqId & " rank=" & EventArgs.rank & " conId=" & Contract.ConID & _
            '             " symbol=" & Contract.Symbol & " secType=" & Contract.SecType & " currency=" & Contract.Currency & _
            '             " localSymbol=" & Contract.LocalSymbol & " marketName=" & ContractDetails.MarketName & _
            '             " tradingClass=" & ContractDetails.TradingClass & " distance=" & EventArgs.distance & _
            '             " benchmark=" & EventArgs.benchmark & " projection=" & EventArgs.projection & _
            '             " legsStr=" & EventArgs.legsStr

        End Sub



#End Region

    End Class

End Namespace
