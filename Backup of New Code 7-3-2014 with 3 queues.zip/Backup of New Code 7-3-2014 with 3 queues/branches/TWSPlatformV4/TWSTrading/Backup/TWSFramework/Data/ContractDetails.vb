Namespace Data
    Public Class ContractDetails

#Region " Member Variables "

        Private _priceMagnifier As Integer
        Private _minTick, _coupon As Double
        Private _marketName, _tradingClass, _orderTypes, _validExchanges As String
        Private _cusip, _ratings, _descAppend, _bondType, _couponType As String
        Private _maturity, _issueDate, _nextOptionDate, _nextOptionType As String
        Private _notes, _validateErrorMessage As String
        Private _callable, _putable, _convertible, _nextOptionPartial As Boolean

        Private _summary As Contract

#End Region

#Region " Class Constructors "

        ''' <summary>
        ''' The default constructor sets some member variables
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()
            _validateErrorMessage = ""
        End Sub

#End Region

#Region " Class Properties "

        ''' <summary>
        ''' Houses the contract object that contains data specific to this
        ''' security
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Summary() As Contract
            Get
                Return _summary
            End Get
            Set(ByVal value As Contract)
                _summary = value
            End Set
        End Property

        ''' <summary>
        ''' The name of the market this security trades on
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property MarketName() As String
            Get
                Return _marketName
            End Get
            Set(ByVal value As String)
                _marketName = value
            End Set
        End Property

        ''' <summary>
        ''' The trading class for this security
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property TradingClass() As String
            Get
                Return _tradingClass
            End Get
            Set(ByVal value As String)
                _tradingClass = value
            End Set
        End Property

        ''' <summary>
        ''' The minimum amount of money that this security can change
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks>
        ''' Most of the time this value will be 0.01
        ''' </remarks>
        Public Property MinTick() As Double
            Get
                Return _minTick
            End Get
            Set(ByVal value As Double)
                _minTick = value
            End Set
        End Property

        ''' <summary>
        ''' Explaination required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property PriceMagnifier() As Integer
            Get
                Return _priceMagnifier
            End Get
            Set(ByVal value As Integer)
                _priceMagnifier = value
            End Set
        End Property

        ''' <summary>
        ''' A list of valid order types for this contract
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property OrderTypes() As String
            Get
                Return _orderTypes
            End Get
            Set(ByVal value As String)
                _orderTypes = value
            End Set
        End Property

        ''' <summary>
        ''' The list of valid exchanges this security is traded on
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ValidExchanges() As String
            Get
                Return _validExchanges
            End Get
            Set(ByVal value As String)
                _validExchanges = value
            End Set
        End Property

        ''' <summary>
        ''' The nine character bond CUSIP or the twelve character SEDOL
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Cusip() As String
            Get
                Return _cusip
            End Get
            Set(ByVal value As String)
                _cusip = value
            End Set
        End Property

        ''' <summary>
        ''' Identifies the credit rating of the bond issuer
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Ratings() As String
            Get
                Return _ratings
            End Get
            Set(ByVal value As String)
                _ratings = value
            End Set
        End Property

        ''' <summary>
        ''' Contains further information about the bond
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property DescAppend() As String
            Get
                Return _descAppend
            End Get
            Set(ByVal value As String)
                _descAppend = value
            End Set
        End Property

        ''' <summary>
        ''' The type of bond
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property BondType() As String
            Get
                Return _bondType
            End Get
            Set(ByVal value As String)
                _bondType = value
            End Set
        End Property

        ''' <summary>
        ''' The type of bond coupon
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CouponType() As String
            Get
                Return _couponType
            End Get
            Set(ByVal value As String)
                _couponType = value
            End Set
        End Property

        ''' <summary>
        ''' Determines if the bond can be called by the issuer
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Callable() As Boolean
            Get
                Return _callable
            End Get
            Set(ByVal value As Boolean)
                _callable = value
            End Set
        End Property

        ''' <summary>
        ''' Determines if the bond can be sold back to the issuer
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Putable() As Boolean
            Get
                Return _putable
            End Get
            Set(ByVal value As Boolean)
                _putable = value
            End Set
        End Property

        ''' <summary>
        ''' The interest rate of the bond used to determine interest payments
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Coupon() As Double
            Get
                Return _coupon
            End Get
            Set(ByVal value As Double)
                _coupon = value
            End Set
        End Property

        ''' <summary>
        ''' Determines if the bond can be converted back to stocks
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Convertible() As Boolean
            Get
                Return _convertible
            End Get
            Set(ByVal value As Boolean)
                _convertible = value
            End Set
        End Property

        ''' <summary>
        ''' The date on which the issuer must repay the face value of the bond
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Maturity() As String
            Get
                Return _maturity
            End Get
            Set(ByVal value As String)
                _maturity = value
            End Set
        End Property

        ''' <summary>
        ''' The date on which the bond was issued
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property IssueDate() As String
            Get
                Return _issueDate
            End Get
            Set(ByVal value As String)
                _issueDate = value
            End Set
        End Property

        ''' <summary>
        ''' Explaination required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property NextOptionDate() As String
            Get
                Return _nextOptionDate
            End Get
            Set(ByVal value As String)
                _nextOptionDate = value
            End Set
        End Property

        ''' <summary>
        ''' Explaination required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property NextOptionType() As String
            Get
                Return _nextOptionType
            End Get
            Set(ByVal value As String)
                _nextOptionType = value
            End Set
        End Property

        ''' <summary>
        ''' Explaination required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property NextOptionPartial() As Boolean
            Get
                Return _nextOptionPartial
            End Get
            Set(ByVal value As Boolean)
                _nextOptionPartial = value
            End Set
        End Property

        ''' <summary>
        ''' Any notes that are attached to this security
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Notes() As String
            Get
                Return _notes
            End Get
            Set(ByVal value As String)
                _notes = value
            End Set
        End Property

#End Region

        Public Sub LoadDataFromObject(ByVal data As TWSLib.IContractDetails)

            Dim contractDet As TWSLib.IContractDetails = data
            Dim contract As New Contract()

            contract.LoadDataFromObject(contractDet.summary)

            Summary = contract

            With contractDet
                MarketName = .marketName
                TradingClass = .tradingClass
                MinTick = .minTick
                PriceMagnifier = .priceMagnifier
                OrderTypes = .orderTypes
                ValidExchanges = .validExchanges
                Cusip = .cusip
                Ratings = .ratings
                DescAppend = .descAppend
                BondType = .bondType
                CouponType = .couponType
                Callable = Utilities.ConvertIntToBool(.callable)
                Putable = Utilities.ConvertIntToBool(.putable)
                Coupon = .coupon
                Convertible = Utilities.ConvertIntToBool(.convertible)
                Maturity = .maturity
                IssueDate = .issueDate
                NextOptionDate = .nextOptionDate
                NextOptionType = .nextOptionType
                NextOptionPartial = Utilities.ConvertIntToBool(.nextOptionPartial)
                Notes = .notes
            End With
        End Sub

    End Class

End Namespace
