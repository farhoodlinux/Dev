Namespace Data

    ''' <summary>
    ''' Buffer to hold scanner data
    ''' </summary>
    Public Class ScannerBuffer

        Private _MaxSize As Integer = -1
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property MaxSize() As Integer
            Get
                Return _MaxSize
            End Get
            Set(ByVal value As Integer)
                If value <= 0 Then
                    'TODO:  this should not happened - add raising error
                Else
                    _MaxSize = value
                End If
            End Set
        End Property


        Private _Size As Integer
        Public ReadOnly Property Size() As Integer
            Get
                Return _Size
            End Get
        End Property

        'TODO:  this may be not needed at all
        Private _IsReady As Boolean
        Public Property IsReady() As Boolean
            Get
                Return _IsReady
            End Get
            Set(ByVal value As Boolean)
                If (value And (_MaxSize <> _Size)) Then
                    'TODO:  this should not happened - add raising error
                Else
                    _IsReady = value
                End If
            End Set
        End Property



        Private _RequestID As Integer
        Public Property RequestID() As Integer
            Get
                Return _RequestID
            End Get
            Set(ByVal value As Integer)
                _RequestID = value
            End Set
        End Property


        Private _Data As List(Of ScannerData)
        Public ReadOnly Property Data() As List(Of ScannerData)
            Get
                Return _Data
            End Get
        End Property



        Public Sub New()
            _Size = 0
            _IsReady = False
            _Data = New List(Of ScannerData)
        End Sub


        Public Sub Clear()
            _Size = 0
            _IsReady = False
            _Data.Clear()
        End Sub



        Public Sub AddData(ByVal value As ScannerData)
            _Size += 1
            _Data.Add(value)
        End Sub


        Public Sub SetData(ByVal value As ScannerBuffer)
            _Size = value.Size
            _IsReady = value.IsReady
            _Data.Clear()

            For Each row As ScannerData In value.Data
                _Data.Add(row)
            Next
        End Sub

    End Class

End Namespace

