Public Class Utilities

    ''' <summary>
    ''' Converts a boolean to an integer
    ''' </summary>
    ''' <param name="boolToConvert">The boolean value to convert to an integer</param>
    ''' <returns>An integer representation of a boolean</returns>
    ''' <remarks>
    ''' The TWS API uses a 1 or a 0 to indicate true or false; in the
    ''' framework we do not want to require the user to figure this out so we
    ''' store these values as booleans, but they still need to be converted back
    ''' before being sent to the API.
    ''' </remarks>
    Public Shared Function ConvertBoolToInt(ByVal boolToConvert As Boolean) As Integer
        Return CInt(IIf(boolToConvert = True, 1, 0))
    End Function

    ''' <summary>
    ''' Converts an integer to a boolean
    ''' </summary>
    ''' <param name="intToConvert">The integer value to conver to a boolen</param>
    ''' <returns>A boolean representation of an integer</returns>
    ''' <remarks>
    ''' This is used since the TWS API uses a 1 or 0 to indicate true or false;
    ''' this method will convert that number to its boolean equivalent.
    ''' </remarks>
    Public Shared Function ConvertIntToBool(ByVal intToConvert As Integer) As Boolean
        Return CBool(IIf(intToConvert > 0, True, False))
    End Function





End Class
