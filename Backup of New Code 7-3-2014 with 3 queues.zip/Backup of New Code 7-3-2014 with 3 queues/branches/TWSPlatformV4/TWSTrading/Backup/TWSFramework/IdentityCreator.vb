Public Class IdentityCreator

    Private Shared _transactionLockObject As Object
    Private Shared _transactionID As Integer = 0

    ''' <summary>
    ''' Creates the next unique id to use in a transaction
    ''' </summary>
    ''' <returns>A unique integer that can be used in a transaction</returns>
    ''' <remarks>This method can guarantee that the correct id will be created for each client</remarks>
    Public Shared Function GetNextTransactionID() As Integer
        If _transactionLockObject Is Nothing Then
            _transactionLockObject = New Object()
        End If

        ' use a lock so we can guarantee that the values are the correct ones
        SyncLock _transactionLockObject
            _transactionID = _transactionID + 1
            Return _transactionID
        End SyncLock
    End Function

End Class
