Imports TWSFramework.Data
Namespace Events
    Public Class ScannerDataEventArgs
        Inherits EventArgs

        Private _id As Integer

        Private _data As List(Of ScannerData)

        Public Sub New(ByVal pBuffer As ScannerBuffer)
            _id = pBuffer.RequestID
            _data = pBuffer.Data
        End Sub

        ''' <summary>
        ''' List(Of ScannerData)
        ''' </summary>
        Public ReadOnly Property data() As List(Of ScannerData)
            Get

                Return _data
            End Get

        End Property


        ''' <summary>
        ''' ID of the scanner subscription
        ''' </summary>
        Public ReadOnly Property id() As Integer
            Get
                Return _id
            End Get
        End Property

    End Class
End Namespace
