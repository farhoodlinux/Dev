Namespace Events
    Public Class MarketDataEventArgs
        Inherits EventArgs

        Private _data As MarketData

        Public Property Data() As MarketData
            Get
                Return _data
            End Get
            Set(ByVal value As MarketData)
                _data = value
            End Set
        End Property

    End Class
End Namespace