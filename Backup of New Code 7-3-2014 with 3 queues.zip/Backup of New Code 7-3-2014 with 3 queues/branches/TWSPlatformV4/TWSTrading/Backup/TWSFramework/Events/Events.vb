Namespace Events


    ''' <summary>
    ''' This delegate is used when data is returned from the scanner
    ''' subscription method
    ''' </summary>
    ''' <param name="sender">The object firing this event</param>
    ''' <param name="e">The ScannerDataEventArgs class that houses the data being returned by this event</param>
    ''' <remarks></remarks>

    Public Delegate Sub ScannerDataReturned(ByVal sender As Object, ByVal e As ScannerDataEventArgs)

    Public Delegate Sub ErrorDataReturn(ByVal sender As Object, ByVal e As ErrorEventArgs)

    Public Delegate Sub MarketDataReturned(ByVal sender As Object, ByVal e As MarketDataEventArgs)



End Namespace
