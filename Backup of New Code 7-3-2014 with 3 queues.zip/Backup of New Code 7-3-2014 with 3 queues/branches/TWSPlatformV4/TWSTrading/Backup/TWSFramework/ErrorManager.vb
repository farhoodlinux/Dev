Imports TWSFramework.Events
Imports TWSFramework.Data


Public Class ErrorManager

    Public Event ErrorEvent As ErrorDataReturn

    Private TWSForm As TWSComponent

    Public Sub New()

        TWSForm = TWSComponent.getinstance
        TWSForm.SetErrormanager(Me)

    End Sub

    Public Sub APIErrorData(ByVal x As ErrorData)

        Dim _errargs As New ErrorEventArgs

        _errargs.data = x

        RaiseEvent ErrorEvent(Me, _errargs)

    End Sub

End Class
