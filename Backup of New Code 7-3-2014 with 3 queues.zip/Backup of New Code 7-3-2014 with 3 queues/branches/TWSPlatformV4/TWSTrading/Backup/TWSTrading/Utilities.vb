Public Class Utilities
    ''' <summary>
    ''' Creates a data column that will exist in the data grid
    ''' </summary>
    ''' <param name="dataItemName">The name of the data field</param>
    ''' <returns>A DataGridViewColumn object to be added to the grid</returns>
    ''' <remarks></remarks>
    Public Shared Function CreateGridDataColumn(ByVal dataItemName As String) As DataGridViewColumn
        Return CreateGridDataColumn(dataItemName, dataItemName)
    End Function

    ''' <summary>
    ''' Creates a data column that will exist in the data grid
    ''' </summary>
    ''' <param name="dataItemName">The name of the data field</param>
    ''' <param name="headerText">The text that will go in the header of the grid</param>
    ''' <returns>A DataGridViewColumn object to be added to the grid</returns>
    ''' <remarks></remarks>
    Public Shared Function CreateGridDataColumn(ByVal dataItemName As String, ByVal headerText As String) As DataGridViewColumn
        Dim column As New DataGridViewColumn()
        column.DataPropertyName = dataItemName
        column.HeaderText = headerText
        column.Name = dataItemName & "Column"
        column.ReadOnly = True

        Dim cell As DataGridViewCell
        cell = New DataGridViewTextBoxCell()
        column.CellTemplate = cell

        Return column
    End Function

End Class
