<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Order
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LblSecType = New System.Windows.Forms.Label
        Me.txtSymbol = New System.Windows.Forms.TextBox
        Me.grpUpperLimit = New System.Windows.Forms.GroupBox
        Me.grpLowerLimit = New System.Windows.Forms.GroupBox
        Me.lblUpperLimitPrice = New System.Windows.Forms.Label
        Me.lblLowerLimitPrice = New System.Windows.Forms.Label
        Me.CurrentPrice = New System.Windows.Forms.Label
        Me.txtUpperLimitPrice = New System.Windows.Forms.TextBox
        Me.txtLowerLimitPrice = New System.Windows.Forms.TextBox
        Me.lblUpperBuy = New System.Windows.Forms.Label
        Me.lblLowerBuySell = New System.Windows.Forms.Label
        Me.cboUpperBuySell = New System.Windows.Forms.ComboBox
        Me.cboLowerBuySell = New System.Windows.Forms.ComboBox
        Me.lblUpperOrderType = New System.Windows.Forms.Label
        Me.lblLowerOrderType = New System.Windows.Forms.Label
        Me.cboUpperOrderType = New System.Windows.Forms.ComboBox
        Me.cboLowerOrderType = New System.Windows.Forms.ComboBox
        Me.lblUpperNewSymbol = New System.Windows.Forms.Label
        Me.lblLowerSymbol = New System.Windows.Forms.Label
        Me.txtUpperSymbol = New System.Windows.Forms.TextBox
        Me.txtLowerSymbol = New System.Windows.Forms.TextBox
        Me.lblUpperSymbolPrice = New System.Windows.Forms.Label
        Me.txtUpperPrice = New System.Windows.Forms.TextBox
        Me.lblLowerPrice = New System.Windows.Forms.Label
        Me.txtLowerPrice = New System.Windows.Forms.TextBox
        Me.btnOrderRequest = New System.Windows.Forms.Button
        Me.lblPriceAverage = New System.Windows.Forms.Label
        Me.txtPriceAverage = New System.Windows.Forms.TextBox
        Me.grpUpperLimit.SuspendLayout()
        Me.grpLowerLimit.SuspendLayout()
        Me.SuspendLayout()
        '
        'LblSecType
        '
        Me.LblSecType.AutoSize = True
        Me.LblSecType.Location = New System.Drawing.Point(12, 9)
        Me.LblSecType.Name = "LblSecType"
        Me.LblSecType.Size = New System.Drawing.Size(41, 13)
        Me.LblSecType.TabIndex = 0
        Me.LblSecType.Text = "Symbol"
        '
        'txtSymbol
        '
        Me.txtSymbol.Location = New System.Drawing.Point(15, 25)
        Me.txtSymbol.Name = "txtSymbol"
        Me.txtSymbol.Size = New System.Drawing.Size(100, 20)
        Me.txtSymbol.TabIndex = 1
        '
        'grpUpperLimit
        '
        Me.grpUpperLimit.Controls.Add(Me.txtUpperPrice)
        Me.grpUpperLimit.Controls.Add(Me.lblUpperSymbolPrice)
        Me.grpUpperLimit.Controls.Add(Me.txtUpperSymbol)
        Me.grpUpperLimit.Controls.Add(Me.lblUpperNewSymbol)
        Me.grpUpperLimit.Controls.Add(Me.cboUpperOrderType)
        Me.grpUpperLimit.Controls.Add(Me.lblUpperOrderType)
        Me.grpUpperLimit.Controls.Add(Me.cboUpperBuySell)
        Me.grpUpperLimit.Controls.Add(Me.lblUpperBuy)
        Me.grpUpperLimit.Controls.Add(Me.txtUpperLimitPrice)
        Me.grpUpperLimit.Controls.Add(Me.lblUpperLimitPrice)
        Me.grpUpperLimit.Location = New System.Drawing.Point(15, 73)
        Me.grpUpperLimit.Name = "grpUpperLimit"
        Me.grpUpperLimit.Size = New System.Drawing.Size(884, 88)
        Me.grpUpperLimit.TabIndex = 2
        Me.grpUpperLimit.TabStop = False
        Me.grpUpperLimit.Text = "Upper Limit Criteria"
        '
        'grpLowerLimit
        '
        Me.grpLowerLimit.Controls.Add(Me.txtLowerPrice)
        Me.grpLowerLimit.Controls.Add(Me.lblLowerPrice)
        Me.grpLowerLimit.Controls.Add(Me.txtLowerSymbol)
        Me.grpLowerLimit.Controls.Add(Me.lblLowerSymbol)
        Me.grpLowerLimit.Controls.Add(Me.cboLowerOrderType)
        Me.grpLowerLimit.Controls.Add(Me.lblLowerOrderType)
        Me.grpLowerLimit.Controls.Add(Me.cboLowerBuySell)
        Me.grpLowerLimit.Controls.Add(Me.lblLowerBuySell)
        Me.grpLowerLimit.Controls.Add(Me.txtLowerLimitPrice)
        Me.grpLowerLimit.Controls.Add(Me.lblLowerLimitPrice)
        Me.grpLowerLimit.Location = New System.Drawing.Point(15, 167)
        Me.grpLowerLimit.Name = "grpLowerLimit"
        Me.grpLowerLimit.Size = New System.Drawing.Size(884, 90)
        Me.grpLowerLimit.TabIndex = 3
        Me.grpLowerLimit.TabStop = False
        Me.grpLowerLimit.Text = "Lower Limit Criteria"
        '
        'lblUpperLimitPrice
        '
        Me.lblUpperLimitPrice.AutoSize = True
        Me.lblUpperLimitPrice.Location = New System.Drawing.Point(7, 20)
        Me.lblUpperLimitPrice.Name = "lblUpperLimitPrice"
        Me.lblUpperLimitPrice.Size = New System.Drawing.Size(87, 13)
        Me.lblUpperLimitPrice.TabIndex = 0
        Me.lblUpperLimitPrice.Text = "Upper Limit Price"
        '
        'lblLowerLimitPrice
        '
        Me.lblLowerLimitPrice.AutoSize = True
        Me.lblLowerLimitPrice.Location = New System.Drawing.Point(7, 20)
        Me.lblLowerLimitPrice.Name = "lblLowerLimitPrice"
        Me.lblLowerLimitPrice.Size = New System.Drawing.Size(87, 13)
        Me.lblLowerLimitPrice.TabIndex = 0
        Me.lblLowerLimitPrice.Text = "Lower Limit Price"
        '
        'CurrentPrice
        '
        Me.CurrentPrice.AutoSize = True
        Me.CurrentPrice.Location = New System.Drawing.Point(266, 28)
        Me.CurrentPrice.Name = "CurrentPrice"
        Me.CurrentPrice.Size = New System.Drawing.Size(65, 13)
        Me.CurrentPrice.TabIndex = 4
        Me.CurrentPrice.Text = "CurrentPrice"
        '
        'txtUpperLimitPrice
        '
        Me.txtUpperLimitPrice.Location = New System.Drawing.Point(101, 20)
        Me.txtUpperLimitPrice.Name = "txtUpperLimitPrice"
        Me.txtUpperLimitPrice.Size = New System.Drawing.Size(100, 20)
        Me.txtUpperLimitPrice.TabIndex = 1
        '
        'txtLowerLimitPrice
        '
        Me.txtLowerLimitPrice.Location = New System.Drawing.Point(101, 20)
        Me.txtLowerLimitPrice.Name = "txtLowerLimitPrice"
        Me.txtLowerLimitPrice.Size = New System.Drawing.Size(100, 20)
        Me.txtLowerLimitPrice.TabIndex = 1
        '
        'lblUpperBuy
        '
        Me.lblUpperBuy.AutoSize = True
        Me.lblUpperBuy.Location = New System.Drawing.Point(230, 26)
        Me.lblUpperBuy.Name = "lblUpperBuy"
        Me.lblUpperBuy.Size = New System.Drawing.Size(47, 13)
        Me.lblUpperBuy.TabIndex = 2
        Me.lblUpperBuy.Text = "Buy/Sell"
        '
        'lblLowerBuySell
        '
        Me.lblLowerBuySell.AutoSize = True
        Me.lblLowerBuySell.Location = New System.Drawing.Point(233, 26)
        Me.lblLowerBuySell.Name = "lblLowerBuySell"
        Me.lblLowerBuySell.Size = New System.Drawing.Size(47, 13)
        Me.lblLowerBuySell.TabIndex = 2
        Me.lblLowerBuySell.Text = "Buy/Sell"
        '
        'cboUpperBuySell
        '
        Me.cboUpperBuySell.FormattingEnabled = True
        Me.cboUpperBuySell.Items.AddRange(New Object() {"Buy", "Sell"})
        Me.cboUpperBuySell.Location = New System.Drawing.Point(283, 23)
        Me.cboUpperBuySell.Name = "cboUpperBuySell"
        Me.cboUpperBuySell.Size = New System.Drawing.Size(121, 21)
        Me.cboUpperBuySell.TabIndex = 3
        '
        'cboLowerBuySell
        '
        Me.cboLowerBuySell.FormattingEnabled = True
        Me.cboLowerBuySell.Items.AddRange(New Object() {"Buy", "Sell"})
        Me.cboLowerBuySell.Location = New System.Drawing.Point(286, 23)
        Me.cboLowerBuySell.Name = "cboLowerBuySell"
        Me.cboLowerBuySell.Size = New System.Drawing.Size(121, 21)
        Me.cboLowerBuySell.TabIndex = 3
        '
        'lblUpperOrderType
        '
        Me.lblUpperOrderType.AutoSize = True
        Me.lblUpperOrderType.Location = New System.Drawing.Point(434, 30)
        Me.lblUpperOrderType.Name = "lblUpperOrderType"
        Me.lblUpperOrderType.Size = New System.Drawing.Size(60, 13)
        Me.lblUpperOrderType.TabIndex = 4
        Me.lblUpperOrderType.Text = "Order Type"
        '
        'lblLowerOrderType
        '
        Me.lblLowerOrderType.AutoSize = True
        Me.lblLowerOrderType.Location = New System.Drawing.Point(437, 30)
        Me.lblLowerOrderType.Name = "lblLowerOrderType"
        Me.lblLowerOrderType.Size = New System.Drawing.Size(60, 13)
        Me.lblLowerOrderType.TabIndex = 4
        Me.lblLowerOrderType.Text = "Order Type"
        '
        'cboUpperOrderType
        '
        Me.cboUpperOrderType.FormattingEnabled = True
        Me.cboUpperOrderType.Items.AddRange(New Object() {"Market", "Limit"})
        Me.cboUpperOrderType.Location = New System.Drawing.Point(500, 23)
        Me.cboUpperOrderType.Name = "cboUpperOrderType"
        Me.cboUpperOrderType.Size = New System.Drawing.Size(121, 21)
        Me.cboUpperOrderType.TabIndex = 5
        '
        'cboLowerOrderType
        '
        Me.cboLowerOrderType.FormattingEnabled = True
        Me.cboLowerOrderType.Items.AddRange(New Object() {"Market", "Limit"})
        Me.cboLowerOrderType.Location = New System.Drawing.Point(503, 23)
        Me.cboLowerOrderType.Name = "cboLowerOrderType"
        Me.cboLowerOrderType.Size = New System.Drawing.Size(121, 21)
        Me.cboLowerOrderType.TabIndex = 5
        '
        'lblUpperNewSymbol
        '
        Me.lblUpperNewSymbol.AutoSize = True
        Me.lblUpperNewSymbol.Location = New System.Drawing.Point(10, 54)
        Me.lblUpperNewSymbol.Name = "lblUpperNewSymbol"
        Me.lblUpperNewSymbol.Size = New System.Drawing.Size(41, 13)
        Me.lblUpperNewSymbol.TabIndex = 6
        Me.lblUpperNewSymbol.Text = "Symbol"
        '
        'lblLowerSymbol
        '
        Me.lblLowerSymbol.AutoSize = True
        Me.lblLowerSymbol.Location = New System.Drawing.Point(10, 53)
        Me.lblLowerSymbol.Name = "lblLowerSymbol"
        Me.lblLowerSymbol.Size = New System.Drawing.Size(41, 13)
        Me.lblLowerSymbol.TabIndex = 6
        Me.lblLowerSymbol.Text = "Symbol"
        '
        'txtUpperSymbol
        '
        Me.txtUpperSymbol.Location = New System.Drawing.Point(101, 51)
        Me.txtUpperSymbol.Name = "txtUpperSymbol"
        Me.txtUpperSymbol.Size = New System.Drawing.Size(100, 20)
        Me.txtUpperSymbol.TabIndex = 7
        '
        'txtLowerSymbol
        '
        Me.txtLowerSymbol.Location = New System.Drawing.Point(101, 50)
        Me.txtLowerSymbol.Name = "txtLowerSymbol"
        Me.txtLowerSymbol.Size = New System.Drawing.Size(100, 20)
        Me.txtLowerSymbol.TabIndex = 7
        '
        'lblUpperSymbolPrice
        '
        Me.lblUpperSymbolPrice.AutoSize = True
        Me.lblUpperSymbolPrice.Location = New System.Drawing.Point(230, 54)
        Me.lblUpperSymbolPrice.Name = "lblUpperSymbolPrice"
        Me.lblUpperSymbolPrice.Size = New System.Drawing.Size(31, 13)
        Me.lblUpperSymbolPrice.TabIndex = 8
        Me.lblUpperSymbolPrice.Text = "Price"
        '
        'txtUpperPrice
        '
        Me.txtUpperPrice.Location = New System.Drawing.Point(283, 51)
        Me.txtUpperPrice.Name = "txtUpperPrice"
        Me.txtUpperPrice.Size = New System.Drawing.Size(121, 20)
        Me.txtUpperPrice.TabIndex = 9
        '
        'lblLowerPrice
        '
        Me.lblLowerPrice.AutoSize = True
        Me.lblLowerPrice.Location = New System.Drawing.Point(233, 53)
        Me.lblLowerPrice.Name = "lblLowerPrice"
        Me.lblLowerPrice.Size = New System.Drawing.Size(31, 13)
        Me.lblLowerPrice.TabIndex = 8
        Me.lblLowerPrice.Text = "Price"
        '
        'txtLowerPrice
        '
        Me.txtLowerPrice.Location = New System.Drawing.Point(286, 50)
        Me.txtLowerPrice.Name = "txtLowerPrice"
        Me.txtLowerPrice.Size = New System.Drawing.Size(121, 20)
        Me.txtLowerPrice.TabIndex = 9
        '
        'btnOrderRequest
        '
        Me.btnOrderRequest.Location = New System.Drawing.Point(15, 273)
        Me.btnOrderRequest.Name = "btnOrderRequest"
        Me.btnOrderRequest.Size = New System.Drawing.Size(130, 23)
        Me.btnOrderRequest.TabIndex = 5
        Me.btnOrderRequest.Text = "Submit Order Request"
        Me.btnOrderRequest.UseVisualStyleBackColor = True
        '
        'lblPriceAverage
        '
        Me.lblPriceAverage.AutoSize = True
        Me.lblPriceAverage.Location = New System.Drawing.Point(138, 9)
        Me.lblPriceAverage.Name = "lblPriceAverage"
        Me.lblPriceAverage.Size = New System.Drawing.Size(53, 13)
        Me.lblPriceAverage.TabIndex = 6
        Me.lblPriceAverage.Text = "Price Avg"
        '
        'txtPriceAverage
        '
        Me.txtPriceAverage.Location = New System.Drawing.Point(141, 25)
        Me.txtPriceAverage.Name = "txtPriceAverage"
        Me.txtPriceAverage.Size = New System.Drawing.Size(100, 20)
        Me.txtPriceAverage.TabIndex = 7
        '
        'Order
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(911, 452)
        Me.Controls.Add(Me.txtPriceAverage)
        Me.Controls.Add(Me.lblPriceAverage)
        Me.Controls.Add(Me.btnOrderRequest)
        Me.Controls.Add(Me.CurrentPrice)
        Me.Controls.Add(Me.grpLowerLimit)
        Me.Controls.Add(Me.grpUpperLimit)
        Me.Controls.Add(Me.txtSymbol)
        Me.Controls.Add(Me.LblSecType)
        Me.Name = "Order"
        Me.Text = "Order"
        Me.grpUpperLimit.ResumeLayout(False)
        Me.grpUpperLimit.PerformLayout()
        Me.grpLowerLimit.ResumeLayout(False)
        Me.grpLowerLimit.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LblSecType As System.Windows.Forms.Label
    Friend WithEvents txtSymbol As System.Windows.Forms.TextBox
    Friend WithEvents grpUpperLimit As System.Windows.Forms.GroupBox
    Friend WithEvents cboUpperBuySell As System.Windows.Forms.ComboBox
    Friend WithEvents lblUpperBuy As System.Windows.Forms.Label
    Friend WithEvents txtUpperLimitPrice As System.Windows.Forms.TextBox
    Friend WithEvents lblUpperLimitPrice As System.Windows.Forms.Label
    Friend WithEvents grpLowerLimit As System.Windows.Forms.GroupBox
    Friend WithEvents cboLowerBuySell As System.Windows.Forms.ComboBox
    Friend WithEvents lblLowerBuySell As System.Windows.Forms.Label
    Friend WithEvents txtLowerLimitPrice As System.Windows.Forms.TextBox
    Friend WithEvents lblLowerLimitPrice As System.Windows.Forms.Label
    Friend WithEvents CurrentPrice As System.Windows.Forms.Label
    Friend WithEvents cboUpperOrderType As System.Windows.Forms.ComboBox
    Friend WithEvents lblUpperOrderType As System.Windows.Forms.Label
    Friend WithEvents cboLowerOrderType As System.Windows.Forms.ComboBox
    Friend WithEvents lblLowerOrderType As System.Windows.Forms.Label
    Friend WithEvents txtUpperPrice As System.Windows.Forms.TextBox
    Friend WithEvents lblUpperSymbolPrice As System.Windows.Forms.Label
    Friend WithEvents txtUpperSymbol As System.Windows.Forms.TextBox
    Friend WithEvents lblUpperNewSymbol As System.Windows.Forms.Label
    Friend WithEvents txtLowerSymbol As System.Windows.Forms.TextBox
    Friend WithEvents lblLowerSymbol As System.Windows.Forms.Label
    Friend WithEvents txtLowerPrice As System.Windows.Forms.TextBox
    Friend WithEvents lblLowerPrice As System.Windows.Forms.Label
    Friend WithEvents btnOrderRequest As System.Windows.Forms.Button
    Friend WithEvents lblPriceAverage As System.Windows.Forms.Label
    Friend WithEvents txtPriceAverage As System.Windows.Forms.TextBox
End Class
