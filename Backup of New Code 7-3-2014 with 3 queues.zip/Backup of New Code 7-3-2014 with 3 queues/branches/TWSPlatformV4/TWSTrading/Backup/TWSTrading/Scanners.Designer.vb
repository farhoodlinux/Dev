<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Scanners
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ScannerGrid = New System.Windows.Forms.DataGridView
        Me.txtBox = New System.Windows.Forms.TextBox
        Me.txtLoops = New System.Windows.Forms.TextBox
        Me.txtBox2 = New System.Windows.Forms.TextBox
        Me.PanelTop = New System.Windows.Forms.Panel
        Me.PanelTopFill = New System.Windows.Forms.Panel
        Me.PanelTopTop = New System.Windows.Forms.Panel
        Me.ScanButton = New System.Windows.Forms.Button
        Me.PanelFill = New System.Windows.Forms.Panel
        Me.txtBox3 = New System.Windows.Forms.TextBox
        CType(Me.ScannerGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelTop.SuspendLayout()
        Me.PanelTopFill.SuspendLayout()
        Me.PanelTopTop.SuspendLayout()
        Me.PanelFill.SuspendLayout()
        Me.SuspendLayout()
        '
        'ScannerGrid
        '
        Me.ScannerGrid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ScannerGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken
        Me.ScannerGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ScannerGrid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ScannerGrid.Location = New System.Drawing.Point(0, 0)
        Me.ScannerGrid.Name = "ScannerGrid"
        Me.ScannerGrid.Size = New System.Drawing.Size(969, 226)
        Me.ScannerGrid.TabIndex = 0
        '
        'txtBox
        '
        Me.txtBox.Location = New System.Drawing.Point(7, 29)
        Me.txtBox.Multiline = True
        Me.txtBox.Name = "txtBox"
        Me.txtBox.Size = New System.Drawing.Size(307, 290)
        Me.txtBox.TabIndex = 2
        '
        'txtLoops
        '
        Me.txtLoops.Location = New System.Drawing.Point(7, 6)
        Me.txtLoops.Name = "txtLoops"
        Me.txtLoops.Size = New System.Drawing.Size(109, 20)
        Me.txtLoops.TabIndex = 3
        Me.txtLoops.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtBox2
        '
        Me.txtBox2.Location = New System.Drawing.Point(320, 29)
        Me.txtBox2.Multiline = True
        Me.txtBox2.Name = "txtBox2"
        Me.txtBox2.Size = New System.Drawing.Size(328, 290)
        Me.txtBox2.TabIndex = 4
        '
        'PanelTop
        '
        Me.PanelTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PanelTop.Controls.Add(Me.PanelTopFill)
        Me.PanelTop.Controls.Add(Me.PanelTopTop)
        Me.PanelTop.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelTop.Location = New System.Drawing.Point(0, 0)
        Me.PanelTop.Name = "PanelTop"
        Me.PanelTop.Size = New System.Drawing.Size(973, 260)
        Me.PanelTop.TabIndex = 5
        '
        'PanelTopFill
        '
        Me.PanelTopFill.Controls.Add(Me.ScannerGrid)
        Me.PanelTopFill.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelTopFill.Location = New System.Drawing.Point(0, 30)
        Me.PanelTopFill.Name = "PanelTopFill"
        Me.PanelTopFill.Size = New System.Drawing.Size(969, 226)
        Me.PanelTopFill.TabIndex = 1
        '
        'PanelTopTop
        '
        Me.PanelTopTop.BackColor = System.Drawing.SystemColors.Control
        Me.PanelTopTop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PanelTopTop.Controls.Add(Me.ScanButton)
        Me.PanelTopTop.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PanelTopTop.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelTopTop.Location = New System.Drawing.Point(0, 0)
        Me.PanelTopTop.Name = "PanelTopTop"
        Me.PanelTopTop.Size = New System.Drawing.Size(969, 30)
        Me.PanelTopTop.TabIndex = 0
        '
        'ScanButton
        '
        Me.ScanButton.Location = New System.Drawing.Point(3, 3)
        Me.ScanButton.Name = "ScanButton"
        Me.ScanButton.Size = New System.Drawing.Size(75, 23)
        Me.ScanButton.TabIndex = 2
        Me.ScanButton.Text = "Start"
        Me.ScanButton.UseVisualStyleBackColor = True
        '
        'PanelFill
        '
        Me.PanelFill.Controls.Add(Me.txtBox3)
        Me.PanelFill.Controls.Add(Me.txtLoops)
        Me.PanelFill.Controls.Add(Me.txtBox)
        Me.PanelFill.Controls.Add(Me.txtBox2)
        Me.PanelFill.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelFill.Location = New System.Drawing.Point(0, 260)
        Me.PanelFill.Name = "PanelFill"
        Me.PanelFill.Size = New System.Drawing.Size(973, 322)
        Me.PanelFill.TabIndex = 6
        '
        'txtBox3
        '
        Me.txtBox3.Location = New System.Drawing.Point(654, 29)
        Me.txtBox3.Multiline = True
        Me.txtBox3.Name = "txtBox3"
        Me.txtBox3.Size = New System.Drawing.Size(316, 290)
        Me.txtBox3.TabIndex = 5
        '
        'Scanners
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(973, 582)
        Me.Controls.Add(Me.PanelFill)
        Me.Controls.Add(Me.PanelTop)
        Me.Name = "Scanners"
        Me.Text = "Scanners"
        CType(Me.ScannerGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelTop.ResumeLayout(False)
        Me.PanelTopFill.ResumeLayout(False)
        Me.PanelTopTop.ResumeLayout(False)
        Me.PanelFill.ResumeLayout(False)
        Me.PanelFill.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ScannerGrid As System.Windows.Forms.DataGridView
    Friend WithEvents txtBox As System.Windows.Forms.TextBox
    Friend WithEvents txtLoops As System.Windows.Forms.TextBox
    Friend WithEvents txtBox2 As System.Windows.Forms.TextBox
    Friend WithEvents PanelTop As System.Windows.Forms.Panel
    Friend WithEvents PanelTopFill As System.Windows.Forms.Panel
    Friend WithEvents PanelTopTop As System.Windows.Forms.Panel
    Friend WithEvents ScanButton As System.Windows.Forms.Button
    Friend WithEvents PanelFill As System.Windows.Forms.Panel
    Friend WithEvents txtBox3 As System.Windows.Forms.TextBox
End Class
