''' <summary>
''' IntersectionData - Common Security between all scanners
''' </summary>
Public Class IntersectionData
    Implements IComparable

    Public Overloads Function CompareTo(ByVal obj As Object) As Integer  Implements IComparable.CompareTo

        If TypeOf obj Is IntersectionData Then
            Dim tmp As IntersectionData = CType(obj, IntersectionData)

            Return _Hits.CompareTo(tmp.Hits)
        End If

        Throw New ArgumentException("object is not a Temperature")
    End Function

    Private _Exchange As String
    Private _Market As String
    Private _Symbol As String
    Private _Hits As Integer

    ''' <summary>
    ''' Constructor for IntersectionData - Common Security between all scanners
    ''' </summary>
    ''' <param name="pExchange">Name of the Exchange</param>
    ''' <param name="pMarket">Market name of the security</param>
    ''' <param name="pSymbol">Symbol of the security</param>
    ''' <param name="pHits">Number of scanners where this security appear</param>
    ''' <remarks></remarks>
    Public Sub New(ByVal pExchange As String, ByVal pMarket As String, ByVal pSymbol As String, ByVal pHits As Integer)
        _Exchange = pExchange
        _Market = pMarket
        _Symbol = pSymbol
        _Hits = pHits
    End Sub


    ''' <summary>
    ''' Name of the Exchange
    ''' </summary>
    Public Property Exchange() As String
        Get
            Return _Exchange
        End Get
        Set(ByVal value As String)
            _Exchange = value
        End Set
    End Property

    ''' <summary>
    ''' Market Name of the Security
    ''' </summary>
    Public Property Market() As String
        Get
            Return _Market
        End Get
        Set(ByVal value As String)
            _Market = value
        End Set
    End Property

    ''' <summary>
    ''' Symbol of the security
    ''' </summary>
    Public Property Symbol() As String
        Get
            Return _Symbol
        End Get
        Set(ByVal value As String)
            _Symbol = value
        End Set
    End Property

    ''' <summary>
    ''' Number of scanners where this security appear
    ''' </summary>
    Public Property Hits() As Integer
        Get
            Return _Hits
        End Get
        Set(ByVal value As Integer)
            _Hits = value
        End Set
    End Property


End Class
