Public Class Order

    Private Sub cboUpperOrderType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboUpperOrderType.SelectedIndexChanged
        If cboUpperOrderType.Text = "Market" Then
            lblUpperSymbolPrice.Enabled = False
            txtUpperPrice.Enabled = False
        Else
            lblUpperSymbolPrice.Enabled = True
            txtUpperPrice.Enabled = True
        End If
    End Sub

    Private Sub cboLowerOrderType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboLowerOrderType.SelectedIndexChanged
        If cboLowerOrderType.Text = "Market" Then
            lblLowerPrice.Enabled = False
            txtLowerPrice.Enabled = False
        Else
            lblLowerPrice.Enabled = True
            txtLowerPrice.Enabled = True
        End If
    End Sub

    Private Sub btnOrderRequest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOrderRequest.Click

    End Sub
End Class