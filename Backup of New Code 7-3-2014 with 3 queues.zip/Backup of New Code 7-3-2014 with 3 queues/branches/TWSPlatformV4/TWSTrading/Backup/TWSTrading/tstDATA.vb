Public Class tstDATA
    Public data As List(Of String) = New List(Of String)
    Public id As Integer
End Class
