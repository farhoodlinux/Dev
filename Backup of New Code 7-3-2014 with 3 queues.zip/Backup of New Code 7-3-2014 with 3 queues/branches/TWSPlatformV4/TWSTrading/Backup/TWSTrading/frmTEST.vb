Public Class frmTEST

    Public allBuffers As Dictionary(Of Integer, tstDATA) = New Dictionary(Of Integer, tstDATA)

    Public Sub init()
        Dim results As List(Of String) = New List(Of String)
        allBuffers.Add(1, New tstDATA) : allBuffers.Add(2, New tstDATA) : allBuffers.Add(3, New tstDATA)
        allBuffers(1).data.Add("A001") : allBuffers(2).data.Add("A001") : allBuffers(3).data.Add("A001")
        allBuffers(1).data.Add("A002") : allBuffers(2).data.Add("B002") : allBuffers(3).data.Add("B002")
        allBuffers(1).data.Add("A003") : allBuffers(2).data.Add("B003") : allBuffers(3).data.Add("C001")
        allBuffers(1).data.Add("A004") : allBuffers(2).data.Add("B004") : allBuffers(3).data.Add("C002")
        allBuffers(1).data.Add("A005") : allBuffers(2).data.Add("B001") : allBuffers(3).data.Add("C003")
        allBuffers(1).data.Add("A006") : allBuffers(2).data.Add("A006") : allBuffers(3).data.Add("A006")

        Dim comp As String
        Dim iHits As Integer

        For Each dt As KeyValuePair(Of Integer, tstDATA) In allBuffers
            For Each Val As String In dt.Value.data
                comp = Val
                iHits = 1
                For Each cm As KeyValuePair(Of Integer, tstDATA) In allBuffers
                    If dt.Key <> cm.Key Then
                        For Each CmVal As String In cm.Value.data
                            If comp = CmVal Then
                                iHits = iHits + 1
                            End If
                        Next CmVal
                    End If
                Next cm
                If iHits > 1 Then
                    If Not results.Contains(Val) Then
                        results.Add(Val)
                        txtBox.Text = txtBox.Text & Val & " - " & CStr(iHits) & Chr(13) & Chr(10)
                    End If
                End If
                txtBox.Refresh()
                My.Application.DoEvents()
                My.Application.DoEvents()
            Next Val
            My.Application.DoEvents()
        Next dt
        My.Application.DoEvents()

    End Sub


End Class