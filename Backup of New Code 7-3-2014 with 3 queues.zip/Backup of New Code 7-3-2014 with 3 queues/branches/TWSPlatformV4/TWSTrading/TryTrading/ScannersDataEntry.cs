﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TWSFramework;
using TWSFramework.Enums;

namespace TryTrading
{
    public partial class ScannersDataEntry : Form
    {
        public ScannersDataEntry()
        {
            InitializeComponent();
            SetComboboxes();
            ClearData();
            SetDataSource();
        }

        private void SetComboboxes()
        {
            cmbInstrument.DataSource = Enum.GetNames(typeof(TWSFramework.Enums.InstrumentType));
            cmbLocation.DataSource = Enum.GetNames(typeof(TWSFramework.Enums.LocationType));
            cmbScanCode.DataSource = Enum.GetNames(typeof(TWSFramework.Enums.ScanCodeType));
            cmbStockType.DataSource = Enum.GetNames(typeof(TWSFramework.Enums.StockTypeFilter));
        }

        private void SetDataSource()
        {
            var scanners = new DataLayer().GetScannersFromDatabase(false);
            dgvScanners.DataSource = scanners;
            dgvScanners.Columns["RequestId"].Width = 60;
            //dgvScanners.Columns["ActualEmail"].Width = 150;
            //dgvScanners.Columns["TempEmailId"].Visible = false;
            //dgvScanners.Columns["MaxCount"].Width = 70;
            //dgvScanners.Columns["UsageCount"].Width = 75;
            //dgvScanners.Columns["Validity"].Width = 75;
        }

        private void dgvScanners_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var row = dgvScanners.Rows[e.RowIndex];

            txtMinPrice.Text = row.Cells["PriceAbove"].Value.ToString();
            txtMaxPrice.Text = row.Cells["PriceBelow"].Value.ToString();
            txtRequestId.Text = row.Cells["RequestId"].Value.ToString();
            txtScannerName.Text = row.Cells["ScannerName"].Value.ToString();
            txtMarketCapAbove.Text = row.Cells["MarketCapAbove"].Value.ToString();
            txtMarketCapBelow.Text = row.Cells["MarketCapBelow"].Value.ToString();
            cmbStockType.SelectedItem = ((StockTypeFilter)((int)row.Cells["StockTypeFilter"].Value)).ToString();
            cmbScanCode.SelectedItem = ((ScanCodeType)((int)row.Cells["ScanCode"].Value)).ToString();
            cmbLocation.SelectedItem = ((LocationType)((int)row.Cells["Location"].Value)).ToString();
            cmbInstrument.SelectedItem = ((InstrumentType)((int)row.Cells["Instrument"].Value)).ToString();

            btnUpdate.Text = "Update";
        }

        private void ClearData()
        {
            btnUpdate.Text = "Add Scanner";
            txtMinPrice.Text = "0";
            txtMaxPrice.Text = "0";
            txtRequestId.Text = "0";
            txtScannerName.Text = "";
            txtMarketCapAbove.Text = txtMarketCapBelow.Text = "0";
            cmbStockType.SelectedIndex =
                cmbScanCode.SelectedIndex = cmbLocation.SelectedIndex = cmbInstrument.SelectedIndex = 0;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                var minPrice = double.Parse(txtMinPrice.Text);
                var maxPrice = double.Parse(txtMaxPrice.Text);
                var marketCapAbove = double.Parse(txtMarketCapAbove.Text);
                var marketCapBelow = double.Parse(txtMarketCapBelow.Text);
                var scanner = new ScannerSubscription()
                                  {
                                      PriceAbove = minPrice,
                                      PriceBelow = maxPrice,
                                      MarketCapAbove = marketCapAbove,
                                      MarketCapBelow = marketCapBelow,
                                      RequestID = int.Parse(txtRequestId.Text),
                                      ScannerName = txtScannerName.Text,
                                      StockTypeFilter =
                                          (TWSFramework.Enums.StockTypeFilter)
                                          Enum.Parse(typeof (TWSFramework.Enums.StockTypeFilter), cmbStockType.Text),
                                      Instrument =
                                          (TWSFramework.Enums.InstrumentType)
                                          Enum.Parse(typeof (TWSFramework.Enums.InstrumentType), cmbInstrument.Text),
                                      ScanCode =
                                          (TWSFramework.Enums.ScanCodeType)
                                          Enum.Parse(typeof (TWSFramework.Enums.ScanCodeType), cmbScanCode.Text),
                                      Location =
                                          (TWSFramework.Enums.LocationType)
                                          Enum.Parse(typeof (TWSFramework.Enums.LocationType), cmbLocation.Text),
                                      Enabled = chkEnabled.Checked
                                  };

                new DataLayer().WriteToDatabase(scanner);
                ClearData();
                SetDataSource();
            }
            catch
            {
                MessageBox.Show("Invalid Data, Please enter correct values for all the fields!", "Invalid Data");
            }
        }

    }
}
