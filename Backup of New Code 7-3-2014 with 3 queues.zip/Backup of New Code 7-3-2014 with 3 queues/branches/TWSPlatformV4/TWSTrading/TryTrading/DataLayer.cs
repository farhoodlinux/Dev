﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Globalization;
using TWSFramework;
using TWSFramework.Enums;

namespace TryTrading
{
    class DataLayer
    {
        private string ConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["ScannerDatabaseConnectionString"].ConnectionString; }
        }

        private string GetInsertStatement(ScannerSubscription ss)
        {
            string query =
                "INSERT INTO Scanner(ScannerName, ScanCode, InstrumentType, LocationType, StockTypeFilter, MinPrice, MaxPrice, MarketCapAbove, MarketCapBelow, Enabled) VALUES ('{0}',{1},{2},{3},{4},{5},{6},{7},{8},{9})";

            query = string.Format(query, ss.ScannerName, (int) ss.ScanCode, (int) ss.Instrument, (int) ss.Location,
                                  (int) ss.StockTypeFilter, ss.PriceAbove, ss.PriceBelow, ss.MarketCapAbove, ss.MarketCapBelow, ss.Enabled.ToString());
            return query;
        }

        private string GetUpdateStatement(ScannerSubscription ss)
        {
            string query =
                "UPDATE Scanner SET ScannerName = '{0}', ScanCode={1}, InstrumentType={2}, LocationType={3}, StockTypeFilter={4}, MinPrice={5}, MaxPrice={6}, MarketCapAbove={7}, MarketCapBelow={8}, Enabled={9} WHERE RequestId={10}";

            query = string.Format(query, ss.ScannerName, (int)ss.ScanCode, (int)ss.Instrument, (int)ss.Location,
                                  (int)ss.StockTypeFilter, ss.PriceAbove, ss.PriceBelow, ss.MarketCapAbove, ss.MarketCapBelow, ss.Enabled.ToString(), ss.RequestID);
            return query;
        }

        public void WriteToDatabase(ScannerSubscription scannerSubscription)
        {
            string queryString = scannerSubscription.RequestID == 0 ? GetInsertStatement(scannerSubscription) : GetUpdateStatement(scannerSubscription);
            var connection = new OleDbConnection(ConnectionString);
            try
            {
                connection.Open();
                var command = new OleDbCommand(queryString, connection);
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to write to database. Reason: " + ex.Message, "Error writing to database");
            }
            finally
            {
                connection.Close();
            }
        }

        public List<ScannerSubscription> GetScannersFromDatabase(bool onlyValid)
        {
            var scannerSubscriptions = new List<ScannerSubscription>();
            try
            {
                string queryString = String.Format("SELECT * FROM Scanner");
                if (onlyValid)
                    queryString += " WHERE Enabled=True";
                var connection = new OleDbConnection(ConnectionString);
                connection.Open();
                var command = new OleDbCommand(queryString, connection);
                OleDbDataReader reader = command.ExecuteReader();

                if (reader != null && reader.HasRows)
                {
                    while (reader.Read())
                    {
                        scannerSubscriptions.Add(new ScannerSubscription()
                        {
                            RequestID = (int)reader["RequestId"],
                            Instrument = (InstrumentType)((int)reader["InstrumentType"]),
                            ScannerName = reader["ScannerName"].ToString(),
                            ScanCode = (ScanCodeType)((int)reader["ScanCode"]),
                            Location = (LocationType)((int)reader["LocationType"]),
                            StockTypeFilter = (StockTypeFilter)((int)reader["StockTypeFilter"]),
                            PriceAbove = (int)reader["MinPrice"],
                            PriceBelow = (int)reader["MaxPrice"],
                            MarketCapAbove = (int)reader["MarketCapAbove"],
                            MarketCapBelow = (int)reader["MarketCapBelow"]
                        });
                    }
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to read database. Reason: " + ex.Message, "Error reading database");
            }
            return scannerSubscriptions;
        }
    }
}
