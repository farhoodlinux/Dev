﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AxTWSLib;
using TWSFramework;
using TryTrading.Properties;
using System.IO;


namespace TryTrading
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            axTws1.scannerDataEx += new _DTwsEvents_scannerDataExEventHandler(axTws1_scannerDataEx);
            axTws1.scannerDataEnd += new _DTwsEvents_scannerDataEndEventHandler(axTws1_scannerDataEnd);
            axTws1.errMsg += new _DTwsEvents_errMsgEventHandler(axTws1_errMsg);
            axTws2.scannerDataEx += new _DTwsEvents_scannerDataExEventHandler(axTws2_scannerDataEx);
            axTws2.scannerDataEnd += new _DTwsEvents_scannerDataEndEventHandler(axTws2_scannerDataEnd);
            axTws2.errMsg += new _DTwsEvents_errMsgEventHandler(axTws2_errMsg);

            cmbScanType1.DataSource = Enum.GetNames(typeof (TWSFramework.Enums.ScanCodeType));
            cmbScanType2.DataSource = Enum.GetNames(typeof (TWSFramework.Enums.ScanCodeType));
        }

        private Dictionary<int, ScannerSubscription> ScannerSubscriptions { get; set; }

        private int ClientId1
        {
            get
            {
                return int.Parse(txtClientId1.Text);
            }
        }

        private int ClientId2
        {
            get
            {
                return int.Parse(txtClientId2.Text);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                ScannerSubscriptions = new Dictionary<int, ScannerSubscription>();
                var scanType1 =
                    (TWSFramework.Enums.ScanCodeType)
                    Enum.Parse(typeof (TWSFramework.Enums.ScanCodeType), cmbScanType1.SelectedValue.ToString());

                var scanType2 =
                    (TWSFramework.Enums.ScanCodeType)
                    Enum.Parse(typeof(TWSFramework.Enums.ScanCodeType), cmbScanType2.SelectedValue.ToString());

                var minPrice1 = int.Parse(txtMinPrice1.Text);
                var minPrice2 = int.Parse(txtMinPrice2.Text);

                var maxPrice1 = int.Parse(txtMaxPrice1.Text);
                var maxPrice2 = int.Parse(txtMaxPrice2.Text);

                var clientId1 = int.Parse(txtClientId1.Text);
                var clientId2 = int.Parse(txtClientId2.Text);

                var scannerSubscription1 = CreateCustomScannerSubscription(scanType1, minPrice1, maxPrice1);
                var scannerSubscription2 = CreateCustomScannerSubscription(scanType2, minPrice2, maxPrice2);

                ScannerSubscriptions.Add(clientId1, scannerSubscription1);
                ScannerSubscriptions.Add(clientId2, scannerSubscription2);
                
                axTws1.connect("", 7496, clientId1);
                //axTws2.connect("", 7496, clientId2);

                //SetUpScanner(axTws1, scannerSubscription1, ClientId1);
                //SetUpScanner(axTws1, scannerSubscription2, ClientId2);

                btnStart.Enabled = false;
                btnStop.Enabled = true;
            }
            catch (Exception)
            {
                MessageBox.Show("Please check the values for all the fields!", "Error!", MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
            }
            //AxTws1.connect("", 7496, 3);
            //axTws2.connect("", 7496, 4);
            //var scannerSubs = AxTws1.createScannerSubscription();
            //var scan = new ScannerSubscription(10, TWSFramework.Enums.InstrumentType.Stk, TWSFramework.Enums.LocationType.Stk_Us,
            //                                   TWSFramework.Enums.StockTypeFilter.All, TWSFramework.Enums.ScanCodeType.Top_Volume_Rate, 0, 1000);
            //scan.RevertToTWSObject(ref scannerSubs);
            //AxTws1.reqScannerSubscriptionEx(1, scannerSubs);
            //AxTws1.errMsg += new _DTwsEvents_errMsgEventHandler(AxTws1_errMsg);

            //var scannerSubs2 = axTws2.createScannerSubscription();
            //var scan2 = new ScannerSubscription(10, TWSFramework.Enums.InstrumentType.Stk, TWSFramework.Enums.LocationType.Stk_Us,
            //                                   TWSFramework.Enums.StockTypeFilter.All, TWSFramework.Enums.ScanCodeType.Most_Active, 0, 1000);
            //scan2.RevertToTWSObject(ref scannerSubs2);
            //axTws2.reqScannerSubscriptionEx(20, scannerSubs2);
            //axTws2.errMsg += new _DTwsEvents_errMsgEventHandler(axTws2_errMsg);

        }

        private static ScannerSubscription CreateCustomScannerSubscription(TWSFramework.Enums.ScanCodeType scanCodeType, int priceBelow, int priceAbove)
        {
            return new ScannerSubscription(10, TWSFramework.Enums.InstrumentType.Stk, TWSFramework.Enums.LocationType.Stk_Nyse,
                                               TWSFramework.Enums.StockTypeFilter.Stock, scanCodeType, priceAbove, priceBelow);
        }

        private void SetUpScanner(AxTws axTws, ScannerSubscription scannerSubscription, int requestId)
        {
            //axTws.connect("", 7496, clientId);
            var scannerSubs = axTws.createScannerSubscription();
            scannerSubscription.RevertToTWSObject(ref scannerSubs);
            axTws.reqScannerSubscriptionEx(requestId, scannerSubs);
        }

        void axTws2_scannerDataEnd(object sender, _DTwsEvents_scannerDataEndEvent e)
        {
            //axTws2.disconnect();
            if(btnStart.Enabled) return;
            
            SetUpScanner(axTws2, ScannerSubscriptions[ClientId2], e.reqId + 2);
        }
        void axTws1_scannerDataEnd(object sender, _DTwsEvents_scannerDataEndEvent e)
        {
            //axTws1.disconnect();
            if (btnStart.Enabled) return;
            if (e.reqId % 2 == 0)
            {
                txtOutputValues1.Text = txtOutputValues1.Text.Trim(',') + "\r\n";
                axTws1.cancelScannerSubscription(e.reqId);
                SetUpScanner(axTws1, ScannerSubscriptions[ClientId1], e.reqId);
            }
            else
            {
                txtOutputValues2.Text = txtOutputValues2.Text.Trim(',') + "\r\n";
                axTws1.cancelScannerSubscription(e.reqId);
                SetUpScanner(axTws1, ScannerSubscriptions[ClientId2], e.reqId);
            }
        }

        void axTws2_scannerDataEx(object sender, _DTwsEvents_scannerDataExEvent e)
        {
            txtOutputValues2.Text += e.contractDetails.marketName + ",";//"Market Name: " + e.contractDetails.marketName + "; Long Name: " + e.contractDetails.longName + ",";//GetAllValues(e.contractDetails) + "\r\n";
        }

        void axTws1_scannerDataEx(object sender, _DTwsEvents_scannerDataExEvent e)
        {
            if (e.reqId % 2 == 0)
                txtOutputValues1.Text += e.contractDetails.marketName + ",";//"Market Name: " + e.contractDetails.marketName + "; Long Name: " + e.contractDetails.longName + ",";//GetAllValues(e.contractDetails) + "\r\n";
            else
            {
                txtOutputValues2.Text += e.contractDetails.marketName + ",";
            }
        }

        void axTws2_errMsg(object sender, _DTwsEvents_errMsgEvent e)
        {
            txtError.Text += GetAllValues<_DTwsEvents_errMsgEvent>(e) + "\r\n";//e.errorCode.ToString() + ": " + e.errorMsg + ": " + e.id.ToString() + "\r\n";
        }

        void axTws1_errMsg(object sender, _DTwsEvents_errMsgEvent e)
        {
            txtError.Text += GetAllValues<_DTwsEvents_errMsgEvent>(e) + "\r\n";//e.errorCode.ToString() + ": " + e.errorMsg + ": " + e.id.ToString() + "\r\n";
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            axTws1.cancelScannerSubscription(ClientId1);
            axTws2.cancelScannerSubscription(ClientId2);
            axTws1.disconnect();
            axTws2.disconnect();
            btnStart.Enabled = true;
            btnStop.Enabled = false;
        }

        private static string GetAllValues<T>(T contractDetails)
        {
            string retVal = "";
            var properties = typeof(T).GetProperties();
            foreach(var property in properties)
            {
                if (property.PropertyType != typeof(string) && property.PropertyType != typeof(int) && property.PropertyType != typeof(double) && property.PropertyType != typeof(Enum)) { continue; }
                var val = property.GetValue(contractDetails, null);
                if (val == null) continue;
                if (string.IsNullOrEmpty(val.ToString())) continue;
                retVal += property.Name + ": " + val + ",";
            }

            var fieldInfos = typeof(T).GetFields();
            foreach (var property in fieldInfos)
            {
                if (property.FieldType != typeof(string) && property.FieldType != typeof(int) && property.FieldType != typeof(double) && property.FieldType != typeof(Enum)) { continue; }
                var val = property.GetValue(contractDetails);
                if(val == null) continue;
                if (string.IsNullOrEmpty(val.ToString())) continue;
                retVal += property.Name + ": " + val.ToString() + ",";
            }
            return retVal;
        }

        private void btnCreateScanner_Click(object sender, EventArgs e)
        {
            new ScannersDataEntry().ShowDialog();
        }



        //private static void Write2File(string filename, string data)
        //{
        //    using (var streamWriter = new StreamWriter(new FileStream(filename,FileMode.Create)))
        //    {
        //        streamWriter.Write(data);
        //    }
        //}

        //private static string ConvertPropertyDetailsToCsv(string propertyDetails)
        //{
        //    var lines = propertyDetails.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
        //    var finalString = string.Empty;
        //    foreach (var line in lines)
        //    {
        //        var keyValuePairs = line.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
        //        var keysList = new List<string>();
        //        var valuesList = new List<string>();
        //        foreach (var keyValuePair in keyValuePairs)
        //        {
        //            var key = keyValuePair.Split(':')[0].Trim();
        //            keysList.Add(key);
        //            var value = keyValuePair.Split(':')[1].Trim();
        //            valuesList.Add(value);
        //        }
        //        if (finalString == "")
        //        {
        //            foreach (var key in keysList)
        //            {
        //                finalString = finalString + key + ",";
        //            }
        //            finalString.Trim(',');
        //            finalString += "\r\n";
        //        }
        //        foreach (var value in valuesList)
        //        {
        //            finalString = finalString + value + ",";
        //        }
        //        finalString.Trim(',');
        //        finalString += "\r\n";
        //    }
        //    return finalString;
        //}

        //private void button2_Click(object sender, EventArgs e)
        //{
        //    var path = Application.StartupPath.Trim('\\') + "\\" + "save1.csv";

        //    var finalString = ConvertPropertyDetailsToCsv(txtOutputValues1.Text);
            
        //    Write2File(path, finalString);
        //}

        //private void button3_Click(object sender, EventArgs e)
        //{
        //    var path = Application.StartupPath.Trim('\\') + "\\" + "save2.csv";

        //    var finalString = ConvertPropertyDetailsToCsv(txtOutputValues2.Text);

        //    Write2File(path, finalString);
        //}
        
    }
}
