﻿namespace TryTrading
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnStart = new System.Windows.Forms.Button();
            this.axTws1 = new AxTWSLib.AxTws();
            this.axTws2 = new AxTWSLib.AxTws();
            this.txtOutputValues2 = new System.Windows.Forms.TextBox();
            this.txtError = new System.Windows.Forms.TextBox();
            this.txtOutputValues1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbScanType1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMinPrice1 = new System.Windows.Forms.TextBox();
            this.txtMaxPrice1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMaxPrice2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMinPrice2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbScanType2 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnStop = new System.Windows.Forms.Button();
            this.txtClientId1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtClientId2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnCreateScanner = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.axTws1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axTws2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(13, 13);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(318, 23);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start Scanners";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.button1_Click);
            // 
            // axTws1
            // 
            this.axTws1.Enabled = true;
            this.axTws1.Location = new System.Drawing.Point(631, 329);
            this.axTws1.Name = "axTws1";
            this.axTws1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axTws1.OcxState")));
            this.axTws1.Size = new System.Drawing.Size(100, 50);
            this.axTws1.TabIndex = 1;
            // 
            // axTws2
            // 
            this.axTws2.Enabled = true;
            this.axTws2.Location = new System.Drawing.Point(479, 114);
            this.axTws2.Name = "axTws2";
            this.axTws2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axTws2.OcxState")));
            this.axTws2.Size = new System.Drawing.Size(100, 50);
            this.axTws2.TabIndex = 2;
            // 
            // txtOutputValues2
            // 
            this.txtOutputValues2.Location = new System.Drawing.Point(12, 261);
            this.txtOutputValues2.Multiline = true;
            this.txtOutputValues2.Name = "txtOutputValues2";
            this.txtOutputValues2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtOutputValues2.Size = new System.Drawing.Size(800, 169);
            this.txtOutputValues2.TabIndex = 3;
            // 
            // txtError
            // 
            this.txtError.Location = new System.Drawing.Point(13, 436);
            this.txtError.Multiline = true;
            this.txtError.Name = "txtError";
            this.txtError.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtError.Size = new System.Drawing.Size(800, 77);
            this.txtError.TabIndex = 4;
            // 
            // txtOutputValues1
            // 
            this.txtOutputValues1.Location = new System.Drawing.Point(13, 69);
            this.txtOutputValues1.Multiline = true;
            this.txtOutputValues1.Name = "txtOutputValues1";
            this.txtOutputValues1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtOutputValues1.Size = new System.Drawing.Size(800, 157);
            this.txtOutputValues1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Scanner Type:";
            // 
            // cmbScanType1
            // 
            this.cmbScanType1.FormattingEnabled = true;
            this.cmbScanType1.Location = new System.Drawing.Point(95, 40);
            this.cmbScanType1.Name = "cmbScanType1";
            this.cmbScanType1.Size = new System.Drawing.Size(235, 21);
            this.cmbScanType1.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(336, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Minimum Price:";
            // 
            // txtMinPrice1
            // 
            this.txtMinPrice1.Location = new System.Drawing.Point(420, 40);
            this.txtMinPrice1.Name = "txtMinPrice1";
            this.txtMinPrice1.Size = new System.Drawing.Size(100, 20);
            this.txtMinPrice1.TabIndex = 11;
            this.txtMinPrice1.Text = "0";
            // 
            // txtMaxPrice1
            // 
            this.txtMaxPrice1.Location = new System.Drawing.Point(610, 40);
            this.txtMaxPrice1.Name = "txtMaxPrice1";
            this.txtMaxPrice1.Size = new System.Drawing.Size(100, 20);
            this.txtMaxPrice1.TabIndex = 13;
            this.txtMaxPrice1.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(526, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Maximum Price:";
            // 
            // txtMaxPrice2
            // 
            this.txtMaxPrice2.Location = new System.Drawing.Point(610, 234);
            this.txtMaxPrice2.Name = "txtMaxPrice2";
            this.txtMaxPrice2.Size = new System.Drawing.Size(100, 20);
            this.txtMaxPrice2.TabIndex = 19;
            this.txtMaxPrice2.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(526, 237);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "Maximum Price:";
            // 
            // txtMinPrice2
            // 
            this.txtMinPrice2.Location = new System.Drawing.Point(420, 234);
            this.txtMinPrice2.Name = "txtMinPrice2";
            this.txtMinPrice2.Size = new System.Drawing.Size(100, 20);
            this.txtMinPrice2.TabIndex = 17;
            this.txtMinPrice2.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(336, 237);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "Minimum Price:";
            // 
            // cmbScanType2
            // 
            this.cmbScanType2.FormattingEnabled = true;
            this.cmbScanType2.Location = new System.Drawing.Point(95, 234);
            this.cmbScanType2.Name = "cmbScanType2";
            this.cmbScanType2.Size = new System.Drawing.Size(235, 21);
            this.cmbScanType2.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 237);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Scanner Type:";
            // 
            // btnStop
            // 
            this.btnStop.Enabled = false;
            this.btnStop.Location = new System.Drawing.Point(339, 13);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(318, 23);
            this.btnStop.TabIndex = 20;
            this.btnStop.Text = "Stop Scanners";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // txtClientId1
            // 
            this.txtClientId1.Location = new System.Drawing.Point(768, 41);
            this.txtClientId1.Name = "txtClientId1";
            this.txtClientId1.Size = new System.Drawing.Size(44, 20);
            this.txtClientId1.TabIndex = 22;
            this.txtClientId1.Text = "1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(716, 43);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "Client Id:";
            // 
            // txtClientId2
            // 
            this.txtClientId2.Location = new System.Drawing.Point(768, 234);
            this.txtClientId2.Name = "txtClientId2";
            this.txtClientId2.Size = new System.Drawing.Size(44, 20);
            this.txtClientId2.TabIndex = 24;
            this.txtClientId2.Text = "2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(716, 236);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 13);
            this.label8.TabIndex = 23;
            this.label8.Text = "Client Id:";
            // 
            // btnCreateScanner
            // 
            this.btnCreateScanner.Location = new System.Drawing.Point(663, 13);
            this.btnCreateScanner.Name = "btnCreateScanner";
            this.btnCreateScanner.Size = new System.Drawing.Size(149, 23);
            this.btnCreateScanner.TabIndex = 25;
            this.btnCreateScanner.Text = "Create Scanners";
            this.btnCreateScanner.UseVisualStyleBackColor = true;
            this.btnCreateScanner.Click += new System.EventHandler(this.btnCreateScanner_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(825, 525);
            this.Controls.Add(this.btnCreateScanner);
            this.Controls.Add(this.txtClientId2);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtClientId1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.txtMaxPrice2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtMinPrice2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmbScanType2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtMaxPrice1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtMinPrice1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbScanType1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtOutputValues1);
            this.Controls.Add(this.txtError);
            this.Controls.Add(this.txtOutputValues2);
            this.Controls.Add(this.axTws2);
            this.Controls.Add(this.axTws1);
            this.Controls.Add(this.btnStart);
            this.Name = "Form1";
            this.Text = "2 Scanners Test Form";
            ((System.ComponentModel.ISupportInitialize)(this.axTws1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axTws2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStart;
        internal AxTWSLib.AxTws axTws1;
        internal AxTWSLib.AxTws axTws2;
        private System.Windows.Forms.TextBox txtOutputValues2;
        private System.Windows.Forms.TextBox txtError;
        private System.Windows.Forms.TextBox txtOutputValues1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbScanType1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMinPrice1;
        private System.Windows.Forms.TextBox txtMaxPrice1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMaxPrice2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMinPrice2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbScanType2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.TextBox txtClientId1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtClientId2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnCreateScanner;
    }
}

