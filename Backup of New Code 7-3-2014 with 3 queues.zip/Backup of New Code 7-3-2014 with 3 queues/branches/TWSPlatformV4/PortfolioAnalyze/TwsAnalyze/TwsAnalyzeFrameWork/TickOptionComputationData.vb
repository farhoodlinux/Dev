﻿Public Class TickOptionComputationData


    Private _impVol As Double
    Private _delta As Double
    Private _gamma As Double
    Private _vega As Double
    Private _theta As Double
    Private _undPrice As Double
    Private _optionPrice As Double
    Private _requestId As Integer
    Private _tickType As OptionTickType


    Public Sub LoadFromObject(ByVal optionPrice As AxTWSLib._DTwsEvents_tickOptionComputationEvent)

        _requestId = optionPrice.id
        _impVol = optionPrice.impliedVol
        _delta = optionPrice.delta
        _gamma = optionPrice.gamma
        _vega = optionPrice.vega
        _theta = optionPrice.theta
        _undPrice = optionPrice.undPrice
        _optionPrice = optionPrice.optPrice
        _tickType = CType(optionPrice.tickType, OptionTickType)

    End Sub
    Public Property RequestID() As Integer
        Get
            Return _requestId
        End Get
        Set(ByVal value As Integer)
            _requestId = value
        End Set
    End Property

    Public Property ImpVol() As Double
        Get
            Return _impVol
        End Get
        Set(ByVal value As Double)
            _impVol = value
        End Set
    End Property

    Public Property Gamma() As Double
        Get
            Return _gamma
        End Get
        Set(ByVal value As Double)
            _gamma = value
        End Set
    End Property


    Public Property Delta() As Double
        Get
            Return _delta
        End Get
        Set(ByVal value As Double)
            _delta = value
        End Set
    End Property

    Public Property Vega() As Double
        Get
            Return _vega
        End Get
        Set(ByVal value As Double)
            _vega = value
        End Set
    End Property
    Public Property UndPrice() As Double
        Get
            Return _undPrice
        End Get
        Set(ByVal value As Double)
            _undPrice = value
        End Set
    End Property
    Public Property Theta() As Double
        Get
            Return _theta
        End Get
        Set(ByVal value As Double)
            _theta = value
        End Set
    End Property
    Public Property OptionPrice() As Double
        Get
            Return _optionPrice
        End Get
        Set(ByVal value As Double)
            _optionPrice = value
        End Set
    End Property
    Public Property TickType() As OptionTickType
        Get
            Return _tickType
        End Get
        Set(ByVal value As OptionTickType)
            _tickType = value
        End Set
    End Property
End Class


