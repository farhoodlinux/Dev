﻿Public Class MarketDataRequest

    'Items for this method are: tickerId, Contract, Generic Ticks, Snap Shot


    Private _tickerId As Integer
    Public Property TickerId() As Integer
        Get
            Return _tickerId
        End Get
        Set(ByVal value As Integer)
            _tickerId = value
        End Set
    End Property


    Private _contract As TWSLib.IContract
    Public Property Contract() As TWSLib.IContract
        Get
            Return _contract
        End Get
        Set(ByVal value As TWSLib.IContract)
            _contract = value
        End Set

    End Property


    Private _genericTicks As String
    Public Property GenericTicks() As String
        Get
            Return _genericTicks
        End Get
        Set(ByVal value As String)
            _genericTicks = value
        End Set
    End Property


    Private _snapShot As Boolean
    Public Property SnapShot() As Boolean
        Get
            Return _snapShot
        End Get
        Set(ByVal value As Boolean)
            _snapShot = value
        End Set
    End Property


End Class
