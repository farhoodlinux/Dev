﻿Imports AxTWSLib

Public Class PortfolioUpdateResponse


    Private _localSymbol As String
    Public ReadOnly Property LocalSymbol() As String
        Get
            Return _localSymbol
        End Get

    End Property


    Private _strike As Double
    Public ReadOnly Property Strike() As Double
        Get
            Return _strike
        End Get

    End Property

    Private _position As Integer
    Public ReadOnly Property Position() As Integer
        Get
            Return _position
        End Get
    End Property

    Public Sub GetFromApiObject(ByVal PortfolioUpdateItem As _DTwsEvents_updatePortfolioExEvent)

        _localSymbol = PortfolioUpdateItem.contract.localSymbol
        _strike = PortfolioUpdateItem.contract.strike
        _position = PortfolioUpdateItem.position

    End Sub

End Class
