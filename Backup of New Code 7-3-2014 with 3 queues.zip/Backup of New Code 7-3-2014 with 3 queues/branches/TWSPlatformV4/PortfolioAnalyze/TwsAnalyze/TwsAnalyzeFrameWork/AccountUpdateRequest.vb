﻿Public Class AccountUpdateRequest


    Private _accountSubscribe As Boolean
    Public Property AccountSubscribe() As Boolean
        Get
            Return _accountSubscribe
        End Get
        Set(ByVal value As Boolean)
            _accountSubscribe = value
        End Set
    End Property



    Private _accountNumber As String
    Public Property AccountNumber() As String
        Get
            Return _accountNumber
        End Get
        Set(ByVal value As String)
            _accountNumber = value
        End Set
    End Property

    Public Function RevertToApiObject() As ApiAccountUpdateRequest

        Dim apiObject As New ApiAccountUpdateRequest

        apiObject.AcctCode = AccountNumber

        If AccountSubscribe = True Then

            apiObject.Subscribe = 1

        Else
            apiObject.Subscribe = 2

        End If

        Return apiObject

    End Function


End Class
