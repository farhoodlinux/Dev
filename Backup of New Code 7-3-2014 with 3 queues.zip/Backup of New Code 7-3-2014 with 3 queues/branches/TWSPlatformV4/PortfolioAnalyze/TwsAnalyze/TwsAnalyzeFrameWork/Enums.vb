﻿''' <summary>
''' These are the different values returned for the price market data
''' </summary>
''' <remarks></remarks>
Public Enum PriceTickType
    Bid = 1
    Ask = 2
    Last = 4
    High = 6
    Low = 7
    Close = 9
End Enum

Public Enum OptionTickType
    Bid = 10
    Ask = 11
    Last = 12
End Enum
