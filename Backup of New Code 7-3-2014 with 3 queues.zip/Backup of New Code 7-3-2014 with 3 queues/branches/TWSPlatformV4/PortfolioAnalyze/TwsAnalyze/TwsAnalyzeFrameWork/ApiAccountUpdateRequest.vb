﻿Public Class ApiAccountUpdateRequest


    Private _subscribe As Integer
    Public Property Subscribe() As Integer
        Get
            Return _subscribe
        End Get
        Set(ByVal value As Integer)
            _subscribe = value
        End Set
    End Property


    Private _acctCode As String
    Public Property AcctCode() As String
        Get
            Return _acctCode
        End Get
        Set(ByVal value As String)
            _acctCode = value
        End Set
    End Property


End Class
