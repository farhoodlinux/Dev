﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PortfolioForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PortfolioForm))
        Me.BtnStart = New System.Windows.Forms.Button()
        Me.BtnStop = New System.Windows.Forms.Button()
        Me.TxtMessages = New System.Windows.Forms.TextBox()
        Me.dgvPortfolio = New System.Windows.Forms.DataGridView()
        Me.AxTws1 = New AxTWSLib.AxTws()
        Me.Description = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UndPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Price = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Strike = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Position = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ImpVol = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Delta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Gamma = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Vega = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Theta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.dgvPortfolio, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxTws1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BtnStart
        '
        Me.BtnStart.Location = New System.Drawing.Point(12, 12)
        Me.BtnStart.Name = "BtnStart"
        Me.BtnStart.Size = New System.Drawing.Size(75, 23)
        Me.BtnStart.TabIndex = 1
        Me.BtnStart.Text = "Start"
        Me.BtnStart.UseVisualStyleBackColor = True
        '
        'BtnStop
        '
        Me.BtnStop.Location = New System.Drawing.Point(93, 12)
        Me.BtnStop.Name = "BtnStop"
        Me.BtnStop.Size = New System.Drawing.Size(75, 23)
        Me.BtnStop.TabIndex = 2
        Me.BtnStop.Text = "Stop"
        Me.BtnStop.UseVisualStyleBackColor = True
        '
        'TxtMessages
        '
        Me.TxtMessages.Location = New System.Drawing.Point(12, 273)
        Me.TxtMessages.Multiline = True
        Me.TxtMessages.Name = "TxtMessages"
        Me.TxtMessages.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TxtMessages.Size = New System.Drawing.Size(363, 92)
        Me.TxtMessages.TabIndex = 3
        '
        'dgvPortfolio
        '
        Me.dgvPortfolio.AllowUserToAddRows = False
        Me.dgvPortfolio.AllowUserToDeleteRows = False
        Me.dgvPortfolio.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvPortfolio.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Description, Me.UndPrice, Me.Price, Me.Strike, Me.Position, Me.ImpVol, Me.Delta, Me.Gamma, Me.Vega, Me.Theta})
        Me.dgvPortfolio.Location = New System.Drawing.Point(12, 39)
        Me.dgvPortfolio.Name = "dgvPortfolio"
        Me.dgvPortfolio.ReadOnly = True
        Me.dgvPortfolio.RowHeadersVisible = False
        Me.dgvPortfolio.Size = New System.Drawing.Size(883, 228)
        Me.dgvPortfolio.TabIndex = 4
        '
        'AxTws1
        '
        Me.AxTws1.Enabled = True
        Me.AxTws1.Location = New System.Drawing.Point(12, 315)
        Me.AxTws1.Name = "AxTws1"
        Me.AxTws1.OcxState = CType(resources.GetObject("AxTws1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxTws1.Size = New System.Drawing.Size(100, 50)
        Me.AxTws1.TabIndex = 0
        '
        'Description
        '
        Me.Description.HeaderText = "Description"
        Me.Description.Name = "Description"
        Me.Description.ReadOnly = True
        Me.Description.Width = 200
        '
        'UndPrice
        '
        Me.UndPrice.HeaderText = "UndPrice"
        Me.UndPrice.Name = "UndPrice"
        Me.UndPrice.ReadOnly = True
        Me.UndPrice.Width = 75
        '
        'Price
        '
        Me.Price.HeaderText = "Price"
        Me.Price.Name = "Price"
        Me.Price.ReadOnly = True
        Me.Price.Width = 75
        '
        'Strike
        '
        Me.Strike.HeaderText = "Strike"
        Me.Strike.Name = "Strike"
        Me.Strike.ReadOnly = True
        Me.Strike.Width = 75
        '
        'Position
        '
        Me.Position.HeaderText = "Position"
        Me.Position.Name = "Position"
        Me.Position.ReadOnly = True
        Me.Position.Width = 75
        '
        'ImpVol
        '
        Me.ImpVol.HeaderText = "Imp. Vol"
        Me.ImpVol.Name = "ImpVol"
        Me.ImpVol.ReadOnly = True
        Me.ImpVol.Width = 75
        '
        'Delta
        '
        Me.Delta.HeaderText = "Delta"
        Me.Delta.Name = "Delta"
        Me.Delta.ReadOnly = True
        Me.Delta.Width = 75
        '
        'Gamma
        '
        Me.Gamma.HeaderText = "Gamma"
        Me.Gamma.Name = "Gamma"
        Me.Gamma.ReadOnly = True
        Me.Gamma.Width = 75
        '
        'Vega
        '
        Me.Vega.HeaderText = "Vega"
        Me.Vega.Name = "Vega"
        Me.Vega.ReadOnly = True
        Me.Vega.Width = 75
        '
        'Theta
        '
        Me.Theta.HeaderText = "Theta"
        Me.Theta.Name = "Theta"
        Me.Theta.ReadOnly = True
        Me.Theta.Width = 75
        '
        'PortfolioForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(912, 384)
        Me.Controls.Add(Me.dgvPortfolio)
        Me.Controls.Add(Me.TxtMessages)
        Me.Controls.Add(Me.BtnStop)
        Me.Controls.Add(Me.BtnStart)
        Me.Controls.Add(Me.AxTws1)
        Me.Name = "PortfolioForm"
        Me.Text = "Portfolio"
        CType(Me.dgvPortfolio, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxTws1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents AxTws1 As AxTWSLib.AxTws
    Friend WithEvents BtnStart As System.Windows.Forms.Button
    Friend WithEvents BtnStop As System.Windows.Forms.Button
    Friend WithEvents TxtMessages As System.Windows.Forms.TextBox
    Friend WithEvents dgvPortfolio As System.Windows.Forms.DataGridView
    Friend WithEvents Description As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents UndPrice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Price As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Strike As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Position As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ImpVol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Delta As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Gamma As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Vega As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Theta As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
