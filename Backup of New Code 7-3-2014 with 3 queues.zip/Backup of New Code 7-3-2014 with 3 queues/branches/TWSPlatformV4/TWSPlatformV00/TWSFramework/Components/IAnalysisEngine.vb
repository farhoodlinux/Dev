﻿Imports TWSFramework.Analysis

Namespace Components
    Public Interface IAnalysisEngine
        Event AnalysisReady(ByVal symbol As String, ByVal size As Integer, ByVal result As MarketAnalysisResult)
        Event MultiLevelAnalysisReady(ByVal symbol As String, ByVal result25 As MarketAnalysisResult, ByVal result100 As MarketAnalysisResult)
        Sub SetBid(ByVal symbol As String, ByVal value As Double)
        Sub SetAsk(ByVal symbol As String, ByVal value As Double)
        Sub SetLast(ByVal symbol As String, ByVal value As Double)
        Sub SetImpVol(ByVal symbol As String, ByVal value As Double)
        Sub TradeOccurred(ByVal symbol As String, ByVal tradeVolume As Integer)
        Sub RaiseEvents(ByVal symbol As String)
    End Interface
End Namespace