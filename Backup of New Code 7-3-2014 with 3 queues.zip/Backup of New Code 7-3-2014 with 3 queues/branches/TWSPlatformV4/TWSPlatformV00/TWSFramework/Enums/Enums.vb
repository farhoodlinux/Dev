﻿Namespace Enums

    ''' <summary>
    ''' Lists all of the possible scan codes in the system so that the user
    ''' doesn't have to
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum ScanCodeType
        Top_Perc_Gain
        Top_Perc_Lose
        Most_Active
        Not_Open
        Halted
        Hot_By_Price
        Hot_By_Volume
        Top_Trade_Count
        Top_Trade_Rate
        Top_Price_Range
        Hot_By_Price_Range
        Top_Volume_Rate
        Top_Open_Perc_Gain
        Top_Open_Perc_Lose
        High_Open_Gap
        Low_Open_Gap
        High_Opt_Imp_Volat
        Low_Opt_Imp_Volat
        Top_Opt_Imp_Volat_Gain
        Low_Opt_Imp_Volat_Lose
        High_Opt_Imp_Volat_Over_Hist
        Low_Opt_Imp_Volat_Over_Hist
        Opt_Volume_Most_Active
        Opt_Open_Interest_Most_Active
        High_Opt_Volume_Put_Call_Ratio
        Low_Opt_Volume_Put_Call_Ratio
        High_Opt_Open_Interest_Put_Call_Ratio
        Low_Opt_Open_Interest_Put_Call_Ratio
        Hot_By_Opt_Volume
        High_Synth_Bid_Rev_Nat_Yield
        Low_Synth_Ask_Rev_Nat_Yield
        High_Vs_13W_Hl
        Low_Vs_13W_Hl
        High_Vs_26W_Hl
        Low_Vs_26W_Hl
        High_Vs_52W_Hl
        Low_Vs_52W_Hl
    End Enum

    ''' <summary>
    ''' Lists the different stock types that can be used in the stock type
    ''' filter parameter
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum StockTypeFilter
        ''' <summary>
        ''' Search for all stock types
        ''' </summary>
        ''' <remarks></remarks>
        All
        ''' <summary>
        ''' Search for just stocks
        ''' </summary>
        ''' <remarks></remarks>
        Stock
        ''' <summary>
        ''' Search for just Etf's
        ''' </summary>
        ''' <remarks></remarks>
        Etf
    End Enum

    ''' <summary>
    ''' List the different instruments that can be used
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum InstrumentType
        ''' <summary>
        ''' The stock instrument type
        ''' </summary>
        ''' <remarks></remarks>
        Stk
        ''' <summary>
        ''' The US futures instrument type
        ''' </summary>
        ''' <remarks></remarks>
        Fut_Us
        ''' <summary>
        ''' The US indexes instrument type
        ''' </summary>
        ''' <remarks></remarks>
        Ind_Us
        ''' <summary>
        ''' The Efp instrument types
        ''' </summary>
        ''' <remarks></remarks>
        Efp
        ''' <summary>
        ''' The stocks NA instrument type
        ''' </summary>
        ''' <remarks></remarks>
        Stock_Na
        ''' <summary>
        ''' The futures NA instrument type
        ''' </summary>
        ''' <remarks></remarks>
        Fut_Na
        ''' <summary>
        ''' The european stock instrument type
        ''' </summary>
        ''' <remarks></remarks>
        Stock_Eu
        ''' <summary>
        ''' The european future instrument type
        ''' </summary>
        ''' <remarks></remarks>
        Fut_Eu
        ''' <summary>
        ''' The european index instrument type
        ''' </summary>
        ''' <remarks></remarks>
        Ind_Eu
        ''' <summary>
        ''' The Hong Kong stock instrument type
        ''' </summary>
        ''' <remarks></remarks>
        Stock_Hk
        ''' <summary>
        ''' The Hong Kong future instrument type
        ''' </summary>
        ''' <remarks></remarks>
        Fut_Hk
        ''' <summary>
        ''' The Hong Kong index instrument type
        ''' </summary>
        ''' <remarks></remarks>
        Ind_Hk
    End Enum

    ''' <summary>
    ''' List the different locations that can be used with an instrument
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum LocationType
        Stk_Us ' Used by Stk
        Stk_Nyse ' Used by Stk
        Stk_Amex ' Used by Stk
        Stk_Nasdaq ' Used by Stk
        Stk_Nasdaq_Nms ' Used by Stk
        Stk_Nasdaq_Scm ' Used by Stk
        Stk_Otcbb ' Used by Stk
        Fut_Us ' Used by Fut_Us
        Fut_Globex ' Used by Fut_Us
        Fut_Ecbot ' Used by Fut_Us
        Fut_Eurexus ' Used by Fut_Us
        Fut_Nymex ' Used by Fut_Us
        Ind_Us ' Used by Ind_Us
        Efp ' Used by Efp
        Stk_Na ' Used by Stock_Na
        Fut_Na ' Used by Fut_Na
        Stk_Eu ' Used by Stock_Eu
        Stk_Eu_Ibis ' Used by Stock_Eu
        Fut_Eu ' Used by Fut_Eu
        Ind_Eu ' Used by Ind_Eu
        Stk_Hk ' Used by Stock_Hk
        Fut_Hk ' Used by Fut_Hk
        Ind_Hk ' Used by Ind_Hk
    End Enum

    ''' <summary>
    ''' Different security types available within the system
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum SecurityType
        Stk
        Opt
        Fut
        Ind
        Fop
        Cash
        Bag
    End Enum

    ''' <summary>
    ''' Specifies whether an order is an open or close order
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum OpenCloseType
        SameAsParent
        Open
        Close
        Unknown
    End Enum

    ''' <summary>
    ''' For institutional customers this indicates who is making the sale
    ''' </summary>
    ''' <remarks>
    ''' If the value of this enumeration is "ThirdParty" then the
    ''' DesignatedLocation parameter must have a value in it.
    ''' </remarks>
    Public Enum ShortSaleSlotType
        NotApplicable
        ClearingBroker
        ThirdParty ' Designated Location is Required
    End Enum

    ''' <summary>
    ''' Specifies whether an order is a buy or sell action
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum ComboLegActionType
        Buy
        Sell
    End Enum

    ''' <summary>
    ''' When requesting history information this tells the method the time
    ''' span to return the data for
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum DurationType
        Seconds
        Days
        Weeks
        Months
        Years
    End Enum

    ''' <summary>
    ''' When requesting history information this tells the method the size of
    ''' the time slices to break the data into
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum BarSizeType
        OneSecond
        FiveSeconds
        FifteenSeconds
        ThirtySeconds
        OneMinute
        TwoMinutes
        ThreeMinutes
        FiveMinutes
        FifteenMinutes
        ThirtyMinutes
        OneHour
        OneDay
        OneWeek
        OneMonth
        ThreeMonths
        OneYear
    End Enum

    ''' <summary>
    ''' When requesting history information this tells the method what type of
    ''' data to return
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum WhatToShowType
        Trades
        Midpoint
        Bid
        Ask
        BidAsk
    End Enum

    ''' <summary>
    ''' These are the different values returned for the price market data
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum PriceTickType
        Bid = 1
        Ask = 2
        Last = 4
        High = 6
        Low = 7
        Close = 9
    End Enum

    ''' <summary>
    ''' These are the different values returned for the size market data
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum SizeTickType
        Bid = 0
        AskSize = 3
        LastSize = 5
        Volume = 8
        OPTION_CALL_OPEN_INTEREST = 27
        OPTION_PUT_OPEN_INTEREST = 28
        OPTION_CALL_VOLUME = 29
        OPTION_PUT_VOLUME = 30
    End Enum

    ''' <summary>
    ''' These are the different values returned for the computation market data
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum ComputationTickType
        Bid = 10
        Ask = 11
        Last = 12
    End Enum

    ''' <summary>
    ''' These are the different values returned for the generic market data
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum GenericTickType
        Low13Week = 15 ' TickTypeID: 165
        High13Week = 16 ' TickTypeID: 165
        Low26Week = 17 ' TickTypeID: 165
        High26Week = 18 ' TickTypeID: 165
        Low52Week = 19 ' TickTypeID: 165
        High52Week = 20 ' TickTypeID: 165
        AverageVolume = 21 ' TickTypeID: 165
        OptionHistoricalVolume = 23 ' TickTypeID: 104
        OptionImpliedVolume = 24 ' TickTypeID: 106
        OptionCallOpenInterest = 27 ' TickTypeID: 101
        OptionPutOpenInterest = 28 ' TickTypeID: 101
        OptionCallVolume = 29 ' TickTypeID: 100
        OptionPutVolume = 30 ' TickTypeID: 100
        IndexFuturePremium = 31 ' TickTypeID: 162
        AuctionVolume = 34 ' TickTypeID: 225
        AuctionPrice = 35 ' TickTypeID: 225
        AuctionImbalance = 36 ' TickTypeID: 225
        MarkPrice = 37 ' TickTypeID: 221
        Shortable = 46 ' TickTypeID: 236
    End Enum

    ''' <summary>
    ''' These are the different market data return types
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum MarketDataType
        Price
        Size
        Computation
        Generic
        StringValue
        EFP
    End Enum

    Public Enum ActionType

        Buy
        Sell
        Sellshort

    End Enum

    Public Enum OrderType

        Market
        MarketClass
        Limit
        LimitClass
        PegMarket
        Scale
        Stock
        Stocklimit
        Trail
        rel
        vwap
        traillimit

    End Enum

    Public Enum TradeType
        SellShort = 1
        BuyLong = 2
    End Enum

    Public Enum TradeStatus
        Open = 1
        Closed = 2
    End Enum
    Public Enum OptionTickType
        Bid = 10
        Ask = 11
        Last = 12
    End Enum
End Namespace
