﻿Imports System.Collections.Generic
Imports System.Collections
Imports System.Linq

Namespace Analysis

    Public Class MarketDataRepository
        Private _repositories As Dictionary(Of Integer, MarketDataRepositoryItem)
        Private ReadOnly Property Repositories() As Dictionary(Of Integer, MarketDataRepositoryItem)
            Get
                Return _repositories
            End Get
        End Property

        Public Sub New()
            _repositories = New Dictionary(Of Integer, MarketDataRepositoryItem)
        End Sub

        Private _count As Integer
        Public ReadOnly Property Count() As Integer
            Get
                Return _count
            End Get
        End Property

        Public Sub AddRepository(ByVal size As Integer)
            If Not _repositories.ContainsKey(size) Then
                _repositories.Add(size, New MarketDataRepositoryItem(size))
            End If
        End Sub

        Public Sub AddSnapshot(ByVal bid As Double, ByVal ask As Double, ByVal last As Double, ByVal volume As Integer, ByVal impVol As Double, ByVal time As DateTime)
            Dim snapshot = New MarketSnapshot(bid, ask, last, volume, impVol, time)
            AddSnapshot(snapshot)
        End Sub

        Public Sub AddSnapshot(ByVal snapshot As MarketSnapshot)
            For Each key In _repositories.Keys
                _repositories(key).Add(snapshot)
            Next
            _count = _count + 1
        End Sub

        Public Function GetAnalysis(ByVal size As Integer) As MarketAnalysisResult
            If Not _repositories.ContainsKey(size) Then
                Return Nothing
            End If
            If size > Count Then
                Return Nothing
            End If
            Return _repositories(size).GetAnalysis()
        End Function
    End Class
End Namespace