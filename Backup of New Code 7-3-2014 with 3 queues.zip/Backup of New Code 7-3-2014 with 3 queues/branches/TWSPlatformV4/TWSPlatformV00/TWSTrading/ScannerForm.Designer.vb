﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ScannerForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    '<System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ScannerForm))
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dgvScannerData = New System.Windows.Forms.DataGridView()
        Me.BtnStart = New System.Windows.Forms.Button()
        Me.BtnStop = New System.Windows.Forms.Button()
        Me.dgvCommon = New System.Windows.Forms.DataGridView()
        Me.Common = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgvMarketData = New System.Windows.Forms.DataGridView()
        Me.txtDebug = New System.Windows.Forms.TextBox()
        Me.AxTws1 = New AxTWSLib.AxTws()
        Me.dgvPercentages = New System.Windows.Forms.DataGridView()
        Me.btnStartMock = New System.Windows.Forms.Button()
        Me.colConstantChange = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colConstantLast = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colConstantAsk = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colConstantBid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colConstantSymbol = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgvConstantSymbols = New System.Windows.Forms.DataGridView()
        Me.chkPairSec = New System.Windows.Forms.CheckBox()
        Me.Symbol = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Bid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Ask = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Last = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Change = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Volume = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOptCallOpenInterest = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOptPutOpenInterest = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOptCallVolume = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOptPutVolume = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ImpVol = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClmSymbol = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm10BelowBid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm10AtBid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm10BidToAsk = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm10AtAsk = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm10AboveAsk = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm10AvgTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm10AvgPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm10AvgVolume = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm10AvgImpVol = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm100BelowBid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm100AtBid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm100BidToAsk = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm100AtAsk = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm100AboveAsk = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm100AvgTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm100AvgPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm100AvgVolume = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grdPercentagesClm100AvgImpVol = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.dgvScannerData, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvCommon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvMarketData, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxTws1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvPercentages, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvConstantSymbols, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvScannerData
        '
        Me.dgvScannerData.AllowUserToAddRows = False
        Me.dgvScannerData.AllowUserToDeleteRows = False
        Me.dgvScannerData.AllowUserToOrderColumns = True
        Me.dgvScannerData.AllowUserToResizeColumns = False
        Me.dgvScannerData.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvScannerData.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvScannerData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvScannerData.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgvScannerData.Location = New System.Drawing.Point(12, 12)
        Me.dgvScannerData.Name = "dgvScannerData"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvScannerData.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgvScannerData.RowHeadersVisible = False
        Me.dgvScannerData.RowTemplate.Height = 24
        Me.dgvScannerData.Size = New System.Drawing.Size(321, 271)
        Me.dgvScannerData.TabIndex = 0
        '
        'BtnStart
        '
        Me.BtnStart.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnStart.Location = New System.Drawing.Point(1130, 40)
        Me.BtnStart.Name = "BtnStart"
        Me.BtnStart.Size = New System.Drawing.Size(75, 23)
        Me.BtnStart.TabIndex = 3
        Me.BtnStart.Text = "Start"
        Me.BtnStart.UseVisualStyleBackColor = True
        '
        'BtnStop
        '
        Me.BtnStop.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnStop.Enabled = False
        Me.BtnStop.Location = New System.Drawing.Point(1130, 69)
        Me.BtnStop.Name = "BtnStop"
        Me.BtnStop.Size = New System.Drawing.Size(75, 23)
        Me.BtnStop.TabIndex = 3
        Me.BtnStop.Text = "Stop"
        Me.BtnStop.UseVisualStyleBackColor = True
        '
        'dgvCommon
        '
        Me.dgvCommon.AllowUserToAddRows = False
        Me.dgvCommon.AllowUserToDeleteRows = False
        Me.dgvCommon.AllowUserToResizeColumns = False
        Me.dgvCommon.AllowUserToResizeRows = False
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvCommon.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.dgvCommon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvCommon.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Common})
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvCommon.DefaultCellStyle = DataGridViewCellStyle5
        Me.dgvCommon.Location = New System.Drawing.Point(46, 12)
        Me.dgvCommon.Name = "dgvCommon"
        Me.dgvCommon.ReadOnly = True
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvCommon.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.dgvCommon.RowHeadersVisible = False
        Me.dgvCommon.RowTemplate.Height = 24
        Me.dgvCommon.Size = New System.Drawing.Size(79, 240)
        Me.dgvCommon.TabIndex = 5
        '
        'Common
        '
        Me.Common.HeaderText = "Common"
        Me.Common.Name = "Common"
        Me.Common.ReadOnly = True
        Me.Common.Width = 75
        '
        'dgvMarketData
        '
        Me.dgvMarketData.AllowUserToAddRows = False
        Me.dgvMarketData.AllowUserToDeleteRows = False
        Me.dgvMarketData.AllowUserToOrderColumns = True
        Me.dgvMarketData.AllowUserToResizeColumns = False
        Me.dgvMarketData.AllowUserToResizeRows = False
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvMarketData.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.dgvMarketData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvMarketData.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Symbol, Me.Bid, Me.Ask, Me.Last, Me.Change, Me.Volume, Me.colOptCallOpenInterest, Me.colOptPutOpenInterest, Me.colOptCallVolume, Me.colOptPutVolume, Me.ImpVol})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvMarketData.DefaultCellStyle = DataGridViewCellStyle8
        Me.dgvMarketData.Location = New System.Drawing.Point(339, 11)
        Me.dgvMarketData.Name = "dgvMarketData"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvMarketData.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.dgvMarketData.RowHeadersVisible = False
        Me.dgvMarketData.RowTemplate.Height = 24
        Me.dgvMarketData.Size = New System.Drawing.Size(785, 271)
        Me.dgvMarketData.TabIndex = 6
        '
        'txtDebug
        '
        Me.txtDebug.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtDebug.Location = New System.Drawing.Point(12, 289)
        Me.txtDebug.Multiline = True
        Me.txtDebug.Name = "txtDebug"
        Me.txtDebug.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDebug.Size = New System.Drawing.Size(849, 71)
        Me.txtDebug.TabIndex = 7
        '
        'AxTws1
        '
        Me.AxTws1.Enabled = True
        Me.AxTws1.Location = New System.Drawing.Point(0, 0)
        Me.AxTws1.Name = "AxTws1"
        Me.AxTws1.OcxState = CType(resources.GetObject("AxTws1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxTws1.Size = New System.Drawing.Size(100, 50)
        Me.AxTws1.TabIndex = 11
        '
        'dgvPercentages
        '
        Me.dgvPercentages.AllowUserToAddRows = False
        Me.dgvPercentages.AllowUserToDeleteRows = False
        Me.dgvPercentages.AllowUserToOrderColumns = True
        Me.dgvPercentages.AllowUserToResizeColumns = False
        Me.dgvPercentages.AllowUserToResizeRows = False
        Me.dgvPercentages.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvPercentages.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.dgvPercentages.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvPercentages.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.grdPercentagesClmSymbol, Me.grdPercentagesClm10BelowBid, Me.grdPercentagesClm10AtBid, Me.grdPercentagesClm10BidToAsk, Me.grdPercentagesClm10AtAsk, Me.grdPercentagesClm10AboveAsk, Me.grdPercentagesClm10AvgTime, Me.grdPercentagesClm10AvgPrice, Me.grdPercentagesClm10AvgVolume, Me.grdPercentagesClm10AvgImpVol, Me.grdPercentagesClm100BelowBid, Me.grdPercentagesClm100AtBid, Me.grdPercentagesClm100BidToAsk, Me.grdPercentagesClm100AtAsk, Me.grdPercentagesClm100AboveAsk, Me.grdPercentagesClm100AvgTime, Me.grdPercentagesClm100AvgPrice, Me.grdPercentagesClm100AvgVolume, Me.grdPercentagesClm100AvgImpVol})
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvPercentages.DefaultCellStyle = DataGridViewCellStyle13
        Me.dgvPercentages.Location = New System.Drawing.Point(12, 366)
        Me.dgvPercentages.Name = "dgvPercentages"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvPercentages.RowHeadersDefaultCellStyle = DataGridViewCellStyle14
        Me.dgvPercentages.RowHeadersVisible = False
        Me.dgvPercentages.RowTemplate.Height = 24
        Me.dgvPercentages.Size = New System.Drawing.Size(1191, 330)
        Me.dgvPercentages.TabIndex = 9
        '
        'btnStartMock
        '
        Me.btnStartMock.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnStartMock.Location = New System.Drawing.Point(1130, 11)
        Me.btnStartMock.Name = "btnStartMock"
        Me.btnStartMock.Size = New System.Drawing.Size(75, 23)
        Me.btnStartMock.TabIndex = 12
        Me.btnStartMock.Text = "Mock"
        Me.btnStartMock.UseVisualStyleBackColor = True
        '
        'colConstantChange
        '
        Me.colConstantChange.HeaderText = "Change"
        Me.colConstantChange.Name = "colConstantChange"
        Me.colConstantChange.ReadOnly = True
        Me.colConstantChange.Width = 75
        '
        'colConstantLast
        '
        Me.colConstantLast.HeaderText = "Last"
        Me.colConstantLast.Name = "colConstantLast"
        Me.colConstantLast.ReadOnly = True
        Me.colConstantLast.Width = 60
        '
        'colConstantAsk
        '
        Me.colConstantAsk.HeaderText = "Ask"
        Me.colConstantAsk.Name = "colConstantAsk"
        Me.colConstantAsk.ReadOnly = True
        Me.colConstantAsk.Width = 60
        '
        'colConstantBid
        '
        Me.colConstantBid.HeaderText = "Bid"
        Me.colConstantBid.Name = "colConstantBid"
        Me.colConstantBid.ReadOnly = True
        Me.colConstantBid.Width = 60
        '
        'colConstantSymbol
        '
        Me.colConstantSymbol.HeaderText = "Symbol"
        Me.colConstantSymbol.Name = "colConstantSymbol"
        Me.colConstantSymbol.ReadOnly = True
        Me.colConstantSymbol.Width = 75
        '
        'dgvConstantSymbols
        '
        Me.dgvConstantSymbols.AllowUserToAddRows = False
        Me.dgvConstantSymbols.AllowUserToDeleteRows = False
        Me.dgvConstantSymbols.AllowUserToOrderColumns = True
        Me.dgvConstantSymbols.AllowUserToResizeColumns = False
        Me.dgvConstantSymbols.AllowUserToResizeRows = False
        Me.dgvConstantSymbols.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvConstantSymbols.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.dgvConstantSymbols.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvConstantSymbols.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colConstantSymbol, Me.colConstantBid, Me.colConstantAsk, Me.colConstantLast, Me.colConstantChange})
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvConstantSymbols.DefaultCellStyle = DataGridViewCellStyle16
        Me.dgvConstantSymbols.Location = New System.Drawing.Point(867, 289)
        Me.dgvConstantSymbols.Name = "dgvConstantSymbols"
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvConstantSymbols.RowHeadersDefaultCellStyle = DataGridViewCellStyle17
        Me.dgvConstantSymbols.RowHeadersVisible = False
        Me.dgvConstantSymbols.RowTemplate.Height = 24
        Me.dgvConstantSymbols.Size = New System.Drawing.Size(336, 72)
        Me.dgvConstantSymbols.TabIndex = 13
        '
        'chkPairSec
        '
        Me.chkPairSec.AutoSize = True
        Me.chkPairSec.Checked = True
        Me.chkPairSec.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkPairSec.Location = New System.Drawing.Point(1137, 265)
        Me.chkPairSec.Name = "chkPairSec"
        Me.chkPairSec.Size = New System.Drawing.Size(66, 17)
        Me.chkPairSec.TabIndex = 14
        Me.chkPairSec.Text = "Pair Sec"
        Me.chkPairSec.UseVisualStyleBackColor = True
        '
        'Symbol
        '
        Me.Symbol.HeaderText = "Symbol"
        Me.Symbol.Name = "Symbol"
        Me.Symbol.ReadOnly = True
        Me.Symbol.Width = 65
        '
        'Bid
        '
        Me.Bid.HeaderText = "Bid"
        Me.Bid.Name = "Bid"
        Me.Bid.ReadOnly = True
        Me.Bid.Width = 60
        '
        'Ask
        '
        Me.Ask.HeaderText = "Ask"
        Me.Ask.Name = "Ask"
        Me.Ask.ReadOnly = True
        Me.Ask.Width = 60
        '
        'Last
        '
        Me.Last.HeaderText = "Last"
        Me.Last.Name = "Last"
        Me.Last.ReadOnly = True
        Me.Last.Width = 60
        '
        'Change
        '
        Me.Change.HeaderText = "Change"
        Me.Change.Name = "Change"
        Me.Change.ReadOnly = True
        Me.Change.Width = 75
        '
        'Volume
        '
        Me.Volume.HeaderText = "Volume"
        Me.Volume.Name = "Volume"
        Me.Volume.ReadOnly = True
        Me.Volume.Width = 60
        '
        'colOptCallOpenInterest
        '
        Me.colOptCallOpenInterest.HeaderText = "Call Opn Int"
        Me.colOptCallOpenInterest.Name = "colOptCallOpenInterest"
        Me.colOptCallOpenInterest.Width = 90
        '
        'colOptPutOpenInterest
        '
        Me.colOptPutOpenInterest.HeaderText = "Put Opn Int"
        Me.colOptPutOpenInterest.Name = "colOptPutOpenInterest"
        Me.colOptPutOpenInterest.Width = 90
        '
        'colOptCallVolume
        '
        Me.colOptCallVolume.HeaderText = "Cal Vol"
        Me.colOptCallVolume.Name = "colOptCallVolume"
        Me.colOptCallVolume.Width = 65
        '
        'colOptPutVolume
        '
        Me.colOptPutVolume.HeaderText = "Put Vol."
        Me.colOptPutVolume.Name = "colOptPutVolume"
        Me.colOptPutVolume.Width = 70
        '
        'ImpVol
        '
        Me.ImpVol.HeaderText = "Imp. Vol."
        Me.ImpVol.Name = "ImpVol"
        Me.ImpVol.Width = 75
        '
        'grdPercentagesClmSymbol
        '
        Me.grdPercentagesClmSymbol.HeaderText = "Symbol"
        Me.grdPercentagesClmSymbol.Name = "grdPercentagesClmSymbol"
        Me.grdPercentagesClmSymbol.Width = 60
        '
        'grdPercentagesClm10BelowBid
        '
        DataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdPercentagesClm10BelowBid.DefaultCellStyle = DataGridViewCellStyle11
        Me.grdPercentagesClm10BelowBid.HeaderText = "25 Below Bid"
        Me.grdPercentagesClm10BelowBid.Name = "grdPercentagesClm10BelowBid"
        Me.grdPercentagesClm10BelowBid.Width = 65
        '
        'grdPercentagesClm10AtBid
        '
        DataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grdPercentagesClm10AtBid.DefaultCellStyle = DataGridViewCellStyle12
        Me.grdPercentagesClm10AtBid.HeaderText = "25 At Bid"
        Me.grdPercentagesClm10AtBid.Name = "grdPercentagesClm10AtBid"
        Me.grdPercentagesClm10AtBid.Width = 65
        '
        'grdPercentagesClm10BidToAsk
        '
        Me.grdPercentagesClm10BidToAsk.HeaderText = "25 Bid - Ask"
        Me.grdPercentagesClm10BidToAsk.Name = "grdPercentagesClm10BidToAsk"
        Me.grdPercentagesClm10BidToAsk.Width = 65
        '
        'grdPercentagesClm10AtAsk
        '
        Me.grdPercentagesClm10AtAsk.HeaderText = "25 At Ask"
        Me.grdPercentagesClm10AtAsk.Name = "grdPercentagesClm10AtAsk"
        Me.grdPercentagesClm10AtAsk.Width = 65
        '
        'grdPercentagesClm10AboveAsk
        '
        Me.grdPercentagesClm10AboveAsk.HeaderText = "25 Above Ask"
        Me.grdPercentagesClm10AboveAsk.Name = "grdPercentagesClm10AboveAsk"
        Me.grdPercentagesClm10AboveAsk.Width = 65
        '
        'grdPercentagesClm10AvgTime
        '
        Me.grdPercentagesClm10AvgTime.HeaderText = "25 Avg Time"
        Me.grdPercentagesClm10AvgTime.Name = "grdPercentagesClm10AvgTime"
        Me.grdPercentagesClm10AvgTime.Width = 50
        '
        'grdPercentagesClm10AvgPrice
        '
        Me.grdPercentagesClm10AvgPrice.HeaderText = "25 Avg Price"
        Me.grdPercentagesClm10AvgPrice.Name = "grdPercentagesClm10AvgPrice"
        Me.grdPercentagesClm10AvgPrice.Width = 50
        '
        'grdPercentagesClm10AvgVolume
        '
        Me.grdPercentagesClm10AvgVolume.HeaderText = "25 Avg Vol"
        Me.grdPercentagesClm10AvgVolume.Name = "grdPercentagesClm10AvgVolume"
        Me.grdPercentagesClm10AvgVolume.Width = 50
        '
        'grdPercentagesClm10AvgImpVol
        '
        Me.grdPercentagesClm10AvgImpVol.HeaderText = "25 Imp Vol"
        Me.grdPercentagesClm10AvgImpVol.Name = "grdPercentagesClm10AvgImpVol"
        Me.grdPercentagesClm10AvgImpVol.Width = 50
        '
        'grdPercentagesClm100BelowBid
        '
        Me.grdPercentagesClm100BelowBid.HeaderText = "100 Below Bid"
        Me.grdPercentagesClm100BelowBid.Name = "grdPercentagesClm100BelowBid"
        Me.grdPercentagesClm100BelowBid.Width = 65
        '
        'grdPercentagesClm100AtBid
        '
        Me.grdPercentagesClm100AtBid.HeaderText = "100 At Bid"
        Me.grdPercentagesClm100AtBid.Name = "grdPercentagesClm100AtBid"
        Me.grdPercentagesClm100AtBid.Width = 65
        '
        'grdPercentagesClm100BidToAsk
        '
        Me.grdPercentagesClm100BidToAsk.HeaderText = "100 Bid - Ask"
        Me.grdPercentagesClm100BidToAsk.Name = "grdPercentagesClm100BidToAsk"
        Me.grdPercentagesClm100BidToAsk.Width = 65
        '
        'grdPercentagesClm100AtAsk
        '
        Me.grdPercentagesClm100AtAsk.HeaderText = "100 At Ask"
        Me.grdPercentagesClm100AtAsk.Name = "grdPercentagesClm100AtAsk"
        Me.grdPercentagesClm100AtAsk.Width = 65
        '
        'grdPercentagesClm100AboveAsk
        '
        Me.grdPercentagesClm100AboveAsk.HeaderText = "100 Above Ask"
        Me.grdPercentagesClm100AboveAsk.Name = "grdPercentagesClm100AboveAsk"
        Me.grdPercentagesClm100AboveAsk.Width = 65
        '
        'grdPercentagesClm100AvgTime
        '
        Me.grdPercentagesClm100AvgTime.HeaderText = "100 Avg Time"
        Me.grdPercentagesClm100AvgTime.Name = "grdPercentagesClm100AvgTime"
        Me.grdPercentagesClm100AvgTime.Width = 50
        '
        'grdPercentagesClm100AvgPrice
        '
        Me.grdPercentagesClm100AvgPrice.HeaderText = "100 Avg Price"
        Me.grdPercentagesClm100AvgPrice.Name = "grdPercentagesClm100AvgPrice"
        Me.grdPercentagesClm100AvgPrice.Width = 50
        '
        'grdPercentagesClm100AvgVolume
        '
        Me.grdPercentagesClm100AvgVolume.HeaderText = "100 Avg Vol"
        Me.grdPercentagesClm100AvgVolume.Name = "grdPercentagesClm100AvgVolume"
        Me.grdPercentagesClm100AvgVolume.Width = 50
        '
        'grdPercentagesClm100AvgImpVol
        '
        Me.grdPercentagesClm100AvgImpVol.HeaderText = "100 Imp Vol"
        Me.grdPercentagesClm100AvgImpVol.Name = "grdPercentagesClm100AvgImpVol"
        Me.grdPercentagesClm100AvgImpVol.Width = 50
        '
        'ScannerForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1215, 708)
        Me.Controls.Add(Me.chkPairSec)
        Me.Controls.Add(Me.dgvConstantSymbols)
        Me.Controls.Add(Me.btnStartMock)
        Me.Controls.Add(Me.dgvPercentages)
        Me.Controls.Add(Me.txtDebug)
        Me.Controls.Add(Me.dgvMarketData)
        Me.Controls.Add(Me.BtnStop)
        Me.Controls.Add(Me.BtnStart)
        Me.Controls.Add(Me.dgvScannerData)
        Me.Controls.Add(Me.dgvCommon)
        Me.Controls.Add(Me.AxTws1)
        Me.Name = "ScannerForm"
        Me.Text = "Scanner Window"
        CType(Me.dgvScannerData, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvCommon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvMarketData, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxTws1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvPercentages, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvConstantSymbols, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgvScannerData As System.Windows.Forms.DataGridView
    Friend WithEvents BtnStart As System.Windows.Forms.Button
    Friend WithEvents BtnStop As System.Windows.Forms.Button
    Friend WithEvents dgvCommon As System.Windows.Forms.DataGridView
    Friend WithEvents dgvMarketData As System.Windows.Forms.DataGridView
    Friend WithEvents txtDebug As System.Windows.Forms.TextBox
    Friend WithEvents Common As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dgvPercentages As System.Windows.Forms.DataGridView
    Private WithEvents AxTws1 As AxTWSLib.AxTws
    Friend WithEvents btnStartMock As System.Windows.Forms.Button
    Friend WithEvents colConstantChange As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colConstantLast As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colConstantAsk As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colConstantBid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colConstantSymbol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dgvConstantSymbols As System.Windows.Forms.DataGridView
    Friend WithEvents chkPairSec As System.Windows.Forms.CheckBox
    Friend WithEvents Symbol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Bid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Ask As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Last As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Change As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Volume As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colOptCallOpenInterest As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colOptPutOpenInterest As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colOptCallVolume As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colOptPutVolume As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ImpVol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClmSymbol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm10BelowBid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm10AtBid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm10BidToAsk As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm10AtAsk As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm10AboveAsk As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm10AvgTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm10AvgPrice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm10AvgVolume As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm10AvgImpVol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm100BelowBid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm100AtBid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm100BidToAsk As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm100AtAsk As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm100AboveAsk As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm100AvgTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm100AvgPrice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm100AvgVolume As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grdPercentagesClm100AvgImpVol As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
