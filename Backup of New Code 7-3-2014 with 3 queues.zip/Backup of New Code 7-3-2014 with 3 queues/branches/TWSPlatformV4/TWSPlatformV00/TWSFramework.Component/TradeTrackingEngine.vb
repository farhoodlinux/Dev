﻿Imports System.Collections.Generic
Imports System.Windows.Forms
Imports System.Drawing
Imports TWSFramework.Enums
Imports TWSFramework.Data
Imports DataAccessLayer
' this code was commited on June 2

Public Class TradeTrackingEngine
    Implements ITradeTrackingEngine

#Region "Properties"
    Private _timer As Timer
    Private _isTradeTime As Boolean
    Private _appSettings As AppSettings
    Public ReadOnly Property AppSettings() As AppSettings
        Get
            If _appSettings Is Nothing Then
                _appSettings = DataLayer.GetAppSettings(False)
            End If
            Return _appSettings
        End Get
    End Property

    Private ReadOnly Property APIHostAddress As String
        Get
            Return AppSettings.APIHostAddress
        End Get
    End Property

    Private ReadOnly Property APIPort As Integer
        Get
            Return AppSettings.APIPort
        End Get
    End Property

    Private ReadOnly Property ClientId As Integer
        Get
            Return 2000
        End Get
    End Property

    Private _maxOpenOrders As Integer
    Public Property MaxOpenOrders() As Integer
        Get
            Return _maxOpenOrders
        End Get
        Set(ByVal value As Integer)
            _maxOpenOrders = value
        End Set
    End Property

    Private ReadOnly Property ProfitDeltaModeEnabled() As Boolean
        Get
            Return chkProfitDelta.Checked
        End Get
    End Property

#End Region

#Region "Components"
    Private Shared _instance As ITradeTrackingEngine
    Public Shared ReadOnly Property Instance As ITradeTrackingEngine
        Get
            If _instance Is Nothing Then
                _instance = New TradeTrackingEngine()
            End If
            Return _instance
        End Get
    End Property

    Private _dataLayer As DataLayer
    Private ReadOnly Property DataLayer As DataLayer
        Get
            If _dataLayer Is Nothing Then
                _dataLayer = New DataLayer()
            End If
            Return _dataLayer
        End Get
    End Property

    Private _marketWatcher As MarketWatcher
    Public ReadOnly Property MarketWatcher() As MarketWatcher
        Get
            Return _marketWatcher
        End Get
    End Property
#End Region

#Region "Buffers"
    Private _sellDataBuffer As Dictionary(Of String, TradeSnapshot)
    Private Property SellDataBuffer() As Dictionary(Of String, TradeSnapshot)
        Get
            Return _sellDataBuffer
        End Get
        Set(ByVal value As Dictionary(Of String, TradeSnapshot))
            _sellDataBuffer = value
        End Set
    End Property

    Private _buyDataBuffer As Dictionary(Of String, TradeSnapshot)
    Private Property BuyDataBuffer() As Dictionary(Of String, TradeSnapshot)
        Get
            Return _buyDataBuffer
        End Get
        Set(ByVal value As Dictionary(Of String, TradeSnapshot))
            _buyDataBuffer = value
        End Set
    End Property

    Private _buyPairTradeBuffer As Dictionary(Of String, TradeSnapshot)
    Private Property BuyPairTradeBuffer() As Dictionary(Of String, TradeSnapshot)
        Get
            Return _buyPairTradeBuffer
        End Get
        Set(value As Dictionary(Of String, TradeSnapshot))
            _buyPairTradeBuffer = value
        End Set
    End Property

    Private _sellPairTradeBuffer As Dictionary(Of String, TradeSnapshot)
    Private Property SellPairTradeBuffer() As Dictionary(Of String, TradeSnapshot)
        Get
            Return _sellPairTradeBuffer
        End Get
        Set(value As Dictionary(Of String, TradeSnapshot))
            _sellPairTradeBuffer = value
        End Set
    End Property

    Private _buyTempList As List(Of String)
    Public Property BuyTempList() As List(Of String)
        Get
            Return _buyTempList
        End Get
        Set(ByVal value As List(Of String))
            _buyTempList = value
        End Set
    End Property

    Private _sellTempList As List(Of String)
    Public Property SellTempList() As List(Of String)
        Get
            Return _sellTempList
        End Get
        Set(ByVal value As List(Of String))
            _sellTempList = value
        End Set
    End Property

    Private _maxProfitDictionary As Dictionary(Of String, Double)
    Public Property MaxProfitDictionary() As Dictionary(Of String, Double)
        Get
            If _maxProfitDictionary Is Nothing Then
                _maxProfitDictionary = New Dictionary(Of String, Double)
            End If
            Return _maxProfitDictionary
        End Get
        Set(ByVal value As Dictionary(Of String, Double))
            _maxProfitDictionary = value
        End Set
    End Property

    Private _maxLongTermProfitDictionary As Dictionary(Of String, Double)
    Public Property MaxLongTermProfitDictionary() As Dictionary(Of String, Double) Implements ITradeTrackingEngine.MaxLongTermProfitDictionary
        Get
            If _maxLongTermProfitDictionary Is Nothing Then
                _maxLongTermProfitDictionary = New Dictionary(Of String, Double)
            End If
            Return _maxLongTermProfitDictionary
        End Get
        Set(ByVal value As Dictionary(Of String, Double))
            _maxLongTermProfitDictionary = value
        End Set
    End Property

    Private _maxPairedProfitDictionary As Dictionary(Of String, Tuple(Of Double, Double))
    Public Property MaxPairedProfitDictionary() As Dictionary(Of String, Tuple(Of Double, Double))
        Get
            If _maxPairedProfitDictionary Is Nothing Then
                _maxPairedProfitDictionary = New Dictionary(Of String, Tuple(Of Double, Double))
            End If
            Return _maxPairedProfitDictionary
        End Get
        Set(ByVal value As Dictionary(Of String, Tuple(Of Double, Double)))
            _maxPairedProfitDictionary = value
        End Set
    End Property

    Private _tradeTimeDictionary As Dictionary(Of String, DateTime)
    Public Property TradeTimeDictionary() As Dictionary(Of String, DateTime)
        Get
            Return _tradeTimeDictionary
        End Get
        Set(ByVal value As Dictionary(Of String, DateTime))
            _tradeTimeDictionary = value
        End Set
    End Property

    Private _startedWatchingDictionary As Dictionary(Of String, DateTime)
    Public Property StartedWatchingDictionary() As Dictionary(Of String, DateTime)
        Get
            Return _startedWatchingDictionary
        End Get
        Set(ByVal value As Dictionary(Of String, DateTime))
            _startedWatchingDictionary = value
        End Set
    End Property

#End Region

#Region "Methods"
    Public Sub New()
        InitializeComponent()
    End Sub



    Private Sub RebindGrid()
        dgvTrades.Rows.Clear()
        For Each item As TradeSnapshot In BuyDataBuffer.Values
            Dim rowIndex = dgvTrades.Rows.Add(item.Symbol, item.Price, item.Quantity, "BUY")
            dgvTrades.Rows(rowIndex).Cells(0).Style.BackColor = Color.LightGreen
            dgvTrades.Rows(rowIndex).Cells(1).Style.BackColor = Color.LightGreen
            dgvTrades.Rows(rowIndex).Cells(2).Style.BackColor = Color.LightGreen
            dgvTrades.Rows(rowIndex).Cells(3).Style.BackColor = Color.LightGreen
            dgvTrades.Rows(rowIndex).Cells(4).Style.BackColor = Color.LightGreen
            dgvTrades.Rows(rowIndex).Cells(5).Style.BackColor = Color.LightGreen

            If SellPairTradeBuffer.ContainsKey(item.Symbol) Then
                dgvTrades.Rows(rowIndex).Cells("PairSymbol").Value = SellPairTradeBuffer(item.Symbol).Symbol
                dgvTrades.Rows(rowIndex).Cells("PairPrice").Value = SellPairTradeBuffer(item.Symbol).Price
                dgvTrades.Rows(rowIndex).Cells("PairQuantity").Value = SellPairTradeBuffer(item.Symbol).Quantity
                dgvTrades.Rows(rowIndex).Cells("PairAction").Value = "SELL"
                dgvTrades.Rows(rowIndex).Cells(6).Style.BackColor = Color.LightSalmon
                dgvTrades.Rows(rowIndex).Cells(7).Style.BackColor = Color.LightSalmon
                dgvTrades.Rows(rowIndex).Cells(8).Style.BackColor = Color.LightSalmon
                dgvTrades.Rows(rowIndex).Cells(9).Style.BackColor = Color.LightSalmon
                dgvTrades.Rows(rowIndex).Cells(10).Style.BackColor = Color.LightSalmon
                dgvTrades.Rows(rowIndex).Cells(11).Style.BackColor = Color.LightSalmon
            End If
        Next

        For Each item As TradeSnapshot In SellDataBuffer.Values
            Dim rowIndex = dgvTrades.Rows.Add(item.Symbol, item.Price, item.Quantity, "SELL")
            dgvTrades.Rows(rowIndex).Cells(0).Style.BackColor = Color.LightSalmon
            dgvTrades.Rows(rowIndex).Cells(1).Style.BackColor = Color.LightSalmon
            dgvTrades.Rows(rowIndex).Cells(2).Style.BackColor = Color.LightSalmon
            dgvTrades.Rows(rowIndex).Cells(3).Style.BackColor = Color.LightSalmon
            dgvTrades.Rows(rowIndex).Cells(4).Style.BackColor = Color.LightSalmon
            dgvTrades.Rows(rowIndex).Cells(5).Style.BackColor = Color.LightSalmon
            If BuyPairTradeBuffer.ContainsKey(item.Symbol) Then
                dgvTrades.Rows(rowIndex).Cells("PairSymbol").Value = BuyPairTradeBuffer(item.Symbol).Symbol
                dgvTrades.Rows(rowIndex).Cells("PairPrice").Value = BuyPairTradeBuffer(item.Symbol).Price
                dgvTrades.Rows(rowIndex).Cells("PairAction").Value = "BUY"
                dgvTrades.Rows(rowIndex).Cells("PairQuantity").Value = BuyPairTradeBuffer(item.Symbol).Quantity
                dgvTrades.Rows(rowIndex).Cells(6).Style.BackColor = Color.LightGreen
                dgvTrades.Rows(rowIndex).Cells(7).Style.BackColor = Color.LightGreen
                dgvTrades.Rows(rowIndex).Cells(8).Style.BackColor = Color.LightGreen
                dgvTrades.Rows(rowIndex).Cells(9).Style.BackColor = Color.LightGreen
                dgvTrades.Rows(rowIndex).Cells(10).Style.BackColor = Color.LightGreen
                dgvTrades.Rows(rowIndex).Cells(11).Style.BackColor = Color.LightGreen
            End If
        Next
    End Sub

    Private Sub UpdateCurrentPrice(symbolToUpdate As String, priceToUpdate As Double)
        For Each row As DataGridViewRow In dgvTrades.Rows
            If row.Cells("Symbol").Value.Equals(symbolToUpdate) Then
                row.Cells("CurrentPrice").Value = priceToUpdate
                If BuyDataBuffer.ContainsKey(symbolToUpdate) Then
                    If SellPairTradeBuffer.ContainsKey(symbolToUpdate) Then
                        Dim profit = (priceToUpdate - BuyDataBuffer(symbolToUpdate).Price)
                        row.Cells("ProfitPercent").Value = (profit / BuyDataBuffer(symbolToUpdate).Price).ToString("P2")
                        Dim sellPairCurrentPrice = IntelligentTrader.Instance.MarketData(SellPairTradeBuffer(symbolToUpdate).Symbol).Last
                        row.Cells("PairCurrentPrice").Value = sellPairCurrentPrice
                        row.Cells("PairProfitPercent").Value = (((SellPairTradeBuffer(symbolToUpdate).Price - sellPairCurrentPrice) / SellPairTradeBuffer(symbolToUpdate).Price)).ToString("P2")
                        'If String.IsNullOrEmpty(row.Cells("PairSymbol").Value) Then
                        '    row.Cells("PairSymbol").Value = SellPairTradeBuffer(symbolToUpdate).Symbol
                        '    row.Cells("PairPrice").Value = SellPairTradeBuffer(symbolToUpdate).Price
                        '    row.Cells("PairAction").Value = "SELL"
                        '    row.Cells(6).Style.BackColor = Color.LightSalmon
                        '    row.Cells(7).Style.BackColor = Color.LightSalmon
                        '    row.Cells(8).Style.BackColor = Color.LightSalmon
                        '    row.Cells(9).Style.BackColor = Color.LightSalmon
                        '    row.Cells(10).Style.BackColor = Color.LightSalmon
                        '    row.Cells(11).Style.BackColor = Color.LightSalmon
                        'End If
                        'Dim sellPairProfit = SellPairTradeBuffer(symbolToUpdate).Price - IntelligentTrader.Instance.MarketData(SellPairTradeBuffer(symbolToUpdate).Symbol).Last
                        'row.Cells("TotalProfitPercent").Value = (((profit * 100) / BuyDataBuffer(symbolToUpdate).Price) + ((sellPairProfit * 100) / SellPairTradeBuffer(symbolToUpdate).Price)) / 2
                        'row.Cells("TotalProfitPercent").Value = ((profit + sellPairProfit) / (BuyDataBuffer(symbolToUpdate).Price + SellPairTradeBuffer(symbolToUpdate).Price)) * 100
                        row.Cells("TotalProfitPercent").Value = (Utilities.GetSellProfitPercent(BuyDataBuffer(symbolToUpdate).Price, priceToUpdate, BuyDataBuffer(symbolToUpdate).Quantity, SellPairTradeBuffer(symbolToUpdate).Price, sellPairCurrentPrice, SellPairTradeBuffer(symbolToUpdate).Quantity)).ToString("P2")

                    Else
                        Dim profit = priceToUpdate - BuyDataBuffer(symbolToUpdate).Price
                        Dim profitPercentVal As Double = (profit) / BuyDataBuffer(symbolToUpdate).Price
                        row.Cells("ProfitPercent").Value = profitPercentVal.ToString("P2")
                        row.Cells("TotalProfitPercent").Value = profitPercentVal.ToString("P2")
                    End If
                    If MaxLongTermProfitDictionary.ContainsKey(symbolToUpdate) Then
                        row.Cells("MaxProfitPercent").Value = MaxLongTermProfitDictionary(symbolToUpdate).ToString("P2")
                    End If
                    Return
                End If
                If SellDataBuffer.ContainsKey(symbolToUpdate) Then
                    If BuyPairTradeBuffer.ContainsKey(symbolToUpdate) Then
                        Dim profit = SellDataBuffer(symbolToUpdate).Price - priceToUpdate
                        row.Cells("ProfitPercent").Value = (profit / SellDataBuffer(symbolToUpdate).Price).ToString("P2")
                        Dim buyPairCurrentPrice = IntelligentTrader.Instance.MarketData(BuyPairTradeBuffer(symbolToUpdate).Symbol).Last
                        row.Cells("PairCurrentPrice").Value = buyPairCurrentPrice
                        row.Cells("PairProfitPercent").Value = (((buyPairCurrentPrice - BuyPairTradeBuffer(symbolToUpdate).Price) / BuyPairTradeBuffer(symbolToUpdate).Price)).ToString("P2")
                        'Dim buyPairProfit = IntelligentTrader.Instance.MarketData(BuyPairTradeBuffer(symbolToUpdate).Symbol).Last - BuyPairTradeBuffer(symbolToUpdate).Price
                        'row.Cells("TotalProfitPercent").Value = (((profit * 100) / SellDataBuffer(symbolToUpdate).Price) + ((buyPairProfit * 100) / BuyPairTradeBuffer(symbolToUpdate).Price)) / 2
                        'row.Cells("TotalProfitPercent").Value = ((profit + buyPairProfit) / (SellDataBuffer(symbolToUpdate).Price + BuyPairTradeBuffer(symbolToUpdate).Price)) * 100
                        row.Cells("TotalProfitPercent").Value = (Utilities.GetBuyProfitPercent(SellDataBuffer(symbolToUpdate).Price, priceToUpdate, SellDataBuffer(symbolToUpdate).Quantity, BuyPairTradeBuffer(symbolToUpdate).Price, buyPairCurrentPrice, BuyPairTradeBuffer(symbolToUpdate).Quantity)).ToString("P2")
                    Else
                        Dim profit = SellDataBuffer(symbolToUpdate).Price - priceToUpdate
                        Dim profitPercentVal As Double = (profit) / SellDataBuffer(symbolToUpdate).Price
                        row.Cells("ProfitPercent").Value = profitPercentVal.ToString("P2")
                        row.Cells("TotalProfitPercent").Value = profitPercentVal.ToString("P2")
                    End If
                    If MaxLongTermProfitDictionary.ContainsKey(symbolToUpdate) Then
                        row.Cells("MaxProfitPercent").Value = MaxLongTermProfitDictionary(symbolToUpdate).ToString("P2")
                    End If
                    Return
                End If
            End If
        Next
    End Sub

    Private Function ShouldSellBackWithPairTrade(symbol As String, boughtPrice As Double, currentPrice As Double)
        'TODO: These conditions need to be verified for correctness.
        Dim pairedSecurityTransaction = SellPairTradeBuffer(symbol)
        Dim pairedSecuritySoldPrice = pairedSecurityTransaction.Price
        Dim pairedSecurityCurrentPrice = IntelligentTrader.Instance.MarketData(pairedSecurityTransaction.Symbol).Last
        Dim quantity = BuyDataBuffer(symbol).Quantity
        If ProfitDeltaModeEnabled Then
            'If Not MaxProfitDictionary.ContainsKey(symbol) Then
            '    MaxProfitDictionary.Add(symbol, boughtPrice)
            'End If

            If Not MaxPairedProfitDictionary.ContainsKey(symbol) Then
                MaxPairedProfitDictionary.Add(symbol, Tuple.Create(boughtPrice, pairedSecuritySoldPrice))
            End If

            Dim maxProfitPrice As Double = 0.0
            Dim maxPairedProfitPrice As Double = 0

            'Dim currentProfit As Double = (((currentPrice - boughtPrice) / boughtPrice) + ((pairedSecuritySoldPrice - pairedSecurityCurrentPrice) / pairedSecuritySoldPrice)) / 2
            'Dim currentProfit As Double = ((currentPrice - boughtPrice) + (pairedSecuritySoldPrice - pairedSecurityCurrentPrice)) / (boughtPrice + pairedSecuritySoldPrice)
            Dim currentProfit As Double = Utilities.GetSellProfitPercent(boughtPrice, currentPrice, quantity, pairedSecuritySoldPrice, pairedSecurityCurrentPrice, pairedSecurityTransaction.Quantity)
            AddToMaxLongTermProfit(symbol, currentProfit)
            If currentProfit > 0 Then
                maxProfitPrice = currentPrice
                maxPairedProfitPrice = pairedSecurityCurrentPrice
            Else
                maxProfitPrice = boughtPrice
                maxPairedProfitPrice = pairedSecuritySoldPrice
            End If

            'Dim maxProfit = (((currentPrice - MaxPairedProfitDictionary(symbol).Item1) / MaxPairedProfitDictionary(symbol).Item1) + ((pairedSecuritySoldPrice - MaxPairedProfitDictionary(symbol).Item2) / MaxPairedProfitDictionary(symbol).Item2)) / 2
            'Dim maxProfit = ((currentPrice - MaxPairedProfitDictionary(symbol).Item1) + (pairedSecuritySoldPrice - MaxPairedProfitDictionary(symbol).Item2)) / (MaxPairedProfitDictionary(symbol).Item1 + MaxPairedProfitDictionary(symbol).Item2)
            'Dim maxProfit = Utilities.GetSellProfitPercent(MaxPairedProfitDictionary(symbol).Item1, currentPrice, quantity, MaxPairedProfitDictionary(symbol).Item2, pairedSecurityCurrentPrice, pairedSecurityTransaction.Quantity)
            Dim maxProfit = Utilities.GetSellProfitPercent(boughtPrice, MaxPairedProfitDictionary(symbol).Item1, quantity, pairedSecuritySoldPrice, MaxPairedProfitDictionary(symbol).Item2, pairedSecurityTransaction.Quantity)
            If maxProfit < currentProfit Then
                MaxPairedProfitDictionary(symbol) = Tuple.Create(maxProfitPrice, maxPairedProfitPrice)
            Else
                maxProfitPrice = MaxPairedProfitDictionary(symbol).Item1
                maxPairedProfitPrice = MaxPairedProfitDictionary(symbol).Item2
            End If

            'Security Specific Delta. Check if profit is more than threshold, then set the loss threshold to a lower configured value.
            Dim closeProfitValue = AppSettings.BuyLongDeltaCloseProfitBelow

            'If (((maxProfitPrice - boughtPrice) / boughtPrice) + ((pairedSecuritySoldPrice - maxPairedProfitPrice) / pairedSecuritySoldPrice)) / 2 >= AppSettings.SecuritySpecificDeltaProfitThreshold Then
            '    closeProfitValue = AppSettings.SecuritySpecificDeltaProfitValue
            'End If

            'If (((maxProfitPrice - boughtPrice) + (pairedSecuritySoldPrice - maxPairedProfitPrice)) / (boughtPrice + pairedSecuritySoldPrice)) >= AppSettings.SecuritySpecificDeltaProfitThreshold Then
            '    closeProfitValue = AppSettings.SecuritySpecificDeltaProfitValue
            'End If

            If Utilities.GetSellProfitPercent(boughtPrice, maxProfitPrice, quantity, pairedSecuritySoldPrice, maxPairedProfitPrice, pairedSecurityTransaction.Quantity) >= AppSettings.SecuritySpecificDeltaProfitThreshold Then
                closeProfitValue = AppSettings.SecuritySpecificDeltaProfitValue
            End If

            'Dim currentDeltaProfit As Double = ((currentPrice - maxProfitPrice) + (maxPairedProfitPrice - pairedSecurityCurrentPrice)) / (maxProfitPrice + maxPairedProfitPrice)
            Dim currentDeltaProfit As Double = Utilities.GetSellProfitPercent(maxProfitPrice, currentPrice, quantity, maxPairedProfitPrice, pairedSecurityCurrentPrice, pairedSecurityTransaction.Quantity)
            If currentDeltaProfit < closeProfitValue Then
                AdvancedMockTradingEngine.WriteToFile("Sell Decision. Max Profit Price: " & maxProfitPrice & " Current Price: " & currentPrice & " Max Paired Profit Price: " & maxPairedProfitPrice & " Current Paired Price: " & pairedSecurityCurrentPrice)
                MaxPairedProfitDictionary.Remove(symbol)
                AddToTradeTimeDictionary(symbol)
                RemoveFromMaxLongTermProfit(symbol)
                Return True
            End If
        Else
            'Dim currentProfit As Double = (((currentPrice - boughtPrice) / boughtPrice) + ((pairedSecuritySoldPrice - pairedSecurityCurrentPrice) / pairedSecuritySoldPrice)) / 2
            'Dim currentProfit As Double = ((currentPrice - boughtPrice) + (pairedSecuritySoldPrice - pairedSecurityCurrentPrice)) / (boughtPrice + pairedSecuritySoldPrice)
            Dim currentProfit As Double = Utilities.GetSellProfitPercent(boughtPrice, currentPrice, quantity, pairedSecuritySoldPrice, pairedSecurityCurrentPrice, pairedSecurityTransaction.Quantity)
            AddToMaxLongTermProfit(symbol, currentProfit)
            If currentProfit > AppSettings.BuyLongCloseProfitAbove Or currentProfit < AppSettings.BuyLongCloseProfitBelow Then
                AdvancedMockTradingEngine.WriteToFile("Sell Decision. Bought Price: " & boughtPrice & " Current Price: " & currentPrice)
                If MaxPairedProfitDictionary.ContainsKey(symbol) Then
                    MaxPairedProfitDictionary.Remove(symbol)
                End If
                AddToTradeTimeDictionary(symbol)
                RemoveFromMaxLongTermProfit(symbol)
                Return True
            End If
        End If

        Return False
    End Function

    Private Function ShouldSellBack(symbol As String, boughtPrice As Double, currentPrice As Double)
        'TODO: These conditions need to be verified for correctness.
        If ProfitDeltaModeEnabled Then

            If Not MaxProfitDictionary.ContainsKey(symbol) Then
                MaxProfitDictionary.Add(symbol, boughtPrice)
            End If

            Dim maxProfitPrice As Double = 0.0

            If currentPrice > boughtPrice Then
                maxProfitPrice = currentPrice
            Else
                maxProfitPrice = boughtPrice
            End If

            If maxProfitPrice <= MaxProfitDictionary(symbol) Then
                maxProfitPrice = MaxProfitDictionary(symbol)
            Else
                MaxProfitDictionary(symbol) = maxProfitPrice
            End If

            'Security Specific Delta. Check if profit is more than threshold, then set the loss threshold to a lower configured value.
            Dim closeProfitValue = AppSettings.BuyLongDeltaCloseProfitBelow

            If (maxProfitPrice - boughtPrice) / boughtPrice >= AppSettings.SecuritySpecificDeltaProfitThreshold Then
                closeProfitValue = AppSettings.SecuritySpecificDeltaProfitValue
            End If

            If (currentPrice - maxProfitPrice) / maxProfitPrice < closeProfitValue Then
                AdvancedMockTradingEngine.WriteToFile("Sell Decision. Max Profit Price: " & maxProfitPrice & " Current Price: " & currentPrice)
                MaxProfitDictionary.Remove(symbol)
                AddToTradeTimeDictionary(symbol)
                Return True
            End If
        Else
            If (currentPrice - boughtPrice) / boughtPrice > AppSettings.BuyLongCloseProfitAbove Or (currentPrice - boughtPrice) / boughtPrice < AppSettings.BuyLongCloseProfitBelow Then
                AdvancedMockTradingEngine.WriteToFile("Sell Decision. Bought Price: " & boughtPrice & " Current Price: " & currentPrice)
                If MaxProfitDictionary.ContainsKey(symbol) Then
                    MaxProfitDictionary.Remove(symbol)
                End If
                AddToTradeTimeDictionary(symbol)
                Return True
            End If
        End If

        Return False
    End Function

    Private Sub AddToMaxLongTermProfit(symbol As String, currentProfit As Double)
        If Not MaxLongTermProfitDictionary.ContainsKey(symbol) Then
            MaxLongTermProfitDictionary.Add(symbol, 0)
        End If
        If MaxLongTermProfitDictionary(symbol) < currentProfit Then
            MaxLongTermProfitDictionary(symbol) = currentProfit
        End If
    End Sub

    Private Sub RemoveFromMaxLongTermProfit(symbol As String)
        If MaxLongTermProfitDictionary.ContainsKey(symbol) Then
            MaxLongTermProfitDictionary.Remove(symbol)
        End If
    End Sub

    Private Function ShouldBuyBackWithPairTrade(symbol As String, soldPrice As Double, currentPrice As Double)
        'TODO: These conditions need to be verified for correctness.
        Dim pairedSecurityTransaction = BuyPairTradeBuffer(symbol)
        Dim pairedSecurityBoughtPrice = pairedSecurityTransaction.Price
        Dim pairedSecurityCurrentPrice = IntelligentTrader.Instance.MarketData(pairedSecurityTransaction.Symbol).Last
        Dim quantity = SellDataBuffer(symbol).Quantity
        If ProfitDeltaModeEnabled Then

            If Not MaxPairedProfitDictionary.ContainsKey(symbol) Then
                MaxPairedProfitDictionary.Add(symbol, Tuple.Create(soldPrice, pairedSecurityBoughtPrice))
            End If

            Dim maxProfitPrice As Double = 0.0
            Dim maxPairedProfitPrice As Double = 0

            'Dim currentProfit As Double = ((soldPrice - currentPrice) / soldPrice + ((pairedSecurityCurrentPrice - pairedSecurityBoughtPrice) / pairedSecurityBoughtPrice)) / 2
            'Dim currentProfit As Double = ((soldPrice - currentPrice) + (pairedSecurityCurrentPrice - pairedSecurityBoughtPrice)) / (soldPrice + pairedSecurityBoughtPrice)
            Dim currentProfit As Double = Utilities.GetBuyProfitPercent(soldPrice, currentPrice, quantity, pairedSecurityBoughtPrice, pairedSecurityCurrentPrice, pairedSecurityTransaction.Quantity)

            AddToMaxLongTermProfit(symbol, currentProfit)

            If currentProfit > 0 Then
                maxProfitPrice = currentPrice
                maxPairedProfitPrice = pairedSecurityCurrentPrice
            Else
                maxProfitPrice = soldPrice
                maxPairedProfitPrice = pairedSecurityBoughtPrice
            End If

            'Dim maxProfit = (((MaxPairedProfitDictionary(symbol).Item1 - currentPrice) / MaxPairedProfitDictionary(symbol).Item1) + ((MaxPairedProfitDictionary(symbol).Item2 - pairedSecurityBoughtPrice) / MaxPairedProfitDictionary(symbol).Item2)) / 2
            'Dim maxProfit = ((MaxPairedProfitDictionary(symbol).Item1 - currentPrice) + (MaxPairedProfitDictionary(symbol).Item2 - pairedSecurityBoughtPrice)) / (MaxPairedProfitDictionary(symbol).Item1 + MaxPairedProfitDictionary(symbol).Item2)
            'Dim maxProfit = Utilities.GetBuyProfitPercent(MaxPairedProfitDictionary(symbol).Item1, currentPrice, quantity, MaxPairedProfitDictionary(symbol).Item2, pairedSecurityCurrentPrice, pairedSecurityTransaction.Quantity)
            Dim maxProfit = Utilities.GetBuyProfitPercent(soldPrice, MaxPairedProfitDictionary(symbol).Item1, quantity, pairedSecurityBoughtPrice, MaxPairedProfitDictionary(symbol).Item2, pairedSecurityTransaction.Quantity)
            If maxProfit < currentProfit Then
                MaxPairedProfitDictionary(symbol) = Tuple.Create(maxProfitPrice, maxPairedProfitPrice)
            Else
                maxProfitPrice = MaxPairedProfitDictionary(symbol).Item1
                maxPairedProfitPrice = MaxPairedProfitDictionary(symbol).Item2
            End If

            'Security Specific Delta. Check if profit is more than threshold, then set the loss threshold to a lower configured value.
            Dim closeProfitValue = AppSettings.SellShortDeltaCloseProfitBelow

            'If (((soldPrice - maxProfitPrice) / soldPrice) + ((maxPairedProfitPrice - pairedSecurityBoughtPrice) / pairedSecurityBoughtPrice)) / 2 >= AppSettings.SecuritySpecificDeltaProfitThreshold Then
            '    closeProfitValue = AppSettings.SecuritySpecificDeltaProfitValue
            'End If

            'If ((soldPrice - maxProfitPrice) + (maxPairedProfitPrice - pairedSecurityBoughtPrice)) / (soldPrice + pairedSecurityBoughtPrice) >= AppSettings.SecuritySpecificDeltaProfitThreshold Then
            '    closeProfitValue = AppSettings.SecuritySpecificDeltaProfitValue
            'End If

            If Utilities.GetBuyProfitPercent(soldPrice, maxProfitPrice, quantity, pairedSecurityBoughtPrice, maxPairedProfitPrice, pairedSecurityTransaction.Quantity) >= AppSettings.SecuritySpecificDeltaProfitThreshold Then
                closeProfitValue = AppSettings.SecuritySpecificDeltaProfitValue
            End If

            ' Dim currentDeltaProfit As Double = (((maxProfitPrice - currentPrice) / maxProfitPrice) + ((pairedSecurityCurrentPrice - maxPairedProfitPrice) / maxPairedProfitPrice)) / 2
            'Dim currentDeltaProfit As Double = ((maxProfitPrice - currentPrice) + (pairedSecurityCurrentPrice - maxPairedProfitPrice)) / (maxProfitPrice + maxPairedProfitPrice)
            Dim currentDeltaProfit As Double = Utilities.GetBuyProfitPercent(maxProfitPrice, currentPrice, quantity, maxPairedProfitPrice, pairedSecurityCurrentPrice, pairedSecurityTransaction.Quantity)
            If currentDeltaProfit < closeProfitValue Then
                AdvancedMockTradingEngine.WriteToFile("Sell Decision. Max Profit Price: " & maxProfitPrice & " Current Price: " & currentPrice & " Max Paired Profit Price: " & maxPairedProfitPrice & " Current Paired Price: " & pairedSecurityCurrentPrice)
                MaxPairedProfitDictionary.Remove(symbol)
                AddToTradeTimeDictionary(symbol)
                RemoveFromMaxLongTermProfit(symbol)
                Return True
            End If
        Else
            'Dim currentProfit As Double = ((soldPrice - currentPrice) / soldPrice + ((pairedSecurityCurrentPrice - pairedSecurityBoughtPrice) / pairedSecurityBoughtPrice)) / 2
            'Dim currentProfit As Double = ((soldPrice - currentPrice) + (pairedSecurityCurrentPrice - pairedSecurityBoughtPrice)) / (soldPrice + pairedSecurityBoughtPrice)
            Dim currentProfit As Double = Utilities.GetBuyProfitPercent(soldPrice, currentPrice, quantity, pairedSecurityBoughtPrice, pairedSecurityCurrentPrice, pairedSecurityTransaction.Quantity)
            AddToMaxLongTermProfit(symbol, currentProfit)
            If currentProfit > AppSettings.SellShortCloseProfitAbove Or currentProfit < AppSettings.SellShortCloseProfitBelow Then
                AdvancedMockTradingEngine.WriteToFile("Buy Decision. Sold Price: " & soldPrice & " Current Price: " & currentPrice)
                If MaxPairedProfitDictionary.ContainsKey(symbol) Then
                    MaxPairedProfitDictionary.Remove(symbol)
                End If
                RemoveFromMaxLongTermProfit(symbol)
                AddToTradeTimeDictionary(symbol)
                Return True
            End If
        End If

        Return False
    End Function

    Private Function ShouldBuyBack(symbol As String, soldPrice As Double, currentPrice As Double)
        'TODO: These conditions need to be verified for correctness.
        If ProfitDeltaModeEnabled Then

            If Not MaxProfitDictionary.ContainsKey(symbol) Then
                MaxProfitDictionary.Add(symbol, soldPrice)
                Return False
            End If

            Dim maxProfitPrice As Double = 0.0

            If currentPrice < soldPrice Then
                maxProfitPrice = currentPrice
            Else
                maxProfitPrice = soldPrice
            End If

            If maxProfitPrice >= MaxProfitDictionary(symbol) Then
                maxProfitPrice = MaxProfitDictionary(symbol)
            Else
                MaxProfitDictionary(symbol) = maxProfitPrice
            End If

            'Security Specific Delta. Check if profit is more than threshold, then set the loss threshold to a lower configured value.
            Dim closeProfitValue = AppSettings.SellShortDeltaCloseProfitBelow

            If (soldPrice - maxProfitPrice) / soldPrice >= AppSettings.SecuritySpecificDeltaProfitThreshold Then
                closeProfitValue = AppSettings.SecuritySpecificDeltaProfitValue
            End If

            If (maxProfitPrice - currentPrice) / maxProfitPrice < closeProfitValue Then
                AdvancedMockTradingEngine.WriteToFile("Sell Decision. Max Profit Price: " & maxProfitPrice & " Current Price: " & currentPrice)
                MaxProfitDictionary.Remove(symbol)
                AddToTradeTimeDictionary(symbol)
                Return True
            End If
        Else
            If (soldPrice - currentPrice) / soldPrice > AppSettings.SellShortCloseProfitAbove Or (soldPrice - currentPrice) / soldPrice < AppSettings.SellShortCloseProfitBelow Then
                AdvancedMockTradingEngine.WriteToFile("Buy Decision. Sold Price: " & soldPrice & " Current Price: " & currentPrice)
                If MaxProfitDictionary.ContainsKey(symbol) Then
                    MaxProfitDictionary.Remove(symbol)
                End If
                AddToTradeTimeDictionary(symbol)
                Return True
            End If
        End If

        Return False
    End Function

    Private Sub AddToTradeTimeDictionary(symbol As String)
        If Not TradeTimeDictionary.ContainsKey(symbol) Then
            TradeTimeDictionary.Add(symbol, DateTime.Now)
        Else
            TradeTimeDictionary(symbol) = DateTime.Now
        End If
    End Sub

    Private Sub AddToStartedWatchingDictionary(symbol As String)
        If Not StartedWatchingDictionary.ContainsKey(symbol) Then
            StartedWatchingDictionary.Add(symbol, DateTime.Now)
        Else
            StartedWatchingDictionary(symbol) = DateTime.Now
        End If
    End Sub

    Private Function IsTimeValidForTradingSymbol(symbol As String) As Boolean
        If Not TradeTimeDictionary.ContainsKey(symbol) Then
            Return True
        Else
            Return ((DateTime.Now - TradeTimeDictionary(symbol)).TotalSeconds <= 60)
        End If
    End Function

    Private Sub BoughtTrade(symbol As String, quantity As Integer, ByVal price As Double, ByVal toSave As Boolean)
        If SellDataBuffer.ContainsKey(symbol) Then
            If SellDataBuffer(symbol).Quantity >= quantity Then
                SellDataBuffer(symbol).Quantity = SellDataBuffer(symbol).Quantity - quantity
            Else
                Throw New Exception("Invalid Buy, you can't buy long and buy at the samme time.")
            End If
            If SellDataBuffer(symbol).Quantity = 0 Then
                AdvancedMockTradingEngine.WriteToFile("Removing symbol from sell data buffer, " & symbol)
                SellDataBuffer.Remove(symbol)
                If BuyPairTradeBuffer.ContainsKey(symbol) Then
                    BuyPairTradeBuffer.Remove(symbol)
                End If
                MarketWatcher.StopWatching(symbol)
            End If

            Return
        End If

        If Not BuyTempList.Contains(symbol) Then
            AdvancedMockTradingEngine.WriteToFile("Invalid Fresh buy without any entry in temp list " & symbol)
            Return
        End If

        BuyTempList.Remove(symbol)

        If BuyDataBuffer.ContainsKey(symbol) Then
            BuyDataBuffer(symbol).Quantity = BuyDataBuffer(symbol).Quantity + quantity
            AdvancedMockTradingEngine.WriteToFile("Invalid Buy, the symbol is already in the buy data buffer.")
        Else
            BuyDataBuffer.Add(symbol, New TradeSnapshot(symbol, quantity, price))
            AdvancedMockTradingEngine.WriteToFile("Symbol added to buy data buffer " & symbol & " at price " & price.ToString())
            AddToStartedWatchingDictionary(symbol)
            MarketWatcher.StartWatching(symbol)
        End If

    End Sub

    Private Sub SoldTrade(symbol As String, quantity As Integer, price As Double, ByVal toSave As Boolean)
        If BuyDataBuffer.ContainsKey(symbol) Then
            If BuyDataBuffer(symbol).Quantity >= quantity Then
                BuyDataBuffer(symbol).Quantity = BuyDataBuffer(symbol).Quantity - quantity
            Else
                Throw New Exception("Invalid Sell, you can't sell short and sell at the samme time.")
            End If
            If BuyDataBuffer(symbol).Quantity = 0 Then
                AdvancedMockTradingEngine.WriteToFile("Removing symbol from buy data buffer, " & symbol)
                BuyDataBuffer.Remove(symbol)
                If SellPairTradeBuffer.ContainsKey(symbol) Then
                    SellPairTradeBuffer.Remove(symbol)
                End If
                MarketWatcher.StopWatching(symbol)
            End If
            Return
        End If

        If Not SellTempList.Contains(symbol) Then
            AdvancedMockTradingEngine.WriteToFile("Invalid Fresh sell without any entry in temp list " & symbol)
            Return
        End If

        SellTempList.Remove(symbol)

        If SellDataBuffer.ContainsKey(symbol) Then
            SellDataBuffer(symbol).Quantity = SellDataBuffer(symbol).Quantity + quantity
            AdvancedMockTradingEngine.WriteToFile("Invalid Sell, the symbol is already in the sell data buffer.")
        Else
            SellDataBuffer.Add(symbol, New TradeSnapshot(symbol, quantity, price))
            AdvancedMockTradingEngine.WriteToFile("Symbol added to sell data buffer " & symbol & " at price " & price.ToString())
            AddToStartedWatchingDictionary(symbol)
            MarketWatcher.StartWatching(symbol)
        End If
    End Sub

    Private Sub LoadPreviousTrades()
        Dim trades = DataLayer.GetOpenTrades()
        If trades Is Nothing Then
            Return
        End If
        For Each trade As Data.Trade In trades
            If trade.TradeType = Enums.TradeType.BuyLong Then
                BuyDataBuffer.Add(trade.Symbol, New TradeSnapshot(trade.Symbol, trade.TradeVolume, trade.TradePrice))
                SellPairTradeBuffer.Add(trade.Symbol, New TradeSnapshot(trade.PairedSecuritySymbol, trade.PairedSecurityQuantity, trade.PairedSecurityPrice))
            Else
                SellDataBuffer.Add(trade.Symbol, New TradeSnapshot(trade.Symbol, trade.TradeVolume, trade.TradePrice))
                BuyPairTradeBuffer.Add(trade.Symbol, New TradeSnapshot(trade.PairedSecuritySymbol, trade.PairedSecurityQuantity, trade.PairedSecurityPrice))
            End If
            AddToStartedWatchingDictionary(trade.Symbol)
            MarketWatcher.StartWatching(trade.Symbol)
        Next
        RebindGrid()
    End Sub

    Private Sub CloseAllTrades()
        Dim openTrades = DataLayer.GetOpenTrades()

        For Each tc In openTrades
            If tc.TradeType = TradeType.BuyLong Then
                RaiseEvent SellWithoutCheck(tc.Symbol, tc.TradeVolume)
            End If
            If tc.TradeType = TradeType.SellShort Then
                RaiseEvent BuyWithoutCheck(tc.Symbol, tc.TradeVolume)
            End If
        Next

        'For Each symbol As String In BuyDataBuffer.Keys
        '    Dim ts = BuyDataBuffer(symbol)
        '    AdvancedMockTradingEngine.WriteToFile("Sell Back Decision for symbol " & symbol & ". Original Buy Price " & ts.Price)
        '    RaiseEvent SellWithoutCheck(symbol, ts.Quantity)
        'Next

        'For Each symbol As String In SellDataBuffer.Keys
        '    Dim ts = SellDataBuffer(symbol)
        '    AdvancedMockTradingEngine.WriteToFile("Buy Back Decision for symbol " & symbol & ". Original Sell Price " & ts.Price)
        '    RaiseEvent BuyWithoutCheck(symbol, ts.Quantity)
        'Next
    End Sub

    Private Sub SetUpTimer()
        _isTradeTime = True
        _timer = New Timer()
        Dim timeSpan As TimeSpan

        If DateTime.Now.TimeOfDay < AppSettings.TradeCloseTime.TimeOfDay Then
            timeSpan = AppSettings.TradeCloseTime.TimeOfDay - DateTime.Now.TimeOfDay
        Else
            timeSpan = DateTime.Now.TimeOfDay - AppSettings.TradeCloseTime.TimeOfDay
            timeSpan = New TimeSpan(24, 0, 0) - timeSpan
        End If

        _timer.Interval = timeSpan.TotalMilliseconds
        AddHandler _timer.Tick, AddressOf Timer_Tick
        _timer.Start()
    End Sub
#End Region

#Region "Event Handlers"
    Private Sub MarketWatcher_TradeOccurred(ByVal symbol As String, ByVal tickPrice As TickPriceData, ByVal tickSize As TickSizeData)
        If Not StartedWatchingDictionary.ContainsKey(symbol) Then
            Throw New Exception("Invalid State for Market Watcher. The watched symbol wasn't present in the Trade Tracking Engine's Dictionary.")
        End If
        If (DateTime.Now - StartedWatchingDictionary(symbol)).TotalSeconds < 10 Then
            Return
        End If
        If SellDataBuffer.ContainsKey(symbol) Then
            Dim ts = SellDataBuffer(symbol)
            Dim shouldBuyBackVar As Boolean = False
            If IntelligentTrader.Instance.PairSecurityEnabled And BuyPairTradeBuffer.ContainsKey(symbol) Then
                shouldBuyBackVar = ShouldBuyBackWithPairTrade(symbol, ts.Price, tickPrice.Price)
            Else
                shouldBuyBackVar = ShouldBuyBack(symbol, ts.Price, tickPrice.Price)
            End If
            If shouldBuyBackVar Then
                AdvancedMockTradingEngine.WriteToFile("Buy Back Decision for symbol " & symbol & " at " & tickPrice.Price & ". Original Sell Price " & ts.Price)
                RaiseEvent BuyWithoutCheck(symbol, ts.Quantity)
            End If
        End If

        If BuyDataBuffer.ContainsKey(symbol) Then
            Dim ts = BuyDataBuffer(symbol)
            Dim shouldSellBackVar As Boolean = False
            If IntelligentTrader.Instance.PairSecurityEnabled And SellPairTradeBuffer.ContainsKey(symbol) Then
                shouldSellBackVar = ShouldSellBackWithPairTrade(symbol, ts.Price, tickPrice.Price)
            Else
                shouldSellBackVar = ShouldSellBack(symbol, ts.Price, tickPrice.Price)
            End If
            If shouldSellBackVar Then
                AdvancedMockTradingEngine.WriteToFile("Sell Back Decision for symbol " & symbol & " at " & tickPrice.Price & ". Original Buy Price " & ts.Price)
                RaiseEvent SellWithoutCheck(symbol, ts.Quantity)
            End If
        End If

        UpdateCurrentPrice(symbol, tickPrice.Price)
    End Sub

    Private Sub btnHide_Click(sender As System.Object, e As System.EventArgs)
        Me.Hide()
    End Sub

    Private Sub btnMaxOpenOrdersApply_Click(sender As System.Object, e As System.EventArgs) Handles btnMaxOpenOrdersApply.Click
        Dim m As Integer
        If Integer.TryParse(txtMaxOpenOrders.Text, m) Then
            MaxOpenOrders = Integer.Parse(txtMaxOpenOrders.Text)
        End If
    End Sub

    Private Sub TradeTrackingEngine_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Timer_Tick(ByVal sender As Object, ByVal e As EventArgs)
        If _isTradeTime Then
            _timer.Stop()
            _isTradeTime = False
            CloseAllTrades()
            _timer.Interval = 60000
            _timer.Start()
        Else
            _timer.Stop()
            _timer.Dispose()

            SetUpTimer()
        End If

    End Sub
#End Region

#Region "Interface Methods"
    Public Sub StartEngine() Implements ITradeTrackingEngine.StartEngine
        SetUpTimer()

        'Initialize Dictionaries
        SellDataBuffer = New Dictionary(Of String, TradeSnapshot)
        BuyDataBuffer = New Dictionary(Of String, TradeSnapshot)
        TradeTimeDictionary = New Dictionary(Of String, DateTime)
        StartedWatchingDictionary = New Dictionary(Of String, DateTime)
        BuyPairTradeBuffer = New Dictionary(Of String, TradeSnapshot)
        SellPairTradeBuffer = New Dictionary(Of String, TradeSnapshot)

        BuyTempList = New List(Of String)
        SellTempList = New List(Of String)

        AxTws1.connect(APIHostAddress, APIPort, ClientId)
        'AxTws2.connect(APIHostAddress, APIHostAddress, ClientId + 13)
        _marketWatcher = New MarketWatcher(AxTws1)
        AddHandler _marketWatcher.TradeOccurred, AddressOf MarketWatcher_TradeOccurred
        Me.Show()
        LoadPreviousTrades()
        Dim m As Integer
        If Integer.TryParse(txtMaxOpenOrders.Text, m) Then
            MaxOpenOrders = Integer.Parse(txtMaxOpenOrders.Text)
        End If
    End Sub

    Public Sub StopEngine() Implements ITradeTrackingEngine.StopEngine
        AxTws1.disconnect()
        _marketWatcher = Nothing
        Me.Hide()
    End Sub

    Public Sub Bought(symbol As String, quantity As Integer, ByVal price As Double) Implements ITradeTrackingEngine.Bought
        BoughtTrade(symbol, quantity, price, True)
        RebindGrid()
    End Sub

    Public Sub Sold(symbol As String, quantity As Integer, price As Double) Implements ITradeTrackingEngine.Sold
        SoldTrade(symbol, quantity, price, True)
        RebindGrid()
    End Sub

    Public Sub BuyPairTradeCompleted(originalTrade As Trade, pairSecurity As PairSecurity, pairSecurityPrice As Double, pairSecurityQuantity As Integer) Implements ITradeTrackingEngine.BuyPairTradeCompleted
        If BuyPairTradeBuffer.ContainsKey(originalTrade.Symbol) Then
            Throw New Exception("Invalid Pair Trade Buffer State. The given key already exists.")
        End If
        Dim ts As New TradeSnapshot(pairSecurity.Symbol, pairSecurityQuantity, pairSecurityPrice)
        BuyPairTradeBuffer.Add(originalTrade.Symbol, ts)
        RebindGrid()
    End Sub

    Public Sub SellPairTradeCompleted(originalTrade As Trade, pairSecurity As PairSecurity, pairSecurityPrice As Double, pairSecurityQuantity As Integer) Implements ITradeTrackingEngine.SellPairTradeCompleted
        If SellPairTradeBuffer.ContainsKey(originalTrade.Symbol) Then
            Throw New Exception("Invalid Pair Trade Buffer State. The given key already exists.")
        End If
        Dim ts As New TradeSnapshot(pairSecurity.Symbol, pairSecurityQuantity, pairSecurityPrice)
        SellPairTradeBuffer.Add(originalTrade.Symbol, ts)
        RebindGrid()
    End Sub

    Public Function ShouldBuy(symbol As String, quantity As Integer) As Boolean Implements ITradeTrackingEngine.ShouldBuy
        'If the time is the period within 10 minutes of the trade closing time then do not allow any trades.
        If _isTradeTime = False Then
            Return False
        End If

        If BuyDataBuffer.ContainsKey(symbol) Or SellDataBuffer.ContainsKey(symbol) Or BuyTempList.Contains(symbol) Or SellTempList.Contains(symbol) Then
            'If BuyDataBuffer(symbol).Quantity = quantity Then
            Return False
            'End If
        End If

        If IsTimeValidForTradingSymbol(symbol) = False Then
            Return False
        End If

        If BuyDataBuffer.Count + SellDataBuffer.Count >= MaxOpenOrders Then
            Return False
        End If

        AdvancedMockTradingEngine.WriteToFile("Fresh Buy Decision " & symbol)
        BuyTempList.Add(symbol)
        Return True
    End Function

    Public Function ShouldSell(symbol As String, quantity As Integer) As Boolean Implements ITradeTrackingEngine.ShouldSell
        'If the time is the period within 10 minutes of the trade closing time then do not allow any trades.
        If _isTradeTime = False Then
            Return False
        End If

        If SellDataBuffer.ContainsKey(symbol) Or BuyDataBuffer.ContainsKey(symbol) Or SellTempList.Contains(symbol) Or BuyTempList.Contains(symbol) Then
            'If SellDataBuffer(symbol).Quantity = quantity Then
            Return False
            'End If
        End If

        If IsTimeValidForTradingSymbol(symbol) = False Then
            Return False
        End If

        If BuyDataBuffer.Count + SellDataBuffer.Count >= MaxOpenOrders Then
            Return False
        End If

        SellTempList.Add(symbol)
        AdvancedMockTradingEngine.WriteToFile("Fresh Sell Decision " & symbol)
        Return True
    End Function

    Public Event SellWithoutCheck(ByVal symbol As String, ByVal quantity As Integer) Implements ITradeTrackingEngine.SellWithoutCheck
    Public Event BuyWithoutCheck(ByVal symbol As String, ByVal quantity As Integer) Implements ITradeTrackingEngine.BuyWithoutCheck


#End Region

End Class

Class TradeSnapshot

    Public Sub New(ByVal s As String, ByVal q As Integer, ByVal p As Double)
        _symbol = s
        _quantity = q
        _price = p
    End Sub

    Private _symbol As String
    Public Property Symbol() As String
        Get
            Return _symbol
        End Get
        Set(ByVal value As String)
            _symbol = value
        End Set
    End Property

    Private _quantity As Integer
    Public Property Quantity() As Integer
        Get
            Return _quantity
        End Get
        Set(ByVal value As Integer)
            _quantity = value
        End Set
    End Property

    Private _price As Double
    Public Property Price() As Double
        Get
            Return _price
        End Get
        Set(ByVal value As Double)
            _price = value
        End Set
    End Property
End Class
