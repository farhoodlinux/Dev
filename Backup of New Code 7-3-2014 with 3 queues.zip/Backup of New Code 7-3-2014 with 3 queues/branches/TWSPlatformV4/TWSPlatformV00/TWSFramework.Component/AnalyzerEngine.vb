﻿Imports System.Collections.Generic
Imports TWSFramework.Analysis
Imports System.IO
Imports TWSFramework.Components


Public Class AnalyzerEngine
    Implements IAnalysisEngine
    Public Sub New()
        _analysisDictionary = New Dictionary(Of String, MarketDataRepository)
        _bidDictionary = New Dictionary(Of String, Double)
        _askDictionary = New Dictionary(Of String, Double)
        _lastDictionary = New Dictionary(Of String, Double)
        _impVolDictionary = New Dictionary(Of String, Double)
    End Sub

    Private Shared _analyzer As IAnalysisEngine
    Public Shared ReadOnly Property Analyzer As IAnalysisEngine
        Get
            If _analyzer Is Nothing Then
                _analyzer = New AnalyzerEngine()
            End If
            Return _analyzer
        End Get
    End Property

    Private _analysisDictionary As Dictionary(Of String, MarketDataRepository)
    Private _bidDictionary As Dictionary(Of String, Double)
    Private _askDictionary As Dictionary(Of String, Double)
    Private _lastDictionary As Dictionary(Of String, Double)
    Private _impVolDictionary As Dictionary(Of String, Double)
    Private ReadOnly Property AnalysisDictionary As Dictionary(Of String, MarketDataRepository)
        Get
            Return _analysisDictionary
        End Get
    End Property

    Public Event AnalysisReady(ByVal symbol As String, ByVal size As Integer, ByVal result As MarketAnalysisResult) Implements IAnalysisEngine.AnalysisReady
    Public Event MultiLevelAnalysisReady(ByVal symbol As String, ByVal result25 As MarketAnalysisResult, ByVal result100 As MarketAnalysisResult) Implements IAnalysisEngine.MultiLevelAnalysisReady

    Public Sub SetBid(ByVal symbol As String, ByVal value As Double) Implements IAnalysisEngine.SetBid
        If Not _bidDictionary.ContainsKey(symbol) Then
            _bidDictionary.Add(symbol, value)
        End If
        _bidDictionary(symbol) = value
    End Sub

    Public Sub SetAsk(ByVal symbol As String, ByVal value As Double) Implements IAnalysisEngine.SetAsk
        If Not _askDictionary.ContainsKey(symbol) Then
            _askDictionary.Add(symbol, value)
        End If
        _askDictionary(symbol) = value
    End Sub

    Public Sub SetLast(ByVal symbol As String, ByVal value As Double) Implements IAnalysisEngine.SetLast
        If Not _lastDictionary.ContainsKey(symbol) Then
            _lastDictionary.Add(symbol, value)
        End If
        _lastDictionary(symbol) = value
    End Sub
    Public Sub SetImpVol(ByVal symbol As String, ByVal value As Double) Implements IAnalysisEngine.SetImpVol
        If Not _impVolDictionary.ContainsKey(symbol) Then
            _impVolDictionary.Add(symbol, value)
        End If
        _impVolDictionary(symbol) = value
    End Sub

    Public Sub TradeOccurred(ByVal symbol As String, ByVal tradeVolume As Integer) Implements IAnalysisEngine.TradeOccurred
        If Not _bidDictionary.ContainsKey(symbol) Or Not _askDictionary.ContainsKey(symbol) Or Not _lastDictionary.ContainsKey(symbol) Then
            Return
        End If
        If Not _impVolDictionary.ContainsKey(symbol) Then
            _impVolDictionary.Add(symbol, 0)
        End If
        If Not AnalysisDictionary.ContainsKey(symbol) Then
            AnalysisDictionary.Add(symbol, New MarketDataRepository())
            AnalysisDictionary(symbol).AddRepository(25)
            AnalysisDictionary(symbol).AddRepository(100)
            'AnalysisDictionary(symbol).AddRepository(500)
        End If
        Dim timeNow = DateTime.Now
        Dim repository = AnalysisDictionary(symbol)
        Dim bid = _bidDictionary(symbol)
        Dim ask = _askDictionary(symbol)
        Dim last = _lastDictionary(symbol)
        Dim impVol = _impVolDictionary(symbol)
        repository.AddSnapshot(bid, ask, last, tradeVolume, impVol, timeNow)

        RaiseEvents(symbol)

        'If symbol.Equals("AONE", StringComparison.OrdinalIgnoreCase) Then
        '    Utilities.WriteToFileAsync(bid.ToString() & ", " & ask.ToString() & ", " & last.ToString() & ", " & tradeVolume.ToString() & ", " & timeNow.ToString("hh:mm:ss:fff"))
        'End If

    End Sub

    Public Sub RaiseEvents(ByVal symbol As String) Implements IAnalysisEngine.RaiseEvents
        If Not AnalysisDictionary.ContainsKey(symbol) Then
            Return
        End If
        Dim repository = AnalysisDictionary(symbol)
        Dim result25 = repository.GetAnalysis(25)
        Dim result100 = repository.GetAnalysis(100)
        'Dim result500 = repository.GetAnalysis(500)

        If repository.Count > 25 Then
            RaiseEvent AnalysisReady(symbol, 25, result25)
        End If

        If repository.Count > 100 Then
            RaiseEvent AnalysisReady(symbol, 100, result100)
            RaiseEvent MultiLevelAnalysisReady(symbol, result25, result100)
        End If

        'If repository.Count > 500 Then
        '    RaiseEvent AnalysisReady(symbol, 500, result500)
        '    RaiseEvent MultiLevelAnalysisReady(symbol, result10, result100, result500)
        'End If

    End Sub

End Class
