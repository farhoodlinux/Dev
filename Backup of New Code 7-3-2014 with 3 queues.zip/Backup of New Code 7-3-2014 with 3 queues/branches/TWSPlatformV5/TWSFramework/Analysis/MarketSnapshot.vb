﻿Namespace Analysis
    Public Class MarketSnapshot
        Public Sub New(ByVal bid As Double, ByVal ask As Double, ByVal last As Double, ByVal volume As Integer, ByVal rsi As Double, ByVal time As DateTime)
            _bid = bid
            _ask = ask
            _last = last
            _instanceTime = time
            _volume = volume
            '_impVolInitial = impVolInitial
            _rsi = rsi
        End Sub

        Private _bid As Double
        Public Property Bid() As Double
            Get
                Return _bid
            End Get
            Set(ByVal value As Double)
                _bid = value
            End Set
        End Property


        Private _ask As Double
        Public Property Ask() As Double
            Get
                Return _ask
            End Get
            Set(ByVal value As Double)
                _ask = value
            End Set
        End Property


        Private _last As Double
        Public Property Last() As Double
            Get
                Return _last
            End Get
            Set(ByVal value As Double)
                _last = value
            End Set
        End Property

        Private _volume As Integer
        Public Property Volume() As Integer
            Get
                Return _volume
            End Get
            Set(ByVal value As Integer)
                _volume = value
            End Set
        End Property

        Private _instanceTime As DateTime
        Public Property InstanceTime() As DateTime
            Get
                Return _instanceTime
            End Get
            Set(ByVal value As DateTime)
                _instanceTime = value
            End Set
        End Property

        'Private _impVolInitial As Double
        'Public Property ImpVolInitial() As Double
        '    Get
        '        Return _impVolInitial
        '    End Get
        '    Set(value As Double)
        '        _impVolInitial = value
        '    End Set
        'End Property

        Private _rsi As Double
        Public Property RSI() As Double
            Get
                Return _rsi
            End Get
            Set(value As Double)
                _rsi = value
            End Set
        End Property
    End Class
End Namespace