﻿Public Class MarketDataItem
    Private _symbol As String
    Public Property Symbol() As String
        Get
            Return _symbol
        End Get
        Set(ByVal value As String)
            _symbol = value
        End Set
    End Property

    Private _bid As Double
    Public Property Bid() As Double
        Get
            Return _bid
        End Get
        Set(ByVal value As Double)
            _bid = value
        End Set
    End Property

    Private _ask As Double
    Public Property Ask() As Double
        Get
            Return _ask
        End Get
        Set(ByVal value As Double)
            _ask = value
        End Set
    End Property

    Private _last As Double
    Public Property Last() As Double
        Get
            Return _last
        End Get
        Set(ByVal value As Double)
            _last = value
        End Set
    End Property

    Private _close As Double
    Public Property Close() As Double
        Get
            Return _close
        End Get
        Set(ByVal value As Double)
            _close = value
        End Set
    End Property

    Private _change As Double
    Public Property Change() As Double
        Get
            Return _change
        End Get
        Set(ByVal value As Double)
            _change = value
        End Set
    End Property

    Private _lastVolume As Integer
    Public Property LastVolume() As Integer
        Get
            Return _lastVolume
        End Get
        Set(ByVal value As Integer)
            _lastVolume = value
        End Set
    End Property

    Private _callInt As Long
    Public Property CallOpenInterest() As Long
        Get
            Return _callInt
        End Get
        Set(ByVal value As Long)
            _callInt = value
        End Set
    End Property

    Private _putInt As Long
    Public Property PutOpenInterest() As Long
        Get
            Return _putInt
        End Get
        Set(ByVal value As Long)
            _putInt = value
        End Set
    End Property

    Private _callVolume As Integer
    Public Property CallVolume() As Integer
        Get
            Return _callVolume
        End Get
        Set(ByVal value As Integer)
            _callVolume = value
        End Set
    End Property

    Private _putVolume As Integer
    Public Property PutVolume() As Integer
        Get
            Return _putVolume
        End Get
        Set(ByVal value As Integer)
            _putVolume = value
        End Set
    End Property

    Private _impVolInitial As Double
    Public Property ImpVolInitial() As Double
        Get
            Return _impVolInitial
        End Get
        Set(ByVal value As Double)
            _impVolInitial = value
        End Set
    End Property

    Private _impVolFinal As Double
    Public Property ImpVolFinal() As Double
        Get
            Return _impVolFinal
        End Get
        Set(ByVal value As Double)
            _impVolFinal = value
        End Set
    End Property

    Private _rsi As Double
    Property RSI() As Double
        Get
            Return _rsi
        End Get
        Set(value As Double)
            _rsi = value
        End Set
    End Property
End Class
