﻿Public Class TestImpVol
    Private _lastReqId As Integer = 1
    Private Sub SetUpMarketData(ByVal symbol As String, ByVal requestId As Integer)
        Dim contract As TWSFramework.Data.Contract
        contract = New TWSFramework.Data.Contract()
        contract.LocalSymbol = symbol
        contract.SecType = TWSFramework.Enums.SecurityType.Stk
        contract.Exchange = "SMART"
        contract.Currency = "USD"
        contract.Symbol = symbol

        'Dim genericTicks = "100,101,104,105,106,107,165,221,225,233,236,258,293,294,295,318"

        Dim twsContract As TWSLib.IContract = AxTws1.createContract()

        contract.RevertToTWSObject(twsContract)
        AxTws1.reqHistoricalDataEx(requestId, twsContract, DateTime.Now.ToString("yyyyMMdd HH:mm:ss") + " GMT", txtDuration.Text, txtBarSize.Text, "OPTION_IMPLIED_VOLATILITY", 0, 1)
    End Sub
    Private Sub btnCalculate_Click(sender As System.Object, e As System.EventArgs) Handles btnCalculate.Click
        SetUpMarketData(txtSymbol.Text, _lastReqId)
        _lastReqId = _lastReqId + 1
    End Sub

    Private Sub btnConnect_Click(sender As System.Object, e As System.EventArgs) Handles btnConnect.Click
        AxTws1.connect("", 7496, 1027)
    End Sub

    Private Sub btnDisconnect_Click(sender As System.Object, e As System.EventArgs) Handles btnDisconnect.Click
        AxTws1.disconnect()
    End Sub

    Private Sub AxTws1_historicalData(sender As System.Object, e As AxTWSLib._DTwsEvents_historicalDataEvent) Handles AxTws1.historicalData
        Dim s As String = String.Format("High: {0}, Low: {1}, WAP: {2}", e.high.ToString(), e.low.ToString(), e.wAP.ToString())
        lstImpVol.Items.Add(s)
    End Sub
End Class