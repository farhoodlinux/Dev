﻿Imports System.Threading
Imports TWSFramework.Components
Imports System.IO
Imports TWSFramework.Data
Imports System.Collections.Generic
Imports DataAccessLayer

Public Class AdvancedMockTradingEngine
    Implements ITradingEngine
    Private Shared m As New Mutex
    Private Shared lastOrderId = 0

    Private _dataLayer As DataLayer
    Private ReadOnly Property DataLayer As DataLayer
        Get
            If _dataLayer Is Nothing Then
                _dataLayer = New DataLayer()
            End If
            Return _dataLayer
        End Get
    End Property
    Private _appSettings As AppSettings
    Public ReadOnly Property AppSettings() As AppSettings
        Get
            If _appSettings Is Nothing Then
                _appSettings = DataLayer.GetAppSettings(False)
            End If
            Return _appSettings
        End Get
    End Property

    Private _marketWatcher As MarketWatcher

    Private ReadOnly Property APIHostAddress As String
        Get
            Return AppSettings.APIHostAddress
        End Get
    End Property

    Private ReadOnly Property APIPort As Integer
        Get
            Return AppSettings.APIPort
        End Get
    End Property
    Private ReadOnly Property ClientId As Integer
        Get
            Return 2004
        End Get
    End Property

    Private _dict As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
    Private _dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
    Private _dictSymbolQuantity As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

    Public Sub StartEngine() Implements ITradingEngine.StartEngine
        _dictSymbolQuantity = New Dictionary(Of String, Integer)
        WriteToFile("Trading Engine Started at " & DateTime.Now.ToString())
        AxTws2.connect(APIHostAddress, APIPort, ClientId)
        _marketWatcher = New MarketWatcher(AxTws2)
        AddHandler _marketWatcher.TradeOccurred, AddressOf MarketWatcher_TradeOccurred
    End Sub

    Private Sub MarketWatcher_TradeOccurred(ByVal symbol As String, ByVal tickPrice As TickPriceData, ByVal tickSize As TickSizeData)
        _marketWatcher.StopWatching(symbol)
        Dim orderid = _dict(symbol)
        _dict.Remove(symbol)
        Dim quantity = _dictSymbolQuantity(symbol)
        _dictSymbolQuantity.Remove(symbol)

        Dim t = "traded"
        If _dict1(symbol) = 0 Then
            t = " bought "
        Else
            t = " sold "
        End If
        _dict1.Remove(symbol)

        WriteToFile(symbol & t & "at " & tickPrice.Price)
        RaiseEvent OrderCompleted(orderid, tickPrice.Price, quantity)
    End Sub

    Public Sub StopEngine() Implements ITradingEngine.StopEngine
        AxTws2.disconnect()
    End Sub
    Private Sub HoldTillTradeCompleted(symbol As String)
        While (_dict.ContainsKey(symbol) Or _dict1.ContainsKey(symbol) Or _dictSymbolQuantity.ContainsKey(symbol))
            Thread.Sleep(500)
        End While
    End Sub
    Public Function Buy(ByVal symbol As String, ByVal quantity As Integer) As Integer Implements ITradingEngine.Buy
        HoldTillTradeCompleted(symbol)
        lastOrderId = lastOrderId + 1
        'WriteToFile(String.Format("Bought {0} shares of {1}", quantity, symbol))
        If Not _dict.ContainsKey(symbol) Then
            _dict.Add(symbol, lastOrderId)
            _dict1.Add(symbol, 0)
            _dictSymbolQuantity.Add(symbol, quantity)
            _marketWatcher.StartWatching(symbol)
        End If

        Return lastOrderId
    End Function

    Public Function Sell(ByVal symbol As String, ByVal quantity As Integer) As Integer Implements ITradingEngine.Sell
        HoldTillTradeCompleted(symbol)
        lastOrderId = lastOrderId + 1
        'WriteToFile(String.Format("Sold {0} shares of {1}", quantity, symbol))
        If Not _dict.ContainsKey(symbol) Then
            _dict.Add(symbol, lastOrderId)
            _dict1.Add(symbol, 1)
            _dictSymbolQuantity.Add(symbol, quantity)
            _marketWatcher.StartWatching(symbol)
        End If
        'RaiseEvent OrderCompleted(lastOrderId, -1, quantity)
        Return lastOrderId
    End Function

    Public Shared Sub WriteToFile(ByVal msg As Object)
        'm.WaitOne()
        'Dim message = msg.ToString()
        'Dim f As New FileStream("C:\tradelog.txt", FileMode.Append)
        'Dim fs As New StreamWriter(f)
        'fs.WriteLine(DateTime.Now)
        'fs.WriteLine(message)
        'fs.Close()
        'm.ReleaseMutex()
    End Sub

    Public Event OrderCompleted(ByVal orderId As Integer, ByVal price As Double, ByVal quantity As Integer) Implements ITradingEngine.OrderCompleted

End Class