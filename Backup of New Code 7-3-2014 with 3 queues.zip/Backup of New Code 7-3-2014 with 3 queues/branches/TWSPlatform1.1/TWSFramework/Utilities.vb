﻿Imports System.IO
Imports System.Threading

Public Class Utilities
    Private Shared m As New Mutex

    Public Shared Function ConvertBoolToInt(ByVal boolToConvert As Boolean) As Integer
        Return CInt(IIf(boolToConvert = True, 1, 0))
    End Function


    Public Shared Function ConvertIntToBool(ByVal intToConvert As Integer) As Boolean
        Return CBool(IIf(intToConvert > 0, True, False))
    End Function

    Private Shared Sub WriteToFile(ByVal msg As Object)
        m.WaitOne()
        Dim message = msg.ToString()
        Dim f As New FileStream("C:\log.txt", FileMode.Append)
        Dim fs As New StreamWriter(f)
        fs.WriteLine(message)
        fs.Close()
        m.ReleaseMutex()
    End Sub

    Public Shared Sub WriteToFileAsync(ByVal message As String)
        'Dim t As New Thread(New ParameterizedThreadStart(AddressOf WriteToFile))
        't.Start(message)
    End Sub

    Public Shared Function GetQuantity(qpFactor As Double, price As Double) As Integer
        Dim quanity As Integer = Fix(Math.Floor(qpFactor / price))
        Return quanity
    End Function
End Class
