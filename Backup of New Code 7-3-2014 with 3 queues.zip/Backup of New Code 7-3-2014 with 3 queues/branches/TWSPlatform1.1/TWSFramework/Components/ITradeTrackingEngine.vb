﻿Imports System.Collections.Generic
Imports TWSFramework.Data

Public Interface ITradeTrackingEngine
    Function ShouldBuy(ByVal symbol As String, ByVal quantity As Integer) As Boolean
    Function ShouldSell(ByVal symbol As String, ByVal quantity As Integer) As Boolean
    Sub Bought(ByVal symbol As String, ByVal quantity As Integer, ByVal price As Double)
    Sub Sold(ByVal symbol As String, ByVal quantity As Integer, ByVal price As Double)
    Sub StartEngine()
    Sub StopEngine()
    Event SellWithoutCheck(ByVal symbol As String, ByVal quantity As Integer)
    Event BuyWithoutCheck(ByVal symbol As String, ByVal quantity As Integer)
End Interface
