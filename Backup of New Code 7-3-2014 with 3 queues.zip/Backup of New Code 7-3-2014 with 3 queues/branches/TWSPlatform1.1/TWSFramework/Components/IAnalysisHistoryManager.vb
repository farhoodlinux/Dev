﻿Namespace Components
    Public Interface IAnalysisHistoryManager

    End Interface
End Namespace
