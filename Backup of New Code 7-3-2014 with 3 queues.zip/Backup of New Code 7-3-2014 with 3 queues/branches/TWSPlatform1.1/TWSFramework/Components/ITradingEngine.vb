﻿Namespace Components
    Public Interface ITradingEngine
        Function Buy(ByVal symbol As String, ByVal quantity As Integer) As Integer
        Function Sell(ByVal symbol As String, ByVal quantity As Integer) As Integer
        Sub StartEngine()
        Sub StopEngine()
        Event OrderCompleted(orderId As Integer, price As Double, quantity As Integer)
    End Interface
End Namespace
