﻿Imports TWSFramework.Enums

Namespace Data

    ''' <summary>
    ''' Houses data returned from the market "Size" event
    ''' </summary>
    ''' <remarks></remarks>
    Public Class TickSizeData

        Private _requestID, _size As Long

        Private _tickType As SizeTickType

#Region " Public Properties "

        ''' <summary>
        ''' The id from the request to the TWS API
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property RequestID() As Long
            Get
                Return _requestID
            End Get
            Set(ByVal value As Long)
                _requestID = value
            End Set
        End Property

        ''' <summary>
        ''' The value returned from the call to the API
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Size() As Long
            Get
                Return _size
            End Get
            Set(ByVal value As Long)
                _size = value
            End Set
        End Property

        ''' <summary>
        ''' Determines the type of the value
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property TickType() As SizeTickType
            Get
                Return _tickType
            End Get
            Set(ByVal value As SizeTickType)
                _tickType = value
            End Set
        End Property

#End Region


        ''' <summary>
        ''' Takes a tick size event data object a loads the class with that
        ''' data
        ''' </summary>
        ''' <param name="data">The object used to load the class</param>
        ''' <remarks></remarks>
        Public Sub LoadDataFromObject(ByVal sizeData As AxTWSLib._DTwsEvents_tickSizeEvent)
            RequestID = sizeData.id
            Size = sizeData.size
            TickType = CType(sizeData.tickType, SizeTickType)
        End Sub



    End Class

    ''' <summary>
    ''' Houses data returned from the market "Price" event
    ''' </summary>
    ''' <remarks></remarks>
    Public Class TickPriceData

        Private _requestID As Long
        Private _price As Double
        Private _canAutoExecute As Boolean

        Private _tickType As PriceTickType

#Region " Class Properties "

        ''' <summary>
        ''' The id of the request to the TWS API
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property RequestID() As Long
            Get
                Return _requestID
            End Get
            Set(ByVal value As Long)
                _requestID = value
            End Set
        End Property

        ''' <summary>
        ''' The price returned from the system
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Price() As Double
            Get
                Return _price
            End Get
            Set(ByVal value As Double)
                _price = value
            End Set
        End Property

        ''' <summary>
        ''' Definition required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CanAutoExecute() As Boolean
            Get
                Return _canAutoExecute
            End Get
            Set(ByVal value As Boolean)
                _canAutoExecute = value
            End Set
        End Property

        ''' <summary>
        ''' Determines what type of price data has been returned
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property TickType() As PriceTickType
            Get
                Return _tickType
            End Get
            Set(ByVal value As PriceTickType)
                _tickType = value
            End Set
        End Property

#End Region

        ''' <summary>
        ''' Takes a tick price event object that houses data from the API and
        ''' loads the class with it
        ''' </summary>
        ''' <param name="data">The data object to load the classes data with</param>
        ''' <remarks></remarks>
        Public Sub LoadDataFromObject(ByVal priceData As AxTWSLib._DTwsEvents_tickPriceEvent)
            RequestID = priceData.id
            Price = priceData.price
            CanAutoExecute = Utilities.ConvertIntToBool(priceData.canAutoExecute)
            TickType = CType(priceData.tickType, PriceTickType)
        End Sub



    End Class

End Namespace
