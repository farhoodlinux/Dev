﻿Imports TWSFramework.Enums
Imports TWSFramework
Imports System.Collections.Generic


Namespace Data
    Public Class Contract





#Region " Member Variables "

        Private _conID As Integer
        Private _strike As Double
        Private _includeExpired As Boolean
        Private _symbol, _expiry, _right, _multiplier, _exchange As String
        Private _currency, _localSymbol, _primaryExch, _comboLegsDescrip As String
        Private _validateErrorMessage As String

        Private _secType As SecurityType
        Private _comboLegs As List(Of ComboLeg)

#End Region

#Region " Class Constructors "

        ''' <summary>
        ''' The default constructor initializes some member variables
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()
            _validateErrorMessage = ""
        End Sub

#End Region

#Region " Class Properties "

        ''' <summary>
        ''' The ID of the current contract
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ConID() As Integer
            Get
                Return _conID
            End Get
            Set(ByVal value As Integer)
                _conID = value
            End Set
        End Property

        ''' <summary>
        ''' The strike price (needs more information)
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Strike() As Double
            Get
                Return _strike
            End Get
            Set(ByVal value As Double)
                _strike = value
            End Set
        End Property

        ''' <summary>
        ''' Allows queries to be performed against expired contracts
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property IncludeExpired() As Boolean
            Get
                Return _includeExpired
            End Get
            Set(ByVal value As Boolean)
                _includeExpired = value
            End Set
        End Property

        ''' <summary>
        ''' The symbol of the underlying asset
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Symbol() As String
            Get
                Return _symbol
            End Get
            Set(ByVal value As String)
                _symbol = value
            End Set
        End Property

        ''' <summary>
        ''' The expiration date
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Expiry() As String
            Get
                Return _expiry
            End Get
            Set(ByVal value As String)
                _expiry = value
            End Set
        End Property

        ''' <summary>
        ''' Specifies whether this is a put or call operation
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks>
        ''' The valid values for this property are "PUT", "P", "CALL", or "C"
        ''' </remarks>
        Public Property Right() As String
            Get
                Return _right
            End Get
            Set(ByVal value As String)
                _right = value
            End Set
        End Property

        ''' <summary>
        ''' Allows the specification of a future or option contract multiplier
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Multiplier() As String
            Get
                Return _multiplier
            End Get
            Set(ByVal value As String)
                _multiplier = value
            End Set
        End Property

        ''' <summary>
        ''' The order destination such as "SMART"
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Exchange() As String
            Get
                Return _exchange
            End Get
            Set(ByVal value As String)
                _exchange = value
            End Set
        End Property

        ''' <summary>
        ''' The currency the transaction should be made in
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks>
        ''' This should be used when a stock can be traded in multiple markets
        ''' </remarks>
        Public Property Currency() As String
            Get
                Return _currency
            End Get
            Set(ByVal value As String)
                _currency = value
            End Set
        End Property

        ''' <summary>
        ''' The actual security ticker symbol
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property LocalSymbol() As String
            Get
                Return _localSymbol
            End Get
            Set(ByVal value As String)
                _localSymbol = value
            End Set
        End Property

        ''' <summary>
        ''' The exchange where the security is traded
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property PrimaryExch() As String
            Get
                Return _primaryExch
            End Get
            Set(ByVal value As String)
                _primaryExch = value
            End Set
        End Property

        ''' <summary>
        ''' Description for combo legs (needs more information)
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ComboLegsDescrip() As String
            Get
                Return _comboLegsDescrip
            End Get
            Set(ByVal value As String)
                _comboLegsDescrip = value
            End Set
        End Property

        ''' <summary>
        ''' The type of security this contract represents
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property SecType() As SecurityType
            Get
                Return _secType
            End Get
            Set(ByVal value As SecurityType)
                _secType = value
            End Set
        End Property

        ''' <summary>
        ''' Can hold multiple combo legs for this contract
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks>
        ''' This property masks a TWS API IComboLegList object; it uses the
        ''' .Net generic list object
        ''' </remarks>
        Public Property ComboLegs() As List(Of ComboLeg)
            Get
                If _comboLegs Is Nothing Then
                    _comboLegs = New List(Of ComboLeg)()
                End If

                Return _comboLegs
            End Get
            Set(ByVal value As List(Of ComboLeg))
                _comboLegs = value
            End Set
        End Property

#End Region

        Public Sub LoadDataFromObject(ByVal data As TWSLib.IContract)

            Dim contractData As TWSLib.IContract = data

            With contractData
                Symbol = .symbol
                SecType = ConvertSecurityStringToType(.secType)
                Expiry = .expiry
                Strike = .strike
                Right = .right
                Multiplier = .multiplier
                Exchange = .exchange
                Currency = .currency
                LocalSymbol = .localSymbol
                PrimaryExch = .primaryExchange
                IncludeExpired = Utilities.ConvertIntToBool(.includeExpired)
                ComboLegsDescrip = .comboLegsDescrip
                If Not .comboLegs Is Nothing Then
                    ComboLegs = ConvertTWSComboLegsToFrameworkList(.comboLegs)
                End If
                ConID = .conId
            End With
        End Sub

        Public Sub RevertToTWSObject(ByRef contract As TWSLib.IContract)
            With contract
                .symbol = Symbol
                .secType = ConvertSecurityTypeToString(SecType)
                .expiry = Expiry
                .strike = Strike
                .multiplier = Multiplier
                .exchange = Exchange
                .currency = Currency
                .localSymbol = LocalSymbol
                .primaryExchange = PrimaryExch
                .includeExpired = Utilities.ConvertBoolToInt(IncludeExpired)
                .conId = ConID
            End With
        End Sub

#Region " Helper Methods "

        ''' <summary>
        ''' Converts the security type string to the framework type
        ''' </summary>
        ''' <param name="securityType">The string to convert into a SecurityType</param>
        ''' <returns>A SecurityType enumeration that houses the different security types</returns>
        ''' <remarks></remarks>
        Private Function ConvertSecurityStringToType(ByVal securityType As String) As SecurityType
            Select Case securityType.ToLower()
                Case "stk"
                    Return Enums.SecurityType.Stk
                Case "opt"
                    Return Enums.SecurityType.Opt
                Case "fut"
                    Return Enums.SecurityType.Fut
                Case "ind"
                    Return Enums.SecurityType.Ind
                Case "fop"
                    Return Enums.SecurityType.Fop
                Case "cash"
                    Return Enums.SecurityType.Cash
                Case "bag"
                    Return Enums.SecurityType.Bag
                Case Else
                    Throw New Exception("Error in ConvertSecurityStringToType: The security type passed to the method is not valid")
            End Select
        End Function


        Private Function ConvertSecurityTypeToString(ByVal securityType As SecurityType) As String
            Select Case securityType
                Case Enums.SecurityType.Stk
                    Return "STK"
                Case Enums.SecurityType.Opt
                    Return "OPT"
                Case Enums.SecurityType.Fut
                    Return "FUT"
                Case Enums.SecurityType.Ind
                    Return "IND"
                Case Enums.SecurityType.Fop
                    Return "FOP"
                Case Enums.SecurityType.Cash
                    Return "CASH"
                Case Enums.SecurityType.Bag
                    Return "BAG"
                Case Else
                    Throw New Exception("Error in ConvertSecurityTypeToString: The security type passed to the method is not valid")
            End Select
        End Function

        ''' <summary>
        ''' Converts an IComboLegList object to a .Net generic list
        ''' </summary>
        ''' <param name="comboLegs">The IComboLegList to convert</param>
        ''' <returns>A .Net generic list that contains ComboLeg classes</returns>
        ''' <remarks></remarks>
        Private Function ConvertTWSComboLegsToFrameworkList(ByVal comboLegs As TWSLib.IComboLegList) As List(Of ComboLeg)
            Dim frameworkList As New List(Of ComboLeg)()

            For Each comboLeg As TWSLib.IComboLeg In comboLegs
                Dim frameworkComboLeg As New ComboLeg()
                frameworkComboLeg.LoadDataFromObject(comboLeg)
                frameworkList.Add(frameworkComboLeg)
            Next

            Return frameworkList
        End Function

#End Region

    End Class

End Namespace

