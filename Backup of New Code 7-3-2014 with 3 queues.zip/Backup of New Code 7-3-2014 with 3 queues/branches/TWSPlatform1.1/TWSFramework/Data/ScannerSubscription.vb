Imports TWSFramework.Enums
Imports System.Collections.Generic
Namespace Data


    Public Class ScannerSubscription

#Region " Class Constructors "

        ''' <summary>
        ''' The default constructor just initializes member variables
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()
            InitializeVariables()
            _validateErrorMessage = ""
        End Sub

        ''' <summary>
        ''' This constructor sets the variables needed to submit a scanner
        ''' request to the API
        ''' </summary>
        ''' <param name="numberOfRows">The number of items to return from the scan</param>
        ''' <param name="instrument">The type of security to search for</param>
        ''' <param name="location">The location to search</param>
        ''' <param name="stockTypeFilter">The type of security to search (stock, etf, or all)</param>
        ''' <param name="scanCode">The scan to perform</param>
        ''' <remarks></remarks>
        Public Sub New(ByVal numberOfRows As Integer, ByVal instrument As InstrumentType, ByVal location As LocationType, ByVal stockTypeFilter As StockTypeFilter, ByVal scanCode As ScanCodeType)
            InitializeVariables()
            _numberOfRows = numberOfRows
            _instrument = instrument
            _location = location
            _stockTypeFilter = stockTypeFilter
            _scanCode = scanCode
            _validateErrorMessage = ""
        End Sub


        ''' <summary>
        ''' This constructor sets the variables needed to submit a scanner
        ''' request to the API
        ''' </summary>
        ''' <param name="numberOfRows">The number of items to return from the scan</param>
        ''' <param name="instrument">The type of security to search for</param>
        ''' <param name="location">The location to search</param>
        ''' <param name="stockTypeFilter">The type of security to search (stock, etf, or all)</param>
        ''' <param name="scanCode">The scan to perform</param>
        ''' <param name="priceAbove">priceAbove</param>
        ''' <param name="priceBelow">priceBelow</param>
        ''' <remarks></remarks>
        Public Sub New(ByVal numberOfRows As Integer, ByVal instrument As InstrumentType, ByVal location As LocationType, ByVal stockTypeFilter As StockTypeFilter, ByVal scanCode As ScanCodeType, ByVal priceAbove As Integer, ByVal priceBelow As Integer)
            InitializeVariables()
            _numberOfRows = numberOfRows
            _instrument = instrument
            _location = location
            _stockTypeFilter = stockTypeFilter
            _scanCode = scanCode
            _validateErrorMessage = ""
            _priceAbove = priceAbove
            _priceBelow = priceBelow

        End Sub

        ''' <summary>
        ''' Sets the default values to the objects member variables
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub InitializeVariables()
            _requestID = 0
            _numberOfRows = 0
            _volumeAbove = 0
            _averageOptionVolumeAbove = 0
            _priceAbove = 0
            _priceBelow = 0
            _marketCapAbove = 0
            _marketCapBelow = 0
        End Sub

#End Region



        



#Region " Member Variables "
        Private _scannerName As String
        Private _requestID As Integer
        Private _numberOfRows, _volumeAbove, _averageOptionVolumeAbove As Integer
        Private _priceAbove, _priceBelow, _marketCapAbove, _marketCapBelow As Double
        Private _couponRateAbove, _couponRateBelow As Double
        Private _moodyRatingAbove, _moodyRatingBelow, _spRatingAbove, _spRatingBelow As String
        Private _maturityDateAbove, _maturityDateBelow As String
        Private _validateErrorMessage As String
        Private _excludeConvertable As Boolean ' Should be converted to int

        Private _scannerSettingPairs As List(Of String)

        Private _instrument As InstrumentType
        Private _location As LocationType
        Private _scanCode As ScanCodeType
        Private _stockTypeFilter As StockTypeFilter
        Private _enabled As Boolean

        Private _locationTypes As List(Of LocationType)
#End Region

#Region " Class Properties "

        ''' <summary>
        ''' Gets or sets a value indicating whether this <see cref="ScannerSubscription" /> is enabled.
        ''' </summary>
        ''' <value>
        '''   <c>true</c> if enabled; otherwise, <c>false</c>.
        ''' </value>
        Public Property Enabled() As Boolean
            Get
                Return _enabled
            End Get
            Set(ByVal value As Boolean)
                _enabled = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the name of the scanner.
        ''' </summary>
        ''' <value>
        ''' The name of the scanner.
        ''' </value>
        Public Property ScannerName() As String
            Get
                Return _scannerName
            End Get
            Set(ByVal value As String)
                _scannerName = value
            End Set
        End Property
        ''' <summary>
        ''' ID of the scanner rgisterared in TWS client
        ''' </summary>
        ''' <value>Sets the ID for scanner subscription</value>
        ''' <returns>ID of the scanner subscription</returns>
        ''' <remarks></remarks>
        Public Property RequestID() As Integer
            Get
                Return _requestID
            End Get
            Set(ByVal value As Integer)
                _requestID = value
            End Set
        End Property

        ''' <summary>
        ''' The number of rows to return from the scan
        ''' </summary>
        ''' <value>Sets the number of rows to scan for</value>
        ''' <returns>An integer that represents the number of rows to scan for</returns>
        ''' <remarks></remarks>
        Public Property NumberOfRows() As Integer
            Get
                Return _numberOfRows
            End Get
            Set(ByVal value As Integer)
                _numberOfRows = value
            End Set
        End Property

        ''' <summary>
        ''' The type of security to search for
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Instrument() As InstrumentType
            Get
                Return _instrument
            End Get
            Set(ByVal value As InstrumentType)
                _instrument = value
            End Set
        End Property

        ''' <summary>
        ''' The market location to perform the scan
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Location() As LocationType
            Get
                Return _location
            End Get
            Set(ByVal value As LocationType)
                _location = value
            End Set
        End Property

        ''' <summary>
        ''' The type of scan to perform
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ScanCode() As ScanCodeType
            Get
                Return _scanCode
            End Get
            Set(ByVal value As ScanCodeType)
                _scanCode = value
            End Set
        End Property

        ''' <summary>
        ''' The scan will return securities where the price is above this price
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property PriceAbove() As Double
            Get
                Return _priceAbove
            End Get
            Set(ByVal value As Double)
                _priceAbove = value
            End Set
        End Property

        ''' <summary>
        ''' The scan will return securities where the price is below this price
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property PriceBelow() As Double
            Get
                Return _priceBelow
            End Get
            Set(ByVal value As Double)
                _priceBelow = value
            End Set
        End Property

        ''' <summary>
        ''' The scan will return securities where the volume is above this
        ''' volume
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property VolumeAbove() As Integer
            Get
                Return _volumeAbove
            End Get
            Set(ByVal value As Integer)
                _volumeAbove = value
            End Set
        End Property

        ''' <summary>
        ''' The scan will return securities that have a market capitalization
        ''' above this amount
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property MarketCapAbove() As Double
            Get
                Return _marketCapAbove
            End Get
            Set(ByVal value As Double)
                _marketCapAbove = value
            End Set
        End Property

        ''' <summary>
        ''' The scan will return securities that have a market capitalization
        ''' below this amount
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property MarketCapBelow() As Double
            Get
                Return _marketCapBelow
            End Get
            Set(ByVal value As Double)
                _marketCapBelow = value
            End Set
        End Property

        ''' <summary>
        ''' The scan will return securities that have a moody rating above
        ''' this value
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property MoodyRatingAbove() As String
            Get
                Return _moodyRatingAbove
            End Get
            Set(ByVal value As String)
                _moodyRatingAbove = value
            End Set
        End Property

        ''' <summary>
        ''' The scan will return securities that have a moody rating below
        ''' this value
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property MoodyRatingBelow() As String
            Get
                Return _moodyRatingBelow
            End Get
            Set(ByVal value As String)
                _moodyRatingBelow = value
            End Set
        End Property

        ''' <summary>
        ''' This scan will return securities that have a standard and poors
        ''' rating above this value
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property SPRatingAbove() As String
            Get
                Return _spRatingAbove
            End Get
            Set(ByVal value As String)
                _spRatingAbove = value
            End Set
        End Property

        ''' <summary>
        ''' This scan will return securities that have a standard and poors
        ''' rating above this value
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property SPRatingBelow() As String
            Get
                Return _spRatingBelow
            End Get
            Set(ByVal value As String)
                _spRatingBelow = value
            End Set
        End Property

        ''' <summary>
        ''' This scan will return bonds that have a maturity date above this
        ''' value
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property MaturityDateAbove() As String
            Get
                Return _maturityDateAbove
            End Get
            Set(ByVal value As String)
                _maturityDateAbove = value
            End Set
        End Property

        ''' <summary>
        ''' This scan will return bonds that have a maturity date below this
        ''' value
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property MaturityDateBelow() As String
            Get
                Return _maturityDateBelow
            End Get
            Set(ByVal value As String)
                _maturityDateBelow = value
            End Set
        End Property

        ''' <summary>
        ''' This scan will return bonds that have a coupon rate above this
        ''' value
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CouponRateAbove() As Double
            Get
                Return _couponRateAbove
            End Get
            Set(ByVal value As Double)
                _couponRateAbove = value
            End Set
        End Property

        ''' <summary>
        ''' This scan will return bonds that have a coupon rate below this
        ''' value
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CouponRateBelow() As Double
            Get
                Return _couponRateBelow
            End Get
            Set(ByVal value As Double)
                _couponRateBelow = value
            End Set
        End Property

        ''' <summary>
        ''' Determines if this scan should exclude convertable bonds
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ExcludeConvertable() As Boolean
            Get
                Return _excludeConvertable
            End Get
            Set(ByVal value As Boolean)
                _excludeConvertable = value
            End Set
        End Property

        ''' <summary>
        ''' Allows scanner setting pairs to be added to a generic list of pairs
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ScannerSettingPairs() As List(Of String)
            Get
                If _scannerSettingPairs Is Nothing Then
                    _scannerSettingPairs = New List(Of String)()
                End If

                Return _scannerSettingPairs
            End Get
            Set(ByVal value As List(Of String))
                _scannerSettingPairs = value
            End Set
        End Property

        ''' <summary>
        ''' This scan will return securities that have an average option
        ''' volume above this value
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property AverageOptionVolumeAbove() As Integer
            Get
                Return _averageOptionVolumeAbove
            End Get
            Set(ByVal value As Integer)
                _averageOptionVolumeAbove = value
            End Set
        End Property

        ''' <summary>
        ''' Determines which security types will be searched for
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property StockTypeFilter() As StockTypeFilter
            Get
                Return _stockTypeFilter
            End Get
            Set(ByVal value As StockTypeFilter)
                _stockTypeFilter = value
            End Set
        End Property

        Public Property LocationTypes() As List(Of LocationType)
            Get
                Return _locationTypes
            End Get
            Set(ByVal value As List(Of LocationType))
                _locationTypes = value
            End Set
        End Property

        Public ReadOnly Property LocationTypesString() As String
            Get
                If _locationTypes Is Nothing Then
                    Return String.Empty
                End If
                Dim returnString = String.Empty
                For Each loct In _locationTypes
                    returnString = returnString & loct.ToString() & ","
                Next
                returnString = returnString.Trim(",".ToCharArray())
                Return returnString
            End Get
        End Property
#End Region

        Public Sub RevertToTWSObject(ByRef scanner As TWSLib.IScannerSubscription)


            scanner.numberOfRows = NumberOfRows
            scanner.instrument = ConvertInstrumentTypeToString(Instrument)


            If LocationTypes Is Nothing Then
                scanner.locations = ConvertLocationTypeToString(Location)
            Else
                scanner.locations = String.Empty
                For Each loction In LocationTypes
                    scanner.locations = scanner.locations & ConvertLocationTypeToString(loction) & ","
                Next
                scanner.locations = scanner.locations.Trim(",".ToCharArray())
            End If

            scanner.scanCode = ConvertScanCodeTypeToString(ScanCode)
            If PriceAbove > 0 Then
                scanner.priceAbove = PriceAbove
            End If
            If PriceBelow > 0 Then
                scanner.priceBelow = PriceBelow
            End If
            If VolumeAbove > 0 Then
                scanner.volumeAbove = VolumeAbove
            End If
            If MarketCapAbove > 0 Then
                scanner.marketCapAbove = MarketCapAbove
            End If
            If MarketCapBelow > 0 Then
                scanner.marketCapBelow = MarketCapBelow
            End If
            If Not MoodyRatingAbove = "" Then
                scanner.moodyRatingAbove = MoodyRatingAbove
            End If
            If Not MoodyRatingBelow = "" Then
                scanner.moodyRatingBelow = MoodyRatingBelow
            End If
            If Not SPRatingAbove = "" Then
                scanner.spRatingAbove = SPRatingAbove
            End If
            If Not SPRatingBelow = "" Then
                scanner.spRatingBelow = SPRatingBelow
            End If
            If Not MaturityDateAbove = "" Then
                scanner.maturityDateAbove = MaturityDateAbove
            End If
            If Not MaturityDateBelow = "" Then
                scanner.maturityDateBelow = MaturityDateBelow
            End If
            If Not CouponRateAbove >= Double.Parse("0.0") Then
                scanner.couponRateAbove = CouponRateAbove
            End If
            If Not CouponRateBelow >= Double.Parse("0.0") Then
                scanner.couponRateBelow = CouponRateBelow
            End If
            scanner.excludeConvertible = Utilities.ConvertBoolToInt(ExcludeConvertable)
            If ScannerSettingPairs.Count > 0 Then
                scanner.scannerSettingPairs = ConvertScannerSettingPairsToString(ScannerSettingPairs)
            End If
            If AverageOptionVolumeAbove > 0 Then
                scanner.averageOptionVolumeAbove = AverageOptionVolumeAbove
            End If
            scanner.stockTypeFilter = ConvertStockTypeFilterTypeToString(StockTypeFilter)
        End Sub


#Region " Helper Methods "

        ''' <summary>
        ''' Converts the instrument string into the framework instrument enumeration
        ''' </summary>
        ''' <param name="instrument">The string representing the instrument</param>
        ''' <returns>An InstrumentType enumeration that contains the different instrument types</returns>
        ''' <remarks></remarks>
        Private Function ConvertInstrumentStringToType(ByVal instrument As String) As InstrumentType
            Select Case instrument.ToLower()
                Case "stk"
                    Return InstrumentType.Stk
                Case "fut.us"
                    Return InstrumentType.Fut_Us
                Case "ind.us"
                    Return InstrumentType.Ind_Us
                Case "efp"
                    Return InstrumentType.Efp
                Case "stock.na"
                    Return InstrumentType.Stock_Na
                Case "fut.na"
                    Return InstrumentType.Fut_Na
                Case "stock.eu"
                    Return InstrumentType.Stock_Eu
                Case "fut.eu"
                    Return InstrumentType.Fut_Eu
                Case "ind.eu"
                    Return InstrumentType.Ind_Eu
                Case "stock.hk"
                    Return InstrumentType.Stock_Hk
                Case "fut.hk"
                    Return InstrumentType.Fut_Hk
                Case "ind.hk"
                    Return InstrumentType.Ind_Hk
                Case Else
                    Throw New Exception("Error in ConvertInstrumentStringToType: The instrument passed to the method was invalid")
            End Select
        End Function

        ''' <summary>
        ''' Converts the instrument type back into the string that the TWS API
        ''' expects
        ''' </summary>
        ''' <param name="instrument">The <see cref="TWSFramework.Enums.InstrumentType">InstrumentType</see> to convert back to a string</param>
        ''' <returns>A string that the TWS API framework expects</returns>
        ''' <remarks></remarks>
        Private Function ConvertInstrumentTypeToString(ByVal instrument As InstrumentType) As String
            Select Case instrument
                Case InstrumentType.Stk
                    Return "STK"
                Case InstrumentType.Fut_Us
                    Return "FUT.US"
                Case InstrumentType.Ind_Us
                    Return "IND.US"
                Case InstrumentType.Efp
                    Return "EFP"
                Case InstrumentType.Stock_Na
                    Return "STOCK.NA"
                Case InstrumentType.Fut_Na
                    Return "FUT.NA"
                Case InstrumentType.Stock_Eu
                    Return "STOCK.EU"
                Case InstrumentType.Fut_Eu
                    Return "FUT.EU"
                Case InstrumentType.Ind_Eu
                    Return "IND.EU"
                Case InstrumentType.Stock_Hk
                    Return "STOCK.HK"
                Case InstrumentType.Fut_Hk
                    Return "FUT.HK"
                Case InstrumentType.Ind_Hk
                    Return "IND.HK"
                Case Else
                    Throw New Exception("Error in ConvertInstrumentTypeToString: The string passed to the method was invalid")
            End Select
        End Function

        ''' <summary>
        ''' Converts the location string into the framework location enumeration
        ''' </summary>
        ''' <param name="location">The string representing the location</param>
        ''' <returns>A LocationType enumeration that contains the different location types</returns>
        ''' <remarks></remarks>
        Private Function ConvertLocationStringToType(ByVal location As String) As LocationType
            Select Case location.ToLower()
                Case "stk.us"
                    Return LocationType.Stk_Us
                Case "stk.nyse"
                    Return LocationType.Stk_Nyse
                Case "stk.amex"
                    Return LocationType.Stk_Amex
                Case "stk.nasdaq"
                    Return LocationType.Stk_Nasdaq
                Case "stk.nasdaq.nms"
                    Return LocationType.Stk_Nasdaq_Nms
                Case "stk.nasdaq.scm"
                    Return LocationType.Stk_Nasdaq_Scm
                Case "stk.otcbb"
                    Return LocationType.Stk_Otcbb
                Case "fut.us"
                    Return LocationType.Fut_Us
                Case "fut.globex"
                    Return LocationType.Fut_Globex
                Case "fut.ecbot"
                    Return LocationType.Fut_Ecbot
                Case "fut.eurexus"
                    Return LocationType.Fut_Eurexus
                Case "fut.nymex"
                    Return LocationType.Fut_Nymex
                Case "ind.us"
                    Return LocationType.Ind_Us
                Case "efp"
                    Return LocationType.Efp
                Case "stk.na"
                    Return LocationType.Stk_Na
                Case "fut.na"
                    Return LocationType.Fut_Na
                Case "stk.eu"
                    Return LocationType.Stk_Eu
                Case "stk.eu.ibis"
                    Return LocationType.Stk_Eu_Ibis
                Case "fut.eu"
                    Return LocationType.Fut_Eu
                Case "ind.eu"
                    Return LocationType.Ind_Eu
                Case "stk.hk"
                    Return LocationType.Stk_Hk
                Case "fut.hk"
                    Return LocationType.Fut_Hk
                Case "ind.hk"
                    Return LocationType.Ind_Hk
                Case Else
                    Throw New Exception("Error in ConvertLocationStringToType: The location passed to the method was invalid")
            End Select
        End Function

        ''' <summary>
        ''' Converts the location into a string so it can be used by the
        ''' framework
        ''' </summary>
        ''' <param name="location">The <see cref="TWSFramework.Enums.LocationType">LocationType</see> enumeration to convert into a string</param>
        ''' <returns>The string representation of the <see cref="TWSFramework.Enums.LocationType">LocationType</see> enumeration</returns>
        ''' <remarks></remarks>
        Private Function ConvertLocationTypeToString(ByVal location As LocationType) As String
            Select Case location
                Case LocationType.Stk_Us
                    Return "STK.US"
                Case LocationType.Stk_Nyse
                    Return "STK.NYSE"
                Case LocationType.Stk_Amex
                    Return "STK.AMEX"
                Case LocationType.Stk_Nasdaq
                    Return "STK.NASDAQ"
                Case LocationType.Stk_Nasdaq_Nms
                    Return "STK.NASDAQ.NMS"
                Case LocationType.Stk_Nasdaq_Scm
                    Return "STK.NASDAQ.SCM"
                Case LocationType.Stk_Otcbb
                    Return "STK.OTCBB"
                Case LocationType.Fut_Us
                    Return "FUT.US"
                Case LocationType.Fut_Globex
                    Return "FUT.GLOBEX"
                Case LocationType.Fut_Ecbot
                    Return "FUT.ECBOT"
                Case LocationType.Fut_Eurexus
                    Return "FUT.EUREXUS"
                Case LocationType.Fut_Nymex
                    Return "FUT.NYMEX"
                Case LocationType.Ind_Us
                    Return "IND.US"
                Case LocationType.Efp
                    Return "EFP"
                Case LocationType.Stk_Na
                    Return "STK.NA"
                Case LocationType.Fut_Na
                    Return "FUT.NA"
                Case LocationType.Stk_Eu
                    Return "STK.EU"
                Case LocationType.Stk_Eu_Ibis
                    Return "STK.EU.IBIS"
                Case LocationType.Fut_Eu
                    Return "FUT.EU"
                Case LocationType.Ind_Eu
                    Return "IND.EU"
                Case LocationType.Stk_Hk
                    Return "STK.HK"
                Case LocationType.Fut_Hk
                    Return "FUT.HK"
                Case LocationType.Ind_Hk
                    Return "IND.HK"
                Case Else
                    Throw New Exception("Error In ConvertLocationTypeToString: The location type passed to the method was invalid")
            End Select
        End Function

        ''' <summary>
        ''' Converts the scan code string into the framework enumeration
        ''' </summary>
        ''' <param name="scanCode">The string representing the scan to perform</param>
        ''' <returns>A ScanCodeType enumeration that contains the different scan codes</returns>
        ''' <remarks></remarks>
        Private Function ConvertScanCodeStringToType(ByVal scanCode As String) As ScanCodeType
            Select Case scanCode.ToLower()
                Case "top_perc_gain"
                    Return ScanCodeType.Top_Perc_Gain
                Case "top_perc_lose"
                    Return ScanCodeType.Top_Perc_Lose
                Case "most_active"
                    Return ScanCodeType.Most_Active
                Case "not_open"
                    Return ScanCodeType.Not_Open
                Case "halted"
                    Return ScanCodeType.Halted
                Case "hot_by_price"
                    Return ScanCodeType.Hot_By_Price
                Case "hot_by_volume"
                    Return ScanCodeType.Hot_By_Volume
                Case "top_trade_count"
                    Return ScanCodeType.Top_Trade_Count
                Case "top_trade_rate"
                    Return ScanCodeType.Top_Trade_Rate
                Case "top_price_range"
                    Return ScanCodeType.Top_Price_Range
                Case "hot_by_price_range"
                    Return ScanCodeType.Hot_By_Price_Range
                Case "top_volume_rate"
                    Return ScanCodeType.Top_Volume_Rate
                Case "top_open_perc_gain"
                    Return ScanCodeType.Top_Open_Perc_Gain
                Case "top_open_perc_lose"
                    Return ScanCodeType.Top_Open_Perc_Lose
                Case "high_open_gap"
                    Return ScanCodeType.High_Open_Gap
                Case "low_open_gap"
                    Return ScanCodeType.Low_Open_Gap
                Case "high_opt_imp_volat"
                    Return ScanCodeType.High_Opt_Imp_Volat
                Case "low_opt_imp_volat"
                    Return ScanCodeType.Low_Opt_Imp_Volat
                Case "top_opt_imp_volat_gain"
                    Return ScanCodeType.Top_Opt_Imp_Volat_Gain
                Case "low_opt_imp_volat_lose"
                    Return ScanCodeType.Low_Opt_Imp_Volat_Lose
                Case "high_opt_imp_volat_over_hist"
                    Return ScanCodeType.High_Opt_Imp_Volat_Over_Hist
                Case "low_opt_imp_volat_over_hist"
                    Return ScanCodeType.Low_Opt_Imp_Volat_Over_Hist
                Case "opt_volume_most_active"
                    Return ScanCodeType.Opt_Volume_Most_Active
                Case "opt_open_interest_most_active"
                    Return ScanCodeType.Opt_Open_Interest_Most_Active
                Case "high_opt_volume_put_call_ratio"
                    Return ScanCodeType.High_Opt_Volume_Put_Call_Ratio
                Case "low_opt_volume_put_call_ratio"
                    Return ScanCodeType.Low_Opt_Volume_Put_Call_Ratio
                Case "high_opt_open_interest_put_call_ratio"
                    Return ScanCodeType.High_Opt_Open_Interest_Put_Call_Ratio
                Case "low_opt_open_interest_put_call_ratio"
                    Return ScanCodeType.Low_Opt_Open_Interest_Put_Call_Ratio
                Case "hot_by_opt_volume"
                    Return ScanCodeType.Hot_By_Volume
                Case "high_synth_bid_rev_nat_yield"
                    Return ScanCodeType.High_Synth_Bid_Rev_Nat_Yield
                Case "low_synth_ask_rev_nat_yield"
                    Return ScanCodeType.Low_Synth_Ask_Rev_Nat_Yield
                Case "high_vs_13w_hl"
                    Return ScanCodeType.High_Vs_13W_Hl
                Case "low_vs_13w_hl"
                    Return ScanCodeType.Low_Vs_13W_Hl
                Case "high_vs_26w_hl"
                    Return ScanCodeType.High_Vs_26W_Hl
                Case "low_vs_26w_hl"
                    Return ScanCodeType.Low_Vs_26W_Hl
                Case "high_vs_52w_hl"
                    Return ScanCodeType.High_Vs_52W_Hl
                Case "low_vs_52w_hl"
                    Return ScanCodeType.Low_Vs_52W_Hl
                Case Else
                    Throw New Exception("Error in ConvertScanCodeStringToType: The scan code passed to the method was invalid")
            End Select
        End Function

        ''' <summary>
        ''' Converts the <see cref="TWSFramework.Enums.ScanCodeType">ScanCodeType</see>
        ''' into a string so it can be used by the framework
        ''' </summary>
        ''' <param name="scanCode">The <see cref="TWSFramework.Enums.ScanCodeType">ScanCodeType</see> enumeration to convert</param>
        ''' <returns>A string representation of the <see cref="TWSFramework.Enums.ScanCodeType">ScanCodeType</see> enumeration</returns>
        ''' <remarks></remarks>
        Private Function ConvertScanCodeTypeToString(ByVal scanCode As ScanCodeType) As String
            Select Case scanCode
                Case ScanCodeType.Top_Perc_Gain
                    Return "TOP_PERC_GAIN"
                Case ScanCodeType.Top_Perc_Lose
                    Return "TOP_PERC_LOSE"
                Case ScanCodeType.Most_Active
                    Return "MOST_ACTIVE"
                Case ScanCodeType.Not_Open
                    Return "NOT_OPEN"
                Case ScanCodeType.Halted
                    Return "HALTED"
                Case ScanCodeType.Hot_By_Price
                    Return "HOT_BY_PRICE"
                Case ScanCodeType.Hot_By_Volume
                    Return "HOT_BY_VOLUME"
                Case ScanCodeType.Top_Trade_Count
                    Return "TOP_TRADE_COUNT"
                Case ScanCodeType.Top_Trade_Rate
                    Return "TOP_TRADE_RATE"
                Case ScanCodeType.Top_Price_Range
                    Return "TOP_PRICE_RANGE"
                Case ScanCodeType.Hot_By_Price_Range
                    Return "HOT_BY_PRICE_RANGE"
                Case ScanCodeType.Top_Volume_Rate
                    Return "TOP_VOLUME_RATE"
                Case ScanCodeType.Top_Open_Perc_Gain
                    Return "TOP_OPEN_PERC_GAIN"
                Case ScanCodeType.Top_Open_Perc_Lose
                    Return "TOP_OPEN_PERC_LOSE"
                Case ScanCodeType.High_Open_Gap
                    Return "HIGH_OPEN_GAP"
                Case ScanCodeType.Low_Open_Gap
                    Return "LOW_OPEN_GAP"
                Case ScanCodeType.High_Opt_Imp_Volat
                    Return "HIGH_OPT_IMP_VOLAT"
                Case ScanCodeType.Low_Opt_Imp_Volat
                    Return "LOW_OPT_IMP_VOLAT"
                Case ScanCodeType.Top_Opt_Imp_Volat_Gain
                    Return "TOP_OPT_IMP_VOLAT_GAIN"
                Case ScanCodeType.Low_Opt_Imp_Volat_Lose
                    Return "LOW_OPT_IMP_VOLAT_LOSE"
                Case ScanCodeType.High_Opt_Imp_Volat_Over_Hist
                    Return "HIGH_OPT_IMP_VOLAT_OVER_HIST"
                Case ScanCodeType.Low_Opt_Imp_Volat_Over_Hist
                    Return "LOW_OPT_IMP_VOLAT_OVER_HIST"
                Case ScanCodeType.Opt_Volume_Most_Active
                    Return "OPT_VOLUME_MOST_ACTIVE"
                Case ScanCodeType.Opt_Open_Interest_Most_Active
                    Return "OPT_OPEN_INTEREST_MOST_ACTIVE"
                Case ScanCodeType.High_Opt_Volume_Put_Call_Ratio
                    Return "HIGH_OPT_VOLUME_PUT_CALL_RATIO"
                Case ScanCodeType.Low_Opt_Volume_Put_Call_Ratio
                    Return "LOW_OPT_VOLUME_PUT_CALL_RATIO"
                Case ScanCodeType.High_Opt_Open_Interest_Put_Call_Ratio
                    Return "HIGH_OPT_OPEN_INTEREST_PUT_CALL_RATIO"
                Case ScanCodeType.Low_Opt_Open_Interest_Put_Call_Ratio
                    Return "LOW_OPT_OPEN_INTEREST_PUT_CALL_RATIO"
                Case ScanCodeType.Hot_By_Volume
                    Return "HOT_BY_VOLUME"
                Case ScanCodeType.High_Synth_Bid_Rev_Nat_Yield
                    Return "HIGH_SYNTH_BID_REV_NAT_YIELD"
                Case ScanCodeType.Low_Synth_Ask_Rev_Nat_Yield
                    Return "LOW_SYNTH_ASK_REV_NAT_YIELD"
                Case ScanCodeType.High_Vs_13W_Hl
                    Return "HIGH_VS_13W_HL"
                Case ScanCodeType.Low_Vs_13W_Hl
                    Return "LOW_VS_13W_HL"
                Case ScanCodeType.High_Vs_26W_Hl
                    Return "HIGH_VS_26W_HL"
                Case ScanCodeType.Low_Vs_26W_Hl
                    Return "LOW_VS_26W_HL"
                Case ScanCodeType.High_Vs_52W_Hl
                    Return "HIGH_VS_52W_HL"
                Case ScanCodeType.Low_Vs_52W_Hl
                    Return "LOW_VS_52W_HL"
                Case ScanCodeType.Hot_By_Opt_Volume
                    Return "HOT_BY_OPT_VOLUME"
                Case Else
                    Throw New Exception("Error in ConvertScanCodeTypeToString: The scan code type passed to the method was invalid")
            End Select
        End Function

        ''' <summary>
        ''' Converts the stock type filter string into the framework
        ''' enumeration
        ''' </summary>
        ''' <param name="stockTypeFilter">The stock type filter string to convert</param>
        ''' <returns>A <see cref="TWSFramework.Enums.StockTypeFilter">StockTypeFilter</see> enumeration that contains the different stock types</returns>
        ''' <remarks></remarks>
        Private Function ConvertStockTypeFilterStringToType(ByVal stockTypeFilter As String) As StockTypeFilter
            Select Case stockTypeFilter.ToLower()
                Case "all"
                    Return Enums.StockTypeFilter.All
                Case "stock"
                    Return Enums.StockTypeFilter.Stock
                Case "etf"
                    Return Enums.StockTypeFilter.Etf
                Case Else
                    Throw New Exception("Error in ConvertStockTypeFilterStringToType: The stockTypeFilter passed to the method was invalid")
            End Select
        End Function

        ''' <summary>
        ''' Converts the <see cref="TWSFramework.Enums.StockTypeFilter">StockTypeFilter</see>
        ''' into a string so it can be used by the TWS API
        ''' </summary>
        ''' <param name="stockType">The <see cref="TWSFramework.Enums.StockTypeFilter">StockTypeFilter</see> to convert</param>
        ''' <returns>A string representation of the <see cref="TWSFramework.Enums.StockTypeFilter">StockTypeFilter</see> enumeration</returns>
        ''' <remarks></remarks>
        Private Function ConvertStockTypeFilterTypeToString(ByVal stockType As StockTypeFilter) As String
            Select Case stockType
                Case Enums.StockTypeFilter.All
                    Return "ALL"
                Case Enums.StockTypeFilter.Stock
                    Return "STOCK"
                Case Enums.StockTypeFilter.Etf
                    Return "ETF"
                Case Else
                    Throw New Exception("Error in ConvertStockTypeFilterTypeToString: The stockTypeFilter type passed to the method was invalid")
            End Select
        End Function

        ''' <summary>
        ''' Converts the scanner settings generic list to a comma delimited
        ''' string
        ''' </summary>
        ''' <param name="scannerSettings">The scanner setting generic list to convert to a comma delimited string</param>
        ''' <returns>A comma delimited string that represents scanner settings</returns>
        ''' <remarks></remarks>
        Private Function ConvertScannerSettingPairsToString(ByVal scannerSettings As List(Of String)) As String
            Dim scannerString As String = ""

            For Each setting As String In scannerSettings
                scannerString &= CStr(IIf(scannerString.Length > 0, "," & setting, setting))
            Next

            Return scannerString
        End Function

#End Region

    End Class
End Namespace