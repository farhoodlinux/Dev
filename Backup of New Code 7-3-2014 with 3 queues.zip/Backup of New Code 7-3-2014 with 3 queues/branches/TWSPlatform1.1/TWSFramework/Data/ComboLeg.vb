﻿Imports TWSFramework.Enums

Namespace Data
    Public Class ComboLeg


#Region " Member Variables "

        Private _conID, _ratio As Integer
        Private _exchange, _designatedLocation As String
        Private _validateErrorMessage As String

        Private _action As ComboLegActionType
        Private _openClose As OpenCloseType
        Private _shortSaleSlot As ShortSaleSlotType

#End Region

#Region " Class Constructors "

        ''' <summary>
        ''' The default constructor initializes some member variables
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()
            _validateErrorMessage = ""
        End Sub

#End Region

#Region " Class Properties "

        ''' <summary>
        ''' The contract id of this combo leg
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ConID() As Integer
            Get
                Return _conID
            End Get
            Set(ByVal value As Integer)
                _conID = value
            End Set
        End Property

        ''' <summary>
        ''' Determines whether this is a buy or sell operation
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Action() As ComboLegActionType
            Get
                Return _action
            End Get
            Set(ByVal value As ComboLegActionType)
                _action = value
            End Set
        End Property

        ''' <summary>
        ''' (Needs explaination)
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Ratio() As Integer
            Get
                Return _ratio
            End Get
            Set(ByVal value As Integer)
                _ratio = value
            End Set
        End Property

        ''' <summary>
        ''' The exchange the order will be routed to (ex. SMART)
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Exchange() As String
            Get
                Return _exchange
            End Get
            Set(ByVal value As String)
                _exchange = value
            End Set
        End Property

        ''' <summary>
        ''' Specifies whether an order is an open or close order
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property OpenClose() As OpenCloseType
            Get
                Return _openClose
            End Get
            Set(ByVal value As OpenCloseType)
                _openClose = value
            End Set
        End Property

        ''' <summary>
        ''' Indicates who is making the sale (institutional customers only)
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ShortSaleSlot() As ShortSaleSlotType
            Get
                Return _shortSaleSlot
            End Get
            Set(ByVal value As ShortSaleSlotType)
                _shortSaleSlot = value
            End Set
        End Property

        ''' <summary>
        ''' If ShortSaleSlot is ThirdParty then this property is required
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property DesignatedLocation() As String
            Get
                Return _designatedLocation
            End Get
            Set(ByVal value As String)
                _designatedLocation = value
            End Set
        End Property

#End Region

        Public Sub LoadDataFromObject(ByVal data As TWSLib.IComboLeg)

            Dim comboData As TWSLib.IComboLeg = data
            ConID = comboData.conId

            If comboData.action.ToLower() = "buy" Then
                Action = ComboLegActionType.Buy
            ElseIf comboData.action.ToLower() = "sell" Then
                Action = ComboLegActionType.Sell
            Else
                Action = ComboLegActionType.Buy
            End If

            Ratio = comboData.ratio
            Exchange = comboData.exchange

            If comboData.openClose = 0 Then
                OpenClose = OpenCloseType.SameAsParent
            ElseIf comboData.openClose = 1 Then
                OpenClose = OpenCloseType.Open
            ElseIf comboData.openClose = 2 Then
                OpenClose = OpenCloseType.Close
            ElseIf comboData.openClose = 3 Then
                OpenClose = OpenCloseType.Unknown
            Else
                OpenClose = OpenCloseType.Unknown
            End If

            If comboData.shortSaleSlot = 0 Then
                ShortSaleSlot = ShortSaleSlotType.NotApplicable
            ElseIf comboData.shortSaleSlot = 1 Then
                ShortSaleSlot = ShortSaleSlotType.ClearingBroker
            ElseIf comboData.shortSaleSlot = 2 Then
                ShortSaleSlot = ShortSaleSlotType.ThirdParty
            Else
                ShortSaleSlot = ShortSaleSlotType.NotApplicable
            End If

            DesignatedLocation = comboData.designatedLocation
        End Sub



    End Class

End Namespace
