﻿Imports System.Runtime.CompilerServices

Public Module TimeSpanExtensions

    <Extension()>
    Public Function Multiply(ByVal ts As TimeSpan, ByVal factor As Double) As TimeSpan

        Dim milliseconds = ts.TotalMilliseconds

        milliseconds = (milliseconds * factor)

        ts = TimeSpan.FromMilliseconds(milliseconds)

        Return ts

    End Function

End Module
