﻿Imports TWSFramework
Imports TWSFramework.Data
Namespace Events


    Public Class ErrorEventArgs
        Inherits EventArgs

        Private _data As ErrorData

        Public Property data() As ErrorData
            Get

                Return _data
            End Get

            Set(ByVal value As ErrorData)
                _data = value
            End Set
        End Property
    End Class


End Namespace