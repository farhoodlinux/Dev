﻿
Namespace Events


    Public Delegate Sub ErrorDataReturn(ByVal sender As Object, ByVal e As ErrorEventArgs)


End Namespace


