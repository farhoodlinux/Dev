﻿Namespace Analysis
    Public Class MarketAnalysisResult

        Private _belowBid As Double
        Public Property BelowBid() As Double
            Get
                Return _belowBid
            End Get
            Set(ByVal value As Double)
                _belowBid = value
            End Set
        End Property


        Private _atBid As Double
        Public Property AtBid() As Double
            Get
                Return _atBid
            End Get
            Set(ByVal value As Double)
                _atBid = value
            End Set
        End Property


        Private _bidToAsk As Double
        Public Property BidToAsk() As Double
            Get
                Return _bidToAsk
            End Get
            Set(ByVal value As Double)
                _bidToAsk = value
            End Set
        End Property


        Private _atAsk As Double
        Public Property AtAsk() As Double
            Get
                Return _atAsk
            End Get
            Set(ByVal value As Double)
                _atAsk = value
            End Set
        End Property


        Private _aboveAsk As Double
        Public Property AboveAsk() As Double
            Get
                Return _aboveAsk
            End Get
            Set(ByVal value As Double)
                _aboveAsk = value
            End Set
        End Property

        Private _averageTimeGap As TimeSpan
        Public Property AverageTimeGap() As TimeSpan
            Get
                Return _averageTimeGap
            End Get
            Set(ByVal value As TimeSpan)
                _averageTimeGap = value
            End Set
        End Property


        Private _instanceTime As DateTime
        Public Property InstanceTime() As DateTime
            Get
                Return _instanceTime
            End Get
            Set(ByVal value As DateTime)
                _instanceTime = value
            End Set
        End Property

        Private _averageVolume As Double
        Public Property AverageVolume() As Double
            Get
                Return _averageVolume
            End Get
            Set(ByVal value As Double)
                _averageVolume = value
            End Set
        End Property

        Private _averagePrice As Double
        Public Property AveragePrice() As Double
            Get
                Return _averagePrice
            End Get
            Set(ByVal value As Double)
                _averagePrice = value
            End Set
        End Property

    End Class
End Namespace