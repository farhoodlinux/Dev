﻿Imports System.Collections.Generic
Imports System.Collections
Imports System.Linq

Namespace Analysis
    Public Class MarketDataRepositoryItem
        Public Sub New(ByVal s As Integer)
            _size = s
            _snapshots = New Concurrent.ConcurrentQueue(Of MarketSnapshot)
        End Sub

        Private _size As Integer
        Public ReadOnly Property Size() As Integer
            Get
                Return _size
            End Get
        End Property

        Private _snapshots As Concurrent.ConcurrentQueue(Of MarketSnapshot)
        Public Property Snapshots() As Concurrent.ConcurrentQueue(Of MarketSnapshot)
            Get
                Return _snapshots
            End Get
            Set(ByVal value As Concurrent.ConcurrentQueue(Of MarketSnapshot))
                _snapshots = value
            End Set
        End Property

        Public Sub Add(ByVal snapshot As MarketSnapshot)
            If _snapshots.Count = Size Then
                Dim x As MarketSnapshot
                _snapshots.TryDequeue(x)
            End If
            _snapshots.Enqueue(snapshot)
        End Sub

        Public Function GetAnalysis() As MarketAnalysisResult
            Dim lst = _snapshots.ToArray().ToList()
            Dim result = New MarketAnalysisResult()
            Dim prevTimeStamp = DateTime.MinValue
            Dim millisecs As Double
            For Each item As MarketSnapshot In lst
                If item.Last < item.Bid Then
                    result.BelowBid = result.BelowBid + 1
                End If

                If item.Last = item.Bid Then
                    result.AtBid = result.AtBid + 1
                End If

                If item.Last > item.Bid And item.Last < item.Ask Then
                    result.BidToAsk = result.BidToAsk + 1
                End If

                If item.Last = item.Ask Then
                    result.AtAsk = result.AtAsk + 1
                End If

                If item.Last > item.Ask Then
                    result.AboveAsk = result.AboveAsk + 1
                End If

                If prevTimeStamp > DateTime.MinValue Then
                    millisecs = millisecs + item.InstanceTime.TimeOfDay.Subtract(prevTimeStamp.TimeOfDay).TotalMilliseconds
                End If
                prevTimeStamp = item.InstanceTime

                result.AverageVolume = result.AverageVolume + item.Volume

                result.AveragePrice = result.AveragePrice + item.Last
            Next
            Dim mSecs As Double = millisecs / CType(lst.Count, Double)
            result.AverageTimeGap = TimeSpan.FromMilliseconds(mSecs)
            result.BelowBid = (result.BelowBid * 100) / lst.Count
            result.AtBid = (result.AtBid * 100) / lst.Count
            result.BidToAsk = (result.BidToAsk * 100) / lst.Count
            result.AtAsk = (result.AtAsk * 100) / lst.Count
            result.AboveAsk = (result.AboveAsk * 100) / lst.Count
            result.AverageVolume = result.AverageVolume / lst.Count
            result.AveragePrice = result.AveragePrice / lst.Count
            result.InstanceTime = DateTime.Now
            Return result
        End Function

    End Class
End Namespace