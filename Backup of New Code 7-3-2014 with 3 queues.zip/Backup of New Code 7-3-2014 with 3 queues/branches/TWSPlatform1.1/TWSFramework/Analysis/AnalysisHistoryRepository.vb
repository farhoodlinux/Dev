﻿Imports System.Collections
Namespace Analysis
    Public Class AnalysisHistoryRepository
        Public Sub New(ByVal s As Integer)
            _size = s
            _snapshots = New Concurrent.ConcurrentQueue(Of MarketAnalysisResult)
        End Sub

        Private _size As Integer
        Public ReadOnly Property Size() As Integer
            Get
                Return _size
            End Get
        End Property

        Private _snapshots As Concurrent.ConcurrentQueue(Of MarketAnalysisResult)
        Public Property Snapshots() As Concurrent.ConcurrentQueue(Of MarketAnalysisResult)
            Get
                Return _snapshots
            End Get
            Set(ByVal value As Concurrent.ConcurrentQueue(Of MarketAnalysisResult))
                _snapshots = value
            End Set
        End Property

        Public Sub Add(ByVal snapshot As MarketAnalysisResult)
            If _snapshots.Count = Size Then
                Dim x As MarketAnalysisResult
                _snapshots.TryDequeue(x)
            End If
            _snapshots.Enqueue(snapshot)
        End Sub
    End Class
End Namespace