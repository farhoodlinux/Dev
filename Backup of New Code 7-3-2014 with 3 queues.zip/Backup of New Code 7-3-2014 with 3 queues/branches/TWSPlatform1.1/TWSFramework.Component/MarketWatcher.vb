﻿Imports AxTWSLib
Imports System.Collections.Generic
Imports TWSFramework.Data
Imports TWSFramework.Components

Public Class MarketWatcher
#Region "Objects"
    Private _axTws1 As AxTws
    Public Property AxTws1() As AxTws
        Get
            Return _axTws1
        End Get
        Set(ByVal value As AxTws)
            _axTws1 = value
        End Set
    End Property
    Private _marketDataBuffer As Dictionary(Of Integer, TWSLib.IContract)
    Private Property MarketDataBuffer() As Dictionary(Of Integer, TWSLib.IContract)
        Get
            Return _marketDataBuffer
        End Get
        Set(ByVal value As Dictionary(Of Integer, TWSLib.IContract))
            _marketDataBuffer = value
        End Set
    End Property

    Private _priceDataBuffer As Dictionary(Of String, TickPriceData)
    Private Property PriceDataBuffer() As Dictionary(Of String, TickPriceData)
        Get
            Return _priceDataBuffer
        End Get
        Set(ByVal value As Dictionary(Of String, TickPriceData))
            _priceDataBuffer = value
        End Set
    End Property
#End Region

#Region "Public Functions"
    Public Sub New(ByVal axtwsObj As AxTws)
        _axTws1 = axtwsObj
        MarketDataBuffer = New Dictionary(Of Integer, TWSLib.IContract)
        PriceDataBuffer = New Dictionary(Of String, TickPriceData)

        AddHandler _axTws1.tickPrice, AddressOf axTws1_tickPrice
        AddHandler _axTws1.tickSize, AddressOf axTws1_tickSize

    End Sub

    Public Sub StartWatching(ByVal symbol As String)
        Dim requestId = symbol.GetHashCode()
        If MarketDataBuffer.ContainsKey(requestId) Then
            Return
        End If

        SetUpMarketData(symbol, requestId)
    End Sub
    Public Sub StopWatching(ByVal symbol As String)
        Dim requestId = symbol.GetHashCode()
        If Not MarketDataBuffer.ContainsKey(requestId) Then
            Return
        End If

        MarketDataBuffer.Remove(requestId)
    End Sub
#End Region

#Region "Private Functions"

    Private Sub SetUpMarketData(ByVal symbol As String, ByVal requestId As Integer)
        Dim contract As TWSFramework.Data.Contract
        contract = New TWSFramework.Data.Contract()
        contract.LocalSymbol = symbol
        contract.SecType = TWSFramework.Enums.SecurityType.Stk
        contract.Exchange = "SMART"
        contract.Currency = "USD"

        Dim genericTicks = "100,101,104,106,165,221,225,236"

        Dim twsContract As TWSLib.IContract = AxTws1.createContract()

        contract.RevertToTWSObject(twsContract)

        MarketDataBuffer.Add(requestId, twsContract)

        AxTws1.reqMktDataEx(requestId, twsContract, genericTicks, False)

    End Sub

    Private Sub HandleCommonMarketDataPrice(ByVal e As AxTWSLib._DTwsEvents_tickPriceEvent)
        If Not MarketDataBuffer.ContainsKey(e.id) Then
            AxTws1.cancelMktData(e.id)
            Return
        End If
        Dim tickPriceDataItem As TickPriceData = New TickPriceData()

        tickPriceDataItem.LoadDataFromObject(e)

        If Not tickPriceDataItem.TickType = Enums.PriceTickType.Last Then
            Return
        End If

        Dim contract = MarketDataBuffer(tickPriceDataItem.RequestID)

        If Not PriceDataBuffer.ContainsKey(contract.localSymbol) Then
            PriceDataBuffer.Add(contract.localSymbol, tickPriceDataItem)
        End If
        PriceDataBuffer(contract.localSymbol) = tickPriceDataItem
    End Sub

    Private Sub HandleCommonMarketDataSize(ByVal e As AxTWSLib._DTwsEvents_tickSizeEvent)

        If Not MarketDataBuffer.ContainsKey(e.id) Then
            AxTws1.cancelMktData(e.id)
            Return
        End If
        Dim tickSizeDataItem As TickSizeData = New TickSizeData()
        tickSizeDataItem.LoadDataFromObject(e)
        If Not tickSizeDataItem.TickType = Enums.SizeTickType.LastSize Then
            Return
        End If
        Dim contract = MarketDataBuffer(tickSizeDataItem.RequestID)

        If Not PriceDataBuffer.ContainsKey(contract.localSymbol) Then
            Throw New Exception("Invalid Price Data Buffer")
        End If

        RaiseEvent TradeOccurred(contract.localSymbol, PriceDataBuffer(contract.localSymbol), tickSizeDataItem)
    End Sub
#End Region

#Region "Event Handlers"
    Private Sub axTws1_tickPrice(sender As System.Object, e As AxTWSLib._DTwsEvents_tickPriceEvent)
        'If e.id > 100 Then
        HandleCommonMarketDataPrice(e)
        Return
        'End If
    End Sub

    Private Sub axTws1_tickSize(sender As System.Object, e As AxTWSLib._DTwsEvents_tickSizeEvent)
        'If e.id > 100 Then
        HandleCommonMarketDataSize(e)
        Return
        'End If
    End Sub
#End Region

#Region "Events"
    Public Event TradeOccurred(ByVal symbol As String, ByVal tickPrice As TickPriceData, ByVal tickSize As TickSizeData)
#End Region
End Class
