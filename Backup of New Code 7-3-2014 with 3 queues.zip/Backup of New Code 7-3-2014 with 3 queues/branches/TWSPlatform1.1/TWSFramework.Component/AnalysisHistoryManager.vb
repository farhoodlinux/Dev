﻿Imports System.Collections.Generic
Imports System.Collections
Imports TWSFramework.Analysis
Imports TWSFramework.Components

    Public Class AnalysisHistoryManager
        Private _size As Integer
        Public Sub New()
            _size = 10000
            _analysisDictionary = New Dictionary(Of String, AnalysisHistoryRepository)
        End Sub

        Private _analysisDictionary As Dictionary(Of String, AnalysisHistoryRepository)
        Private ReadOnly Property AnalysisDictionary As Dictionary(Of String, AnalysisHistoryRepository)
            Get
                Return _analysisDictionary
            End Get
        End Property

        Public Sub Add(ByVal symbol As String, ByVal marketAnalysisItem As MarketAnalysisResult)
            If Not AnalysisDictionary.ContainsKey(symbol) Then
                AnalysisDictionary.Add(symbol, New AnalysisHistoryRepository(_size))
            End If
            AnalysisDictionary(symbol).Add(marketAnalysisItem)
        End Sub

        Public Function GetHistory(ByVal symbol As String) As List(Of MarketAnalysisResult)
            If Not AnalysisDictionary.ContainsKey(symbol) Then
                Return Nothing
            End If
            Dim returnList As New List(Of MarketAnalysisResult)

            Dim arr = AnalysisDictionary(symbol).Snapshots.ToArray()
            For Each value In arr
                returnList.Add(value)
            Next
            Return returnList
        End Function
    End Class
