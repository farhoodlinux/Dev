﻿Imports System.IO
Imports System.Threading
Imports TWSFramework.Components

Public Class MockTradingEngine
    Implements ITradingEngine
    Private Shared m As New Mutex
    Private Shared lastOrderId = 0

    Private _marketWatcher As MarketWatcher

    Public Sub StartEngine() Implements ITradingEngine.StartEngine
    End Sub

    Public Sub StopEngine() Implements ITradingEngine.StopEngine

    End Sub

    Public Function Buy(ByVal symbol As String, ByVal quantity As Integer) As Integer Implements ITradingEngine.Buy
        lastOrderId = lastOrderId + 1
        WriteToFile(String.Format("Bought {0} shares of {1}", quantity, symbol))
        RaiseEvent OrderCompleted(lastOrderId, -1, quantity)
        Return -1
    End Function

    Public Function Sell(ByVal symbol As String, ByVal quantity As Integer) As Integer Implements ITradingEngine.Sell
        lastOrderId = lastOrderId + 1
        WriteToFile(String.Format("Sold {0} shares of {1}", quantity, symbol))
        RaiseEvent OrderCompleted(lastOrderId, -1, quantity)
        Return -1
    End Function

    Private Shared Sub WriteToFile(ByVal msg As Object)
        m.WaitOne()
        Dim message = msg.ToString()
        Dim f As New FileStream("C:\tradelog.txt", FileMode.Append)
        Dim fs As New StreamWriter(f)
        fs.WriteLine(message)
        fs.Close()
        m.ReleaseMutex()
    End Sub

    Public Event OrderCompleted(orderId As Integer, price As Double, quantity As Integer) Implements ITradingEngine.OrderCompleted

End Class
