﻿Imports System.Collections.Generic
Imports System.Windows.Forms
Imports TWSFramework.Data
Imports DataAccessLayer

Public Class TradeTrackingEngine
    Implements ITradeTrackingEngine

#Region "Properties"
    Private _timer As Timer
    Private _isTradeTime As Boolean
    Private _appSettings As AppSettings
    Public ReadOnly Property AppSettings() As AppSettings
        Get
            If _appSettings Is Nothing Then
                _appSettings = DataLayer.GetAppSettings(False)
            End If
            Return _appSettings
        End Get
    End Property

    Private ReadOnly Property APIHostAddress As String
        Get
            Return AppSettings.APIHostAddress
        End Get
    End Property

    Private ReadOnly Property APIPort As Integer
        Get
            Return AppSettings.APIPort
        End Get
    End Property

    Private ReadOnly Property ClientId As Integer
        Get
            Return 2000
        End Get
    End Property

    Private _maxOpenOrders As Integer
    Public Property MaxOpenOrders() As Integer
        Get
            Return _maxOpenOrders
        End Get
        Set(ByVal value As Integer)
            _maxOpenOrders = value
        End Set
    End Property

    Private ReadOnly Property ProfitDeltaModeEnabled() As Boolean
        Get
            Return chkProfitDelta.Checked
        End Get
    End Property

#End Region

#Region "Components"
    Private Shared _instance As ITradeTrackingEngine
    Public Shared ReadOnly Property Instance As ITradeTrackingEngine
        Get
            If _instance Is Nothing Then
                _instance = New TradeTrackingEngine()
            End If
            Return _instance
        End Get
    End Property

    Private _dataLayer As DataLayer
    Private ReadOnly Property DataLayer As DataLayer
        Get
            If _dataLayer Is Nothing Then
                _dataLayer = New DataLayer()
            End If
            Return _dataLayer
        End Get
    End Property

    Private _marketWatcher As MarketWatcher
    Public ReadOnly Property MarketWatcher() As MarketWatcher
        Get
            Return _marketWatcher
        End Get
    End Property
#End Region

#Region "Buffers"
    Private _sellDataBuffer As Dictionary(Of String, TradeSnapshot)
    Private Property SellDataBuffer() As Dictionary(Of String, TradeSnapshot)
        Get
            Return _sellDataBuffer
        End Get
        Set(ByVal value As Dictionary(Of String, TradeSnapshot))
            _sellDataBuffer = value
        End Set
    End Property

    Private _buyDataBuffer As Dictionary(Of String, TradeSnapshot)
    Private Property BuyDataBuffer() As Dictionary(Of String, TradeSnapshot)
        Get
            Return _buyDataBuffer
        End Get
        Set(ByVal value As Dictionary(Of String, TradeSnapshot))
            _buyDataBuffer = value
        End Set
    End Property

    Private _buyTempList As List(Of String)
    Public Property BuyTempList() As List(Of String)
        Get
            Return _buyTempList
        End Get
        Set(ByVal value As List(Of String))
            _buyTempList = value
        End Set
    End Property

    Private _sellTempList As List(Of String)
    Public Property SellTempList() As List(Of String)
        Get
            Return _sellTempList
        End Get
        Set(ByVal value As List(Of String))
            _sellTempList = value
        End Set
    End Property

    Private _maxProfitDictionary As Dictionary(Of String, Double)
    Public Property MaxProfitDictionary() As Dictionary(Of String, Double)
        Get
            If _maxProfitDictionary Is Nothing Then
                _maxProfitDictionary = New Dictionary(Of String, Double)
            End If
            Return _maxProfitDictionary
        End Get
        Set(ByVal value As Dictionary(Of String, Double))
            _maxProfitDictionary = value
        End Set
    End Property

#End Region

#Region "Methods"
    Public Sub New()
        InitializeComponent()
    End Sub



    Private Sub RebindGrid()
        dgvTrades.Rows.Clear()
        For Each item As TradeSnapshot In BuyDataBuffer.Values
            dgvTrades.Rows.Add(item.Symbol, item.Price, "BUY")
        Next

        For Each item As TradeSnapshot In SellDataBuffer.Values
            dgvTrades.Rows.Add(item.Symbol, item.Price, "SELL")
        Next
    End Sub

    Private Sub UpdateCurrentPrice(symbol As String, price As Double)
        For Each row As DataGridViewRow In dgvTrades.Rows
            If row.Cells("Symbol").Value.Equals(symbol) Then
                row.Cells("CurrentPrice").Value = price
                If BuyDataBuffer.ContainsKey(symbol) Then
                    Dim profit = price - BuyDataBuffer(symbol).Price
                    row.Cells("ProfitPercent").Value = (profit * 100) / BuyDataBuffer(symbol).Price
                    Return
                End If
                If SellDataBuffer.ContainsKey(symbol) Then
                    Dim profit = SellDataBuffer(symbol).Price - price
                    row.Cells("ProfitPercent").Value = (profit * 100) / SellDataBuffer(symbol).Price
                    Return
                End If
            End If
        Next
    End Sub

    Private Function ShouldSellBack(symbol As String, boughtPrice As Double, currentPrice As Double)
        'TODO: These conditions need to be verified for correctness.
        If ProfitDeltaModeEnabled Then

            If Not MaxProfitDictionary.ContainsKey(symbol) Then
                MaxProfitDictionary.Add(symbol, boughtPrice)
            End If

            Dim maxProfitPrice As Double = 0.0

            If currentPrice > boughtPrice Then
                maxProfitPrice = currentPrice
            Else
                maxProfitPrice = boughtPrice
            End If

            If maxProfitPrice <= MaxProfitDictionary(symbol) Then
                maxProfitPrice = MaxProfitDictionary(symbol)
            Else
                MaxProfitDictionary(symbol) = maxProfitPrice
            End If

            If (currentPrice - maxProfitPrice) / maxProfitPrice < AppSettings.BuyLongDeltaCloseProfitBelow Then
                AdvancedMockTradingEngine.WriteToFile("Sell Decision. Max Profit Price: " & maxProfitPrice & " Current Price: " & currentPrice)
                MaxProfitDictionary.Remove(symbol)
                Return True
            End If
        Else
            If (currentPrice - boughtPrice) / boughtPrice > AppSettings.BuyLongCloseProfitAbove Or (currentPrice - boughtPrice) / boughtPrice < AppSettings.BuyLongCloseProfitBelow Then
                AdvancedMockTradingEngine.WriteToFile("Sell Decision. Bought Price: " & boughtPrice & " Current Price: " & currentPrice)
                If MaxProfitDictionary.ContainsKey(symbol) Then
                    MaxProfitDictionary.Remove(symbol)
                End If
                Return True
            End If
        End If

        Return False
    End Function

    Private Function ShouldBuyBack(symbol As String, soldPrice As Double, currentPrice As Double)
        'TODO: These conditions need to be verified for correctness.
        If ProfitDeltaModeEnabled Then

            If Not MaxProfitDictionary.ContainsKey(symbol) Then
                MaxProfitDictionary.Add(symbol, soldPrice)
                Return False
            End If

            Dim maxProfitPrice As Double = 0.0

            If currentPrice < soldPrice Then
                maxProfitPrice = currentPrice
            Else
                maxProfitPrice = soldPrice
            End If

            If maxProfitPrice >= MaxProfitDictionary(symbol) Then
                maxProfitPrice = MaxProfitDictionary(symbol)
            Else
                MaxProfitDictionary(symbol) = maxProfitPrice
            End If

            If (maxProfitPrice - currentPrice) / maxProfitPrice < AppSettings.SellShortDeltaCloseProfitBelow Then
                AdvancedMockTradingEngine.WriteToFile("Sell Decision. Max Profit Price: " & maxProfitPrice & " Current Price: " & currentPrice)
                MaxProfitDictionary.Remove(symbol)
                Return True
            End If
        Else
            If (soldPrice - currentPrice) / soldPrice > AppSettings.SellShortCloseProfitAbove Or (soldPrice - currentPrice) / soldPrice < AppSettings.SellShortCloseProfitBelow Then
                AdvancedMockTradingEngine.WriteToFile("Buy Decision. Sold Price: " & soldPrice & " Current Price: " & currentPrice)
                If MaxProfitDictionary.ContainsKey(symbol) Then
                    MaxProfitDictionary.Remove(symbol)
                End If
                Return True
            End If
        End If

        Return False
    End Function

    Private Sub BoughtTrade(symbol As String, quantity As Integer, ByVal price As Double, ByVal toSave As Boolean)
        If SellDataBuffer.ContainsKey(symbol) Then
            If SellDataBuffer(symbol).Quantity >= quantity Then
                SellDataBuffer(symbol).Quantity = SellDataBuffer(symbol).Quantity - quantity
            Else
                Throw New Exception("Invalid Buy, you can't buy long and buy at the samme time.")
            End If
            If SellDataBuffer(symbol).Quantity = 0 Then
                AdvancedMockTradingEngine.WriteToFile("Removing symbol from sell data buffer, " & symbol)
                SellDataBuffer.Remove(symbol)
                MarketWatcher.StopWatching(symbol)
            End If
            Return
        End If

        If Not BuyTempList.Contains(symbol) Then
            AdvancedMockTradingEngine.WriteToFile("Invalid Fresh buy without any entry in temp list " & symbol)
            Return
        End If

        BuyTempList.Remove(symbol)

        If BuyDataBuffer.ContainsKey(symbol) Then
            BuyDataBuffer(symbol).Quantity = BuyDataBuffer(symbol).Quantity + quantity
            AdvancedMockTradingEngine.WriteToFile("Invalid Buy, the symbol is already in the buy data buffer.")
        Else
            BuyDataBuffer.Add(symbol, New TradeSnapshot(symbol, quantity, price))
            AdvancedMockTradingEngine.WriteToFile("Symbol added to buy data buffer " & symbol & " at price " & price.ToString())
            'If toSave Then
            '    Dim trade As New Trade()
            '    trade.IsOpen = True
            '    trade.Symbol = symbol
            '    trade.TradePrice = price
            '    trade.TradeTime = DateTime.Now
            '    trade.TradeVolume = quantity
            '    trade.TradeType = Enums.TradeType.BuyLong
            '    DataLayer.WriteTrade(trade)
            'End If
            MarketWatcher.StartWatching(symbol)
        End If

    End Sub

    Private Sub SoldTrade(symbol As String, quantity As Integer, price As Double, ByVal toSave As Boolean)
        If BuyDataBuffer.ContainsKey(symbol) Then
            If BuyDataBuffer(symbol).Quantity >= quantity Then
                BuyDataBuffer(symbol).Quantity = BuyDataBuffer(symbol).Quantity - quantity
            Else
                Throw New Exception("Invalid Sell, you can't sell short and sell at the samme time.")
            End If
            If BuyDataBuffer(symbol).Quantity = 0 Then
                AdvancedMockTradingEngine.WriteToFile("Removing symbol from buy data buffer, " & symbol)
                BuyDataBuffer.Remove(symbol)
                MarketWatcher.StopWatching(symbol)
            End If
            Return
        End If

        If Not SellTempList.Contains(symbol) Then
            AdvancedMockTradingEngine.WriteToFile("Invalid Fresh sell without any entry in temp list " & symbol)
            Return
        End If

        SellTempList.Remove(symbol)

        If SellDataBuffer.ContainsKey(symbol) Then
            SellDataBuffer(symbol).Quantity = SellDataBuffer(symbol).Quantity + quantity
            AdvancedMockTradingEngine.WriteToFile("Invalid Buy, the symbol is already in the buy data buffer.")
        Else
            SellDataBuffer.Add(symbol, New TradeSnapshot(symbol, quantity, price))
            AdvancedMockTradingEngine.WriteToFile("Symbol added to sell data buffer " & symbol & " at price " & price.ToString())
            'If toSave Then
            '    Dim trade As New Trade()
            '    trade.IsOpen = True
            '    trade.Symbol = symbol
            '    trade.TradePrice = price
            '    trade.TradeTime = DateTime.Now
            '    trade.TradeVolume = quantity
            '    trade.TradeType = Enums.TradeType.SellShort
            '    DataLayer.WriteTrade(trade)
            'End If
            MarketWatcher.StartWatching(symbol)
        End If
    End Sub

    Private Sub LoadPreviousTrades()
        Dim trades = DataLayer.GetOpenTrades()
        If trades Is Nothing Then
            Return
        End If
        For Each trade As Data.Trade In trades
            If trade.TradeType = Enums.TradeType.BuyLong Then
                BuyDataBuffer.Add(trade.Symbol, New TradeSnapshot(trade.Symbol, trade.TradeVolume, trade.TradePrice))
            Else
                SellDataBuffer.Add(trade.Symbol, New TradeSnapshot(trade.Symbol, trade.TradeVolume, trade.TradePrice))
            End If
            MarketWatcher.StartWatching(trade.Symbol)
        Next
        RebindGrid()
    End Sub

    Private Sub CloseAllTrades()
        For Each symbol As String In BuyDataBuffer.Keys
            Dim ts = BuyDataBuffer(symbol)
            AdvancedMockTradingEngine.WriteToFile("Sell Back Decision for symbol " & symbol & ". Original Buy Price " & ts.Price)
            RaiseEvent SellWithoutCheck(symbol, ts.Quantity)
        Next

        For Each symbol As String In SellDataBuffer.Keys
            Dim ts = SellDataBuffer(symbol)
            AdvancedMockTradingEngine.WriteToFile("Buy Back Decision for symbol " & symbol & ". Original Sell Price " & ts.Price)
            RaiseEvent BuyWithoutCheck(symbol, ts.Quantity)
        Next
    End Sub

    Private Sub SetUpTimer()
        _isTradeTime = True
        _timer = New Timer()
        Dim timeSpan As TimeSpan

        If DateTime.Now.TimeOfDay < AppSettings.TradeCloseTime.TimeOfDay Then
            timeSpan = AppSettings.TradeCloseTime.TimeOfDay - DateTime.Now.TimeOfDay
        Else
            timeSpan = DateTime.Now.TimeOfDay - AppSettings.TradeCloseTime.TimeOfDay
            timeSpan = New TimeSpan(24, 0, 0) - timeSpan
        End If

        _timer.Interval = timeSpan.TotalMilliseconds
        AddHandler _timer.Tick, AddressOf Timer_Tick
        _timer.Start()
    End Sub
#End Region

#Region "Event Handlers"
    Private Sub MarketWatcher_TradeOccurred(ByVal symbol As String, ByVal tickPrice As TickPriceData, ByVal tickSize As TickSizeData)
        If SellDataBuffer.ContainsKey(symbol) Then
            Dim ts = SellDataBuffer(symbol)
            If ShouldBuyBack(symbol, ts.Price, tickPrice.Price) Then
                AdvancedMockTradingEngine.WriteToFile("Buy Back Decision for symbol " & symbol & " at " & tickPrice.Price & ". Original Sell Price " & ts.Price)
                RaiseEvent BuyWithoutCheck(symbol, ts.Quantity)
            End If
        End If

        If BuyDataBuffer.ContainsKey(symbol) Then
            Dim ts = BuyDataBuffer(symbol)
            If ShouldSellBack(symbol, ts.Price, tickPrice.Price) Then
                AdvancedMockTradingEngine.WriteToFile("Sell Back Decision for symbol " & symbol & " at " & tickPrice.Price & ". Original Buy Price " & ts.Price)
                RaiseEvent SellWithoutCheck(symbol, ts.Quantity)
            End If
        End If

        UpdateCurrentPrice(symbol, tickPrice.Price)
    End Sub

    Private Sub btnHide_Click(sender As System.Object, e As System.EventArgs)
        Me.Hide()
    End Sub

    Private Sub TradeTrackingEngine_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Timer_Tick(ByVal sender As Object, ByVal e As EventArgs)
        If _isTradeTime Then
            _timer.Stop()
            _isTradeTime = False
            CloseAllTrades()
            _timer.Interval = 60000
            _timer.Start()
        Else
            _timer.Stop()
            _timer.Dispose()

            SetUpTimer()
        End If

    End Sub
#End Region

#Region "Interface Methods"
    Public Sub StartEngine() Implements ITradeTrackingEngine.StartEngine
        SetUpTimer()

        'Initialize Dictionaries
        SellDataBuffer = New Dictionary(Of String, TradeSnapshot)
        BuyDataBuffer = New Dictionary(Of String, TradeSnapshot)

        BuyTempList = New List(Of String)
        SellTempList = New List(Of String)

        AxTws1.connect(APIHostAddress, APIPort, ClientId)
        'AxTws2.connect(APIHostAddress, APIHostAddress, ClientId + 13)
        _marketWatcher = New MarketWatcher(AxTws1)
        AddHandler _marketWatcher.TradeOccurred, AddressOf MarketWatcher_TradeOccurred
        Me.Show()
        LoadPreviousTrades()
        Dim m As Integer
        If Integer.TryParse(txtMaxOpenOrders.Text, m) Then
            MaxOpenOrders = Integer.Parse(txtMaxOpenOrders.Text)
        End If
    End Sub

    Public Sub StopEngine() Implements ITradeTrackingEngine.StopEngine
        AxTws1.disconnect()
        _marketWatcher = Nothing
        Me.Hide()
    End Sub

    Public Sub Bought(symbol As String, quantity As Integer, ByVal price As Double) Implements ITradeTrackingEngine.Bought
        BoughtTrade(symbol, quantity, price, True)
        RebindGrid()
    End Sub

    Public Sub Sold(symbol As String, quantity As Integer, price As Double) Implements ITradeTrackingEngine.Sold
        SoldTrade(symbol, quantity, price, True)
        RebindGrid()
    End Sub

    Public Function ShouldBuy(symbol As String, quantity As Integer) As Boolean Implements ITradeTrackingEngine.ShouldBuy
        'If the time is the period within 10 minutes of the trade closing time then do not allow any trades.
        If _isTradeTime = False Then
            Return False
        End If

        If BuyDataBuffer.ContainsKey(symbol) Or SellDataBuffer.ContainsKey(symbol) Or BuyTempList.Contains(symbol) Or SellTempList.Contains(symbol) Then
            'If BuyDataBuffer(symbol).Quantity = quantity Then
            Return False
            'End If
        End If

        If BuyDataBuffer.Count + SellDataBuffer.Count >= MaxOpenOrders Then
            Return False
        End If

        AdvancedMockTradingEngine.WriteToFile("Fresh Buy Decision " & symbol)
        BuyTempList.Add(symbol)
        Return True
    End Function

    Public Function ShouldSell(symbol As String, quantity As Integer) As Boolean Implements ITradeTrackingEngine.ShouldSell
        'If the time is the period within 10 minutes of the trade closing time then do not allow any trades.
        If _isTradeTime = False Then
            Return False
        End If

        If SellDataBuffer.ContainsKey(symbol) Or BuyDataBuffer.ContainsKey(symbol) Or SellTempList.Contains(symbol) Or BuyTempList.Contains(symbol) Then
            'If SellDataBuffer(symbol).Quantity = quantity Then
            Return False
            'End If
        End If

        If BuyDataBuffer.Count + SellDataBuffer.Count >= MaxOpenOrders Then
            Return False
        End If

        SellTempList.Add(symbol)
        AdvancedMockTradingEngine.WriteToFile("Fresh Sell Decision " & symbol)
        Return True
    End Function

    Public Event SellWithoutCheck(ByVal symbol As String, ByVal quantity As Integer) Implements ITradeTrackingEngine.SellWithoutCheck
    Public Event BuyWithoutCheck(ByVal symbol As String, ByVal quantity As Integer) Implements ITradeTrackingEngine.BuyWithoutCheck

#End Region


    Private Sub btnMaxOpenOrdersApply_Click(sender As System.Object, e As System.EventArgs) Handles btnMaxOpenOrdersApply.Click
        Dim m As Integer
        If Integer.TryParse(txtMaxOpenOrders.Text, m) Then
            MaxOpenOrders = Integer.Parse(txtMaxOpenOrders.Text)
        End If
    End Sub
End Class

Class TradeSnapshot

    Public Sub New(ByVal s As String, ByVal q As Integer, ByVal p As Double)
        _symbol = s
        _quantity = q
        _price = p
    End Sub

    Private _symbol As String
    Public Property Symbol() As String
        Get
            Return _symbol
        End Get
        Set(ByVal value As String)
            _symbol = value
        End Set
    End Property

    Private _quantity As Integer
    Public Property Quantity() As Integer
        Get
            Return _quantity
        End Get
        Set(ByVal value As Integer)
            _quantity = value
        End Set
    End Property

    Private _price As Double
    Public Property Price() As Double
        Get
            Return _price
        End Get
        Set(ByVal value As Double)
            _price = value
        End Set
    End Property
End Class
