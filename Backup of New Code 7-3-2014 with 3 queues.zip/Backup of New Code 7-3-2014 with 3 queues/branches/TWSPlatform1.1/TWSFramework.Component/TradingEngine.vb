﻿Imports System.Threading
Imports TWSFramework.Components
Imports DataAccessLayer

Public Class TradingEngine
    Implements ITradingEngine
    Private Shared mutexObj As New Mutex

    Private _dataLayer As DataLayer
    Private ReadOnly Property DataLayer As DataLayer
        Get
            If _dataLayer Is Nothing Then
                _dataLayer = New DataLayer()
            End If
            Return _dataLayer
        End Get
    End Property
    Private _appSettings As AppSettings
    Public ReadOnly Property AppSettings() As AppSettings
        Get
            If _appSettings Is Nothing Then
                _appSettings = DataLayer.GetAppSettings(False)
            End If
            Return _appSettings
        End Get
    End Property

    Private ReadOnly Property APIHostAddress As String
        Get
            Return AppSettings.APIHostAddress
        End Get
    End Property

    Private ReadOnly Property APIPort As Integer
        Get
            Return AppSettings.APIPort
        End Get
    End Property
    Private ReadOnly Property ClientId As Integer
        Get
            Return 1000
        End Get
    End Property

    Private _tradingEngine As MockTradingEngine
    Private ReadOnly Property MockTradingEngine As MockTradingEngine
        Get
            If _tradingEngine Is Nothing Then
                _tradingEngine = New MockTradingEngine()
            End If
            Return _tradingEngine
        End Get
    End Property

    Dim _timeStarted As DateTime
    Dim _lastOrderId = 2050
    Public Sub StartEngine() Implements ITradingEngine.StartEngine

        AxTws1.connect(APIHostAddress, APIPort, ClientId)
        _timeStarted = DateTime.Now
        'AxTws1.reqAllOpenOrders()
        'AxTws1.reqOpenOrders()
        AxTws1.reqIds(1000)
        Me.Show()

    End Sub
    Public Sub StopEngine() Implements ITradingEngine.StopEngine
        AxTws1.disconnect()
        _timeStarted = DateTime.MinValue
        Me.Hide()
    End Sub

    Public Function Buy(symbol As String, quantity As Integer) As Integer Implements ITradingEngine.Buy
        If _timeStarted.Date.Year <> DateTime.Now.Date.Year Then
            Return -1
        End If

        Dim secs = (DateTime.Now - _timeStarted).TotalSeconds
        If (secs < 3) Then
            Thread.Sleep(3000)
        End If

        mutexObj.WaitOne()
        MockTradingEngine.Buy(symbol, quantity)
        _lastOrderId = _lastOrderId + 1

        Dim contract As TWSFramework.Data.Contract
        contract = New TWSFramework.Data.Contract()
        contract.LocalSymbol = symbol
        contract.SecType = TWSFramework.Enums.SecurityType.Stk
        contract.Exchange = "SMART"
        contract.Currency = "USD"
        Dim genericTicks = "100,101,104,106,165,221,225,236"
        Dim twsContract As TWSLib.IContract = AxTws1.createContract()
        contract.RevertToTWSObject(twsContract)

        Dim twsOrder = AxTws1.createOrder()
        twsOrder.clientId = ClientId
        twsOrder.orderId = _lastOrderId
        twsOrder.permId = _lastOrderId
        twsOrder.action = "BUY"
        twsOrder.orderType = "MKT"
        twsOrder.totalQuantity = quantity

        twsOrder.transmit = 1
        AxTws1.placeOrderEx(twsOrder.orderId, twsContract, twsOrder)
        mutexObj.ReleaseMutex()
        Return twsOrder.orderId
    End Function

    Public Function Sell(symbol As String, quantity As Integer) As Integer Implements ITradingEngine.Sell
        If _timeStarted.Date <> DateTime.Now.Date Then
            Return -1
        End If

        Dim secs = (DateTime.Now - _timeStarted).TotalSeconds
        If (secs < 3) Then
            Thread.Sleep(3000)
        End If

        mutexObj.WaitOne()
        MockTradingEngine.Sell(symbol, quantity)
        _lastOrderId = _lastOrderId + 1

        Dim contract As TWSFramework.Data.Contract
        contract = New TWSFramework.Data.Contract()
        contract.LocalSymbol = symbol
        contract.SecType = TWSFramework.Enums.SecurityType.Stk
        contract.Exchange = "SMART"
        contract.Currency = "USD"
        Dim genericTicks = "100,101,104,106,165,221,225,236"
        Dim twsContract As TWSLib.IContract = AxTws1.createContract()
        contract.RevertToTWSObject(twsContract)

        Dim twsOrder = AxTws1.createOrder()
        twsOrder.clientId = ClientId
        twsOrder.orderId = _lastOrderId
        twsOrder.permId = _lastOrderId
        twsOrder.action = "SELL"
        twsOrder.orderType = "MKT"
        twsOrder.totalQuantity = quantity
        twsOrder.transmit = 1
        AxTws1.placeOrderEx(_lastOrderId, twsContract, twsOrder)
        mutexObj.ReleaseMutex()
        Return _lastOrderId

    End Function

    Private Sub AxTws1_orderStatus(sender As System.Object, e As AxTWSLib._DTwsEvents_orderStatusEvent) Handles AxTws1.orderStatus
        If e.id > _lastOrderId Then
            _lastOrderId = e.id
        End If
        If e.status.Equals("filled", StringComparison.OrdinalIgnoreCase) Then
            RaiseEvent OrderCompleted(e.id, e.avgFillPrice, e.filled)
        End If
        If e.status.Equals("cancelled", StringComparison.OrdinalIgnoreCase) Then
            RaiseEvent OrderCompleted(e.id, -1, -1)
        End If
    End Sub

    Public Event OrderCompleted(orderId As Integer, price As Double, quantity As Integer) Implements ITradingEngine.OrderCompleted

    Private Sub AxTws1_errMsg(sender As System.Object, e As AxTWSLib._DTwsEvents_errMsgEvent) Handles AxTws1.errMsg
        txtDebug.Text = txtDebug.Text & e.errorCode & ":" & e.errorMsg & vbCrLf
        txtDebug.ScrollToCaret()
    End Sub

    Private Sub AxTws1_openOrderEx(sender As System.Object, e As AxTWSLib._DTwsEvents_openOrderExEvent) Handles AxTws1.openOrderEx
        If e.orderId > _lastOrderId Then
            _lastOrderId = e.orderId
        End If
    End Sub

    Private Sub AxTws1_nextValidId(sender As System.Object, e As AxTWSLib._DTwsEvents_nextValidIdEvent) Handles AxTws1.nextValidId
        _lastOrderId = e.id - 1
    End Sub

    Private Sub TradingEngine_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
