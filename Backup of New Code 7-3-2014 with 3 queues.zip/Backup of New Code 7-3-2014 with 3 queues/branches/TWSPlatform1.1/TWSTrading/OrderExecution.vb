﻿Public Class OrderExecution
#Region "Form Properties"
    Private ReadOnly Property APIHostAddress As String
        Get
            Return ""
        End Get
    End Property

    Private ReadOnly Property APIPort As Integer
        Get
            Return 7496
        End Get
    End Property

    Private ReadOnly Property MinCommon As Integer
        Get
            Return 2
        End Get
    End Property

    Private ReadOnly Property SnapshotGapMilliseconds As Integer
        Get
            Return 10000
        End Get
    End Property
    Private ReadOnly Property ClientId As Integer
        Get
            Return 100
        End Get
    End Property
#End Region

    Private Sub btnConnect_Click(sender As System.Object, e As System.EventArgs) Handles btnConnect.Click
        AxTws1.connect(APIHostAddress, APIPort, ClientId)
    End Sub

    Private Sub AxTws1_errMsg(ByVal sender As System.Object, ByVal e As AxTWSLib._DTwsEvents_errMsgEvent) Handles AxTws1.errMsg
        txtDebug.Text = txtDebug.Text & e.errorCode & ":" & e.errorMsg & vbCrLf
        txtDebug.ScrollToCaret()
    End Sub

    Private Sub btnPlaceOrder_Click(sender As System.Object, e As System.EventArgs) Handles btnPlaceOrder.Click
        Dim contract As TWSFramework.Data.Contract
        contract = New TWSFramework.Data.Contract()
        contract.LocalSymbol = "XRX"
        contract.SecType = TWSFramework.Enums.SecurityType.Stk
        contract.Exchange = "SMART"
        contract.Currency = "USD"
        Dim genericTicks = "100,101,104,106,165,221,225,236"
        Dim twsContract As TWSLib.IContract = AxTws1.createContract()
        contract.RevertToTWSObject(twsContract)

        Dim twsOrder = AxTws1.createOrder()
        twsOrder.clientId = ClientId
        twsOrder.orderId = 110
        twsOrder.permId = 110
        twsOrder.action = "SELL"
        twsOrder.orderType = "MKT"
        twsOrder.totalQuantity = 1
        twsOrder.transmit = 1
        AxTws1.placeOrderEx(110, twsContract, twsOrder)

    End Sub
End Class