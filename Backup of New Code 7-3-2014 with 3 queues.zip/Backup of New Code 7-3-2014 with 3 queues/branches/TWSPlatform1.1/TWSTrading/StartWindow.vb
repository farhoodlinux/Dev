﻿
Imports TWSFramework
Imports TWSFramework.Events



Public Class StartWindow

    Private ScannerFrm As ScannerForm

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click
        ScannerFrm = New ScannerForm()
        ScannerFrm.StartWindowForm = Me
        ScannerFrm.Show()
    End Sub

    Public Property ErrMsgText() As String
        Get
            Return Me.ErrorMsg.Text
        End Get
        Set(ByVal value As String)
            Me.ErrorMsg.Text = value
        End Set
    End Property

    Private Sub StartWindow_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub


    Private Sub ErrorMsg_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ErrorMsg.SelectedIndexChanged

    End Sub

    Private Sub StopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopButton.Click

    End Sub

    Private Sub BtnDataEntry_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDataEntry.Click
        Dim dataEntryForm = New ScannersDataEntry()
        dataEntryForm.Show()
    End Sub

    Private Sub btnPlaceOrder_Click(sender As System.Object, e As System.EventArgs) Handles btnPlaceOrder.Click
        Dim orderForm = New OrderExecution()
        orderForm.Show()
    End Sub
End Class