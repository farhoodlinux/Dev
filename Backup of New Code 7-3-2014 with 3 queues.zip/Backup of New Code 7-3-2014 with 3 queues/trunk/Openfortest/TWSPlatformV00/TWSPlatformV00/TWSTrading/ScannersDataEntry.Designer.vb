﻿
Imports System.Windows.Forms
Imports System.Drawing

Partial Public Class ScannersDataEntry
    ''' <summary>
    ''' Required designer variable.
    ''' </summary>
    Private components As System.ComponentModel.IContainer = Nothing

    ''' <summary>
    ''' Clean up any resources being used.
    ''' </summary>
    ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso (components IsNot Nothing) Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

#Region "Windows Form Designer generated code"

    ''' <summary>
    ''' Required method for Designer support - do not modify
    ''' the contents of this method with the code editor.
    ''' </summary>
    Private Sub InitializeComponent()
        Me.groupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkListBoxLocation = New System.Windows.Forms.CheckedListBox()
        Me.chkEnabled = New System.Windows.Forms.CheckBox()
        Me.txtMarketCapAbove = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.txtMarketCapBelow = New System.Windows.Forms.TextBox()
        Me.label2 = New System.Windows.Forms.Label()
        Me.cmbStockType = New System.Windows.Forms.ComboBox()
        Me.label12 = New System.Windows.Forms.Label()
        Me.cmbInstrument = New System.Windows.Forms.ComboBox()
        Me.label10 = New System.Windows.Forms.Label()
        Me.cmbScanCode = New System.Windows.Forms.ComboBox()
        Me.label9 = New System.Windows.Forms.Label()
        Me.txtScannerName = New System.Windows.Forms.TextBox()
        Me.label7 = New System.Windows.Forms.Label()
        Me.txtRequestId = New System.Windows.Forms.TextBox()
        Me.label6 = New System.Windows.Forms.Label()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.txtMaxPrice = New System.Windows.Forms.TextBox()
        Me.label5 = New System.Windows.Forms.Label()
        Me.txtMinPrice = New System.Windows.Forms.TextBox()
        Me.label3 = New System.Windows.Forms.Label()
        Me.dgvScanners = New System.Windows.Forms.DataGridView()
        Me.groupBox1.SuspendLayout()
        CType(Me.dgvScanners, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.chkListBoxLocation)
        Me.groupBox1.Controls.Add(Me.chkEnabled)
        Me.groupBox1.Controls.Add(Me.txtMarketCapAbove)
        Me.groupBox1.Controls.Add(Me.label1)
        Me.groupBox1.Controls.Add(Me.txtMarketCapBelow)
        Me.groupBox1.Controls.Add(Me.label2)
        Me.groupBox1.Controls.Add(Me.cmbStockType)
        Me.groupBox1.Controls.Add(Me.label12)
        Me.groupBox1.Controls.Add(Me.cmbInstrument)
        Me.groupBox1.Controls.Add(Me.label10)
        Me.groupBox1.Controls.Add(Me.txtScannerName)
        Me.groupBox1.Controls.Add(Me.label7)
        Me.groupBox1.Controls.Add(Me.txtRequestId)
        Me.groupBox1.Controls.Add(Me.label6)
        Me.groupBox1.Controls.Add(Me.btnDelete)
        Me.groupBox1.Controls.Add(Me.btnClear)
        Me.groupBox1.Controls.Add(Me.btnUpdate)
        Me.groupBox1.Controls.Add(Me.txtMaxPrice)
        Me.groupBox1.Controls.Add(Me.label5)
        Me.groupBox1.Controls.Add(Me.txtMinPrice)
        Me.groupBox1.Controls.Add(Me.label3)
        Me.groupBox1.Location = New System.Drawing.Point(11, 388)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(812, 96)
        Me.groupBox1.TabIndex = 3
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Update Data"
        '
        'chkListBoxLocation
        '
        Me.chkListBoxLocation.CheckOnClick = True
        Me.chkListBoxLocation.FormattingEnabled = True
        Me.chkListBoxLocation.Location = New System.Drawing.Point(637, 13)
        Me.chkListBoxLocation.Name = "chkListBoxLocation"
        Me.chkListBoxLocation.Size = New System.Drawing.Size(169, 79)
        Me.chkListBoxLocation.TabIndex = 33
        '
        'chkEnabled
        '
        Me.chkEnabled.AutoSize = True
        Me.chkEnabled.Location = New System.Drawing.Point(566, 42)
        Me.chkEnabled.Name = "chkEnabled"
        Me.chkEnabled.Size = New System.Drawing.Size(65, 17)
        Me.chkEnabled.TabIndex = 32
        Me.chkEnabled.Text = "Enabled"
        Me.chkEnabled.UseVisualStyleBackColor = True
        '
        'txtMarketCapAbove
        '
        Me.txtMarketCapAbove.Location = New System.Drawing.Point(264, 69)
        Me.txtMarketCapAbove.Name = "txtMarketCapAbove"
        Me.txtMarketCapAbove.Size = New System.Drawing.Size(63, 20)
        Me.txtMarketCapAbove.TabIndex = 31
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(162, 72)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(96, 13)
        Me.label1.TabIndex = 30
        Me.label1.Text = "Market Cap Above"
        '
        'txtMarketCapBelow
        '
        Me.txtMarketCapBelow.Location = New System.Drawing.Point(105, 69)
        Me.txtMarketCapBelow.Name = "txtMarketCapBelow"
        Me.txtMarketCapBelow.Size = New System.Drawing.Size(51, 20)
        Me.txtMarketCapBelow.TabIndex = 29
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(6, 71)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(91, 13)
        Me.label2.TabIndex = 28
        Me.label2.Text = "MarketCapBelow:"
        '
        'cmbStockType
        '
        Me.cmbStockType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStockType.FormattingEnabled = True
        Me.cmbStockType.Location = New System.Drawing.Point(433, 39)
        Me.cmbStockType.Name = "cmbStockType"
        Me.cmbStockType.Size = New System.Drawing.Size(127, 21)
        Me.cmbStockType.TabIndex = 27
        '
        'label12
        '
        Me.label12.AutoSize = True
        Me.label12.Location = New System.Drawing.Point(393, 42)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(34, 13)
        Me.label12.TabIndex = 26
        Me.label12.Text = "Type:"
        '
        'cmbInstrument
        '
        Me.cmbInstrument.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbInstrument.FormattingEnabled = True
        Me.cmbInstrument.Location = New System.Drawing.Point(252, 39)
        Me.cmbInstrument.Name = "cmbInstrument"
        Me.cmbInstrument.Size = New System.Drawing.Size(135, 21)
        Me.cmbInstrument.TabIndex = 23
        '
        'label10
        '
        Me.label10.AutoSize = True
        Me.label10.Location = New System.Drawing.Point(187, 42)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(59, 13)
        Me.label10.TabIndex = 22
        Me.label10.Text = "Instrument:"
        '
        'cmbScanCode
        '
        Me.cmbScanCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbScanCode.FormattingEnabled = True
        Me.cmbScanCode.Location = New System.Drawing.Point(86, 337)
        Me.cmbScanCode.Name = "cmbScanCode"
        Me.cmbScanCode.Size = New System.Drawing.Size(215, 21)
        Me.cmbScanCode.TabIndex = 21
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.Location = New System.Drawing.Point(17, 340)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(63, 13)
        Me.label9.TabIndex = 20
        Me.label9.Text = "Scan Code:"
        '
        'txtScannerName
        '
        Me.txtScannerName.Location = New System.Drawing.Point(219, 13)
        Me.txtScannerName.Name = "txtScannerName"
        Me.txtScannerName.Size = New System.Drawing.Size(131, 20)
        Me.txtScannerName.TabIndex = 17
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Location = New System.Drawing.Point(132, 16)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(81, 13)
        Me.label7.TabIndex = 16
        Me.label7.Text = "Scanner Name:"
        '
        'txtRequestId
        '
        Me.txtRequestId.Location = New System.Drawing.Point(71, 13)
        Me.txtRequestId.Name = "txtRequestId"
        Me.txtRequestId.ReadOnly = True
        Me.txtRequestId.Size = New System.Drawing.Size(54, 20)
        Me.txtRequestId.TabIndex = 15
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Location = New System.Drawing.Point(6, 16)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(62, 13)
        Me.label6.TabIndex = 14
        Me.label6.Text = "Request Id:"
        '
        'btnDelete
        '
        Me.btnDelete.Enabled = False
        Me.btnDelete.Location = New System.Drawing.Point(348, 66)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(91, 23)
        Me.btnDelete.TabIndex = 13
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(445, 66)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(91, 23)
        Me.btnClear.TabIndex = 13
        Me.btnClear.Text = "Clear Data"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(542, 66)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(89, 23)
        Me.btnUpdate.TabIndex = 13
        Me.btnUpdate.Text = "Add Scanner"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'txtMaxPrice
        '
        Me.txtMaxPrice.Location = New System.Drawing.Point(558, 13)
        Me.txtMaxPrice.Name = "txtMaxPrice"
        Me.txtMaxPrice.Size = New System.Drawing.Size(73, 20)
        Me.txtMaxPrice.TabIndex = 10
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Location = New System.Drawing.Point(495, 16)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(66, 13)
        Me.label5.TabIndex = 9
        Me.label5.Text = "Price Below:"
        '
        'txtMinPrice
        '
        Me.txtMinPrice.Location = New System.Drawing.Point(427, 13)
        Me.txtMinPrice.Name = "txtMinPrice"
        Me.txtMinPrice.Size = New System.Drawing.Size(62, 20)
        Me.txtMinPrice.TabIndex = 7
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Location = New System.Drawing.Point(356, 16)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(68, 13)
        Me.label3.TabIndex = 6
        Me.label3.Text = "Price Above:"
        '
        'dgvScanners
        '
        Me.dgvScanners.AllowUserToAddRows = False
        Me.dgvScanners.AllowUserToDeleteRows = False
        Me.dgvScanners.AllowUserToOrderColumns = True
        Me.dgvScanners.AllowUserToResizeRows = False
        Me.dgvScanners.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvScanners.Location = New System.Drawing.Point(12, 12)
        Me.dgvScanners.MultiSelect = False
        Me.dgvScanners.Name = "dgvScanners"
        Me.dgvScanners.ReadOnly = True
        Me.dgvScanners.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.dgvScanners.ShowCellErrors = False
        Me.dgvScanners.ShowCellToolTips = False
        Me.dgvScanners.ShowEditingIcon = False
        Me.dgvScanners.ShowRowErrors = False
        Me.dgvScanners.Size = New System.Drawing.Size(811, 308)
        Me.dgvScanners.TabIndex = 2
        '
        'ScannersDataEntry
        '
        Me.ClientSize = New System.Drawing.Size(835, 543)
        Me.Controls.Add(Me.groupBox1)
        Me.Controls.Add(Me.dgvScanners)
        Me.Controls.Add(Me.label9)
        Me.Controls.Add(Me.cmbScanCode)
        Me.Name = "ScannersDataEntry"
        Me.Text = "ScannersDataEntry"
        Me.groupBox1.ResumeLayout(False)
        Me.groupBox1.PerformLayout()
        CType(Me.dgvScanners, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Private groupBox1 As GroupBox
    Private WithEvents btnUpdate As Button
    Private txtMaxPrice As TextBox
    Private label5 As Label
    Private txtMinPrice As TextBox
    Private label3 As Label
    Private WithEvents dgvScanners As DataGridView
    Private txtScannerName As TextBox
    Private label7 As Label
    Private txtRequestId As TextBox
    Private label6 As Label
    Private cmbScanCode As ComboBox
    Private label9 As Label
    Private cmbInstrument As ComboBox
    Private label10 As Label
    Private cmbStockType As ComboBox
    Private label12 As Label
    Private WithEvents btnClear As Button
    Private txtMarketCapAbove As TextBox
    Private label1 As Label
    Private txtMarketCapBelow As TextBox
    Private label2 As Label
    Private chkEnabled As CheckBox
    Friend WithEvents chkListBoxLocation As System.Windows.Forms.CheckedListBox
    Private WithEvents btnDelete As System.Windows.Forms.Button
End Class