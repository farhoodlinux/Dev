﻿Imports System.IO
Imports System.Threading

Public Class Utilities
    Private Shared m As New Object

    Private Shared _fileLocation As String
    Private Shared ReadOnly Property FileLocation() As String
        Get
            If _fileLocation Is Nothing Then
                _fileLocation = Directory.GetParent(System.Reflection.Assembly.GetExecutingAssembly().Location).FullName.TrimEnd("\") & "\"
            End If
            Return _fileLocation
        End Get
    End Property

    Public Shared Function ConvertBoolToInt(ByVal boolToConvert As Boolean) As Integer
        Return CInt(IIf(boolToConvert = True, 1, 0))
    End Function


    Public Shared Function ConvertIntToBool(ByVal intToConvert As Integer) As Boolean
        Return CBool(IIf(intToConvert > 0, True, False))
    End Function

    Public Shared Sub WriteToFile(ByVal msg As Object)
        'm.WaitOne()
        WriteToFile("log.txt", msg.ToString())
        'm.ReleaseMutex()
    End Sub
    Public Shared Sub WriteToImpVolFile(msg As String)
        WriteToFile("impVolLog.txt", msg)
    End Sub

    Private Shared Sub WriteToFile(fileName As String, msg As String)
        Dim message = msg.ToString()
        Monitor.Enter(m)
        Dim f As New FileStream(FileLocation & fileName, FileMode.Append)
        Dim fs As New StreamWriter(f)
        fs.WriteLine(DateTime.Now)
        fs.WriteLine(message)
        fs.WriteLine()
        fs.Close()
        Monitor.Exit(m)
    End Sub

    Public Shared Sub WriteToFileAsync(ByVal message As String)
        'Dim t As New Thread(New ParameterizedThreadStart(AddressOf WriteToFile))
        't.Start(message)
    End Sub

    Public Shared Function GetQuantity(qpFactor As Double, price As Double) As Integer
        Dim quantity As Integer = Fix(Math.Floor(qpFactor / price))
        Return quantity
    End Function

    Public Shared Function GetSellProfitPercent(boughtPrice As Double, currentPrice As Double, quantity As Integer, pairSecuritySoldPrice As Double, pairSecurityCurrentPrice As Double, pairQuantity As Integer) As Double
        Return (((currentPrice - boughtPrice) * quantity) + ((pairSecuritySoldPrice - pairSecurityCurrentPrice) * pairQuantity)) / ((boughtPrice * quantity) + (pairSecuritySoldPrice * pairQuantity))
    End Function

    Public Shared Function GetBuyProfitPercent(soldPrice As Double, currentPrice As Double, quantity As Integer, pairSecurityBoughtPrice As Double, pairSecurityCurrentPrice As Double, pairQuantity As Integer) As Double
        Return (((soldPrice - currentPrice) * quantity) + ((pairSecurityCurrentPrice - pairSecurityBoughtPrice) * pairQuantity)) / ((soldPrice * quantity) + (pairSecurityBoughtPrice * pairQuantity))
    End Function
End Class
