﻿Imports System.Threading
Imports TWSFramework.Components
Imports DataAccessLayer

Public Class TradingEngine
    Implements ITradingEngine
    Private Shared mutexObj As New Mutex

    Private _dataLayer As DataLayer
    Private ReadOnly Property DataLayer As DataLayer
        Get
            If _dataLayer Is Nothing Then
                _dataLayer = New DataLayer()
            End If
            Return _dataLayer
        End Get
    End Property
    Private _appSettings As AppSettings
    Public ReadOnly Property AppSettings() As AppSettings
        Get
            If _appSettings Is Nothing Then
                _appSettings = DataLayer.GetAppSettings(False)
            End If
            Return _appSettings
        End Get
    End Property

    Private ReadOnly Property APIHostAddress As String
        Get
            Return AppSettings.APIHostAddress
        End Get
    End Property

    Private ReadOnly Property APIPort As Integer
        Get
            Return AppSettings.APIPort
        End Get
    End Property
    Private ReadOnly Property ClientId As Integer
        Get
            Return 1000
        End Get
    End Property

    Private _tradingEngine As MockTradingEngine
    Private ReadOnly Property MockTradingEngine As MockTradingEngine
        Get
            If _tradingEngine Is Nothing Then
                _tradingEngine = New MockTradingEngine()
            End If
            Return _tradingEngine
        End Get
    End Property

    Dim _timeStarted As DateTime
    Dim _lastOrderId = 2050
    Public Sub StartEngine() Implements ITradingEngine.StartEngine

<<<<<<< .mine
=======
        'PairedSecurityDictionary = New Dictionary(Of Integer, PairSecurity)
        'PairedSecurityOrderDictionary = New Dictionary(Of Integer, Integer)
        'CompletedOrderDictionary = New Dictionary(Of Integer, AxTWSLib._DTwsEvents_orderStatusEvent)
>>>>>>> .r198
        AxTws1.connect(APIHostAddress, APIPort, ClientId)
        _timeStarted = DateTime.Now
        'AxTws1.reqAllOpenOrders()
        'AxTws1.reqOpenOrders()
        AxTws1.reqIds(1000)
        Me.Show()

    End Sub
    Public Sub StopEngine() Implements ITradingEngine.StopEngine
        AxTws1.disconnect()
        _timeStarted = DateTime.MinValue
        Me.Hide()
    End Sub

<<<<<<< .mine
    Public Function Buy(symbol As String, quantity As Integer) As Integer Implements ITradingEngine.Buy
        If _timeStarted.Date.Year <> DateTime.Now.Date.Year Then
            Return -1
        End If
=======
    'Private _pairedSecurityDictionary As Dictionary(Of Integer, PairSecurity)
    'Public Property PairedSecurityDictionary() As Dictionary(Of Integer, PairSecurity)
    '    Get
    '        Return _pairedSecurityDictionary
    '    End Get
    '    Set(ByVal value As Dictionary(Of Integer, PairSecurity))
    '        _pairedSecurityDictionary = value
    '    End Set
    'End Property
>>>>>>> .r198

<<<<<<< .mine
        Dim secs = (DateTime.Now - _timeStarted).TotalSeconds
        If (secs < 3) Then
            Thread.Sleep(3000)
        End If
=======
    'Private _pairedSecurityOrderDictionary As Dictionary(Of Integer, Integer)
    'Public Property PairedSecurityOrderDictionary() As Dictionary(Of Integer, Integer)
    '    Get
    '        Return _pairedSecurityOrderDictionary
    '    End Get
    '    Set(ByVal value As Dictionary(Of Integer, Integer))
    '        _pairedSecurityOrderDictionary = value
    '    End Set
    'End Property
>>>>>>> .r198

<<<<<<< .mine
        mutexObj.WaitOne()
        MockTradingEngine.Buy(symbol, quantity)
        _lastOrderId = _lastOrderId + 1
=======
    'Private _completedOrderDictionary As Dictionary(Of Integer, AxTWSLib._DTwsEvents_orderStatusEvent)
    'Public Property CompletedOrderDictionary() As Dictionary(Of Integer, AxTWSLib._DTwsEvents_orderStatusEvent)
    '    Get
    '        Return _completedOrderDictionary
    '    End Get
    '    Set(ByVal value As Dictionary(Of Integer, AxTWSLib._DTwsEvents_orderStatusEvent))
    '        _completedOrderDictionary = value
    '    End Set
    'End Property



    Public Function Buy(symbol As String, quantity As Integer) As Integer Implements ITradingEngine.Buy
        'If _timeStarted.Date.Year <> DateTime.Now.Date.Year Then
        '    Return -1
        'End If
>>>>>>> .r198

        Dim contract As TWSFramework.Data.Contract
        contract = New TWSFramework.Data.Contract()
        contract.LocalSymbol = symbol
        contract.SecType = TWSFramework.Enums.SecurityType.Stk
        contract.Exchange = "SMART"
        contract.Currency = "USD"
        Dim genericTicks = "100,101,104,106,165,221,225,236"
        Dim twsContract As TWSLib.IContract = AxTws1.createContract()
        contract.RevertToTWSObject(twsContract)

        Dim twsOrder = AxTws1.createOrder()
        twsOrder.clientId = ClientId
        twsOrder.orderId = _lastOrderId
        twsOrder.permId = _lastOrderId
        twsOrder.action = "BUY"
        twsOrder.orderType = "MKT"
        twsOrder.totalQuantity = quantity

        twsOrder.transmit = 1
        AxTws1.placeOrderEx(twsOrder.orderId, twsContract, twsOrder)
        mutexObj.ReleaseMutex()
        Return twsOrder.orderId
    End Function

<<<<<<< .mine
    Public Function Sell(symbol As String, quantity As Integer) As Integer Implements ITradingEngine.Sell
=======
    Public Function Sell(symbol As String, quantity As Integer) As Integer Implements ITradingEngine.Sell
        'If _timeStarted.Date <> DateTime.Now.Date Then
        '    Return -1
        'End If

        'Dim secs = (DateTime.Now - _timeStarted).TotalSeconds
        'If (secs < 3) Then
        '    Thread.Sleep(3000)
        'End If

        'mutexObj.WaitOne()
        'Dim oid = PlaceOrder(symbol, quantity, "SELL", _lastOrderId)
        '_lastOrderId = oid
        'mutexObj.ReleaseMutex()

        'If Not pairedSecurity Is Nothing Then
        '    PairedSecurityDictionary.Add(oid, pairedSecurity)
        'End If

        'Return oid
        Return PlaceOrder(symbol, quantity, "SELL", _lastOrderId)
    End Function

    Private Function PlaceOrder(symbol As String, quantity As Integer, action As String, lastOrderId As Integer) As Integer ', pairedSecurity As PairSecurity) As Integer
>>>>>>> .r198
        If _timeStarted.Date <> DateTime.Now.Date Then
            Return -1
        End If

        Dim secs = (DateTime.Now - _timeStarted).TotalSeconds
        If (secs < 3) Then
            Thread.Sleep(3000)
        End If

        mutexObj.WaitOne()
<<<<<<< .mine
=======
        Dim oid = PlaceOrderNew(symbol, quantity, action, _lastOrderId)
        _lastOrderId = oid
        mutexObj.ReleaseMutex()

        'If Not pairedSecurity Is Nothing Then
        '    PairedSecurityDictionary.Add(oid, pairedSecurity)
        'End If

        Return oid
    End Function

    Private Function PlaceOrderNew(symbol As String, quantity As Integer, action As String, lastOrderId As Integer) As Integer
        'mutexObj.WaitOne()
>>>>>>> .r198
        'MockTradingEngine.Sell(symbol, quantity)
        _lastOrderId = _lastOrderId + 1

        Dim contract As TWSFramework.Data.Contract
        contract = New TWSFramework.Data.Contract()
        contract.LocalSymbol = symbol
        contract.SecType = TWSFramework.Enums.SecurityType.Stk
        contract.Exchange = "SMART"
        contract.Currency = "USD"
        Dim genericTicks = "100,101,104,106,165,221,225,236"
        Dim twsContract As TWSLib.IContract = AxTws1.createContract()
        contract.RevertToTWSObject(twsContract)

        Dim twsOrder = AxTws1.createOrder()
        twsOrder.clientId = ClientId
        twsOrder.orderId = _lastOrderId
        twsOrder.permId = _lastOrderId
        twsOrder.action = "SELL"
        twsOrder.orderType = "MKT"
        twsOrder.totalQuantity = quantity
        twsOrder.transmit = 1
        AxTws1.placeOrderEx(_lastOrderId, twsContract, twsOrder)
        mutexObj.ReleaseMutex()
        Return _lastOrderId

    End Function

    Private Sub AxTws1_orderStatus(sender As System.Object, e As AxTWSLib._DTwsEvents_orderStatusEvent) Handles AxTws1.orderStatus
        If e.id > _lastOrderId Then
            _lastOrderId = e.id
        End If
        If e.status.Equals("filled", StringComparison.OrdinalIgnoreCase) Then
            'If PairedSecurityDictionary.ContainsKey(e.id) Then
            '    Dim pairedSecurity = PairedSecurityDictionary(e.id)
            '    mutexObj.WaitOne()
            '    Dim qty As Integer = Math.Floor((e.avgFillPrice * e.filled) / pairedSecurity.CurrentPrice)
            '    _lastOrderId = PlaceOrder(pairedSecurity.Symbol, qty, pairedSecurity.Action, _lastOrderId)
            '    PairedSecurityOrderDictionary.Add(_lastOrderId, e.id)
            '    CompletedOrderDictionary.Add(e.id, e)
            '    Return
            'End If
            'If PairedSecurityOrderDictionary.ContainsKey(e.id) Then
            '    Dim origOrderId = PairedSecurityOrderDictionary(e.id)
            '    Dim origOrder = CompletedOrderDictionary(origOrderId)
            'End If

            RaiseEvent OrderCompleted(e.id, e.avgFillPrice, e.filled)
        End If
        If e.status.Equals("cancelled", StringComparison.OrdinalIgnoreCase) Then
            RaiseEvent OrderCompleted(e.id, -1, -1)
        End If
    End Sub

    'Public Event OrderCompleted(orderId As Integer, price As Double, quantity As Integer, pairedSecurity As PairSecurity) Implements ITradingEngine.OrderCompleted
    Public Event OrderCompleted(orderId As Integer, price As Double, quantity As Integer) Implements ITradingEngine.OrderCompleted

    Private Sub AxTws1_errMsg(sender As System.Object, e As AxTWSLib._DTwsEvents_errMsgEvent) Handles AxTws1.errMsg
        txtDebug.Text = txtDebug.Text & e.errorCode & ":" & e.errorMsg & vbCrLf
        txtDebug.ScrollToCaret()
    End Sub

    Private Sub AxTws1_openOrderEx(sender As System.Object, e As AxTWSLib._DTwsEvents_openOrderExEvent) Handles AxTws1.openOrderEx
        If e.orderId > _lastOrderId Then
            _lastOrderId = e.orderId
        End If
    End Sub

    Private Sub AxTws1_nextValidId(sender As System.Object, e As AxTWSLib._DTwsEvents_nextValidIdEvent) Handles AxTws1.nextValidId
        _lastOrderId = e.id - 1
    End Sub

    Private Sub TradingEngine_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
