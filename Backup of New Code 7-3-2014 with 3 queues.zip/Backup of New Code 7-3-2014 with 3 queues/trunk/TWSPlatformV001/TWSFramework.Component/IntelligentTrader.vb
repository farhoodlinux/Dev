﻿Imports System.Collections.Generic
Imports TWSFramework.Components
Imports DataAccessLayer
Imports TWSFramework.TimeSpanExtensions
Imports TWSFramework.Data
Imports TWSFramework.Enums

Public Class IntelligentTrader
    'July 7 2013
#Region "Private Members"
    Private Shared mutexObj As New Threading.Mutex()
<<<<<<< .mine
=======
    'Private _isPairSecuritySetup As Boolean = False
>>>>>>> .r198
#End Region

#Region "Public Properties"
    Private _spyChange As Double
    Public Property SpyChange() As Double
        Get
            Return _spyChange
        End Get
        Set(ByVal value As Double)
            _spyChange = value
        End Set
    End Property

    Private _qqqChange As Double
    Public Property QqqChange() As Double
        Get
            Return _qqqChange
        End Get
        Set(ByVal value As Double)
            _qqqChange = value
        End Set
    End Property
    Public ReadOnly Property PairSecurityEnabled As Boolean
        Get
            Return (UsePairSecurities And Not SellPairSecurity Is Nothing And Not BuyPairSecurity Is Nothing And MarketData.ContainsKey(SellPairSecurity.Symbol))
        End Get
    End Property
#End Region

#Region "Components"
    Private Shared _instance As IntelligentTrader
    Public Shared ReadOnly Property Instance As IntelligentTrader
        Get
            If _instance Is Nothing Then
                _instance = New IntelligentTrader()
                _instance.MarketData = New Dictionary(Of String, MarketDataItem)
                _instance.UsePairSecurities = True
            End If
            Return _instance
        End Get
    End Property

    Private _appSettings As AppSettings
    Public ReadOnly Property AppSettings() As AppSettings
        Get
            If _appSettings Is Nothing Then
                _appSettings = DataLayer.GetAppSettings(False)
            End If
            Return _appSettings
        End Get
    End Property

    Private _analyzer As IAnalysisEngine
    Private ReadOnly Property Analyzer As IAnalysisEngine
        Get
            Return AnalyzerEngine.Analyzer
        End Get
    End Property

    Private _tradingEngine As ITradingEngine
    Public Property TradingEngine As ITradingEngine
        Get
            If _tradingEngine Is Nothing Then
                _tradingEngine = New AdvancedMockTradingEngine()
            End If
            Return _tradingEngine
        End Get
        Set(ByVal value As ITradingEngine)
            _tradingEngine = value
        End Set
    End Property

    'Private _tradeTrackingEngine As ITradeTrackingEngine
    Private ReadOnly Property TradeTrackingEngineInstance As ITradeTrackingEngine
        Get
            Return TradeTrackingEngine.Instance
        End Get
    End Property

    Private _dataLayer As DataLayer
    Private ReadOnly Property DataLayer As DataLayer
        Get
            If _dataLayer Is Nothing Then
                _dataLayer = New DataLayer()
            End If
            Return _dataLayer
        End Get
    End Property
#End Region

#Region "Buffers"
    Private _sellDictionary As Dictionary(Of String, Integer)
    Private Property SellDictionary() As Dictionary(Of String, Integer)
        Get
            Return _sellDictionary
        End Get
        Set(ByVal value As Dictionary(Of String, Integer))
            _sellDictionary = value
        End Set
    End Property
    Private _reverseSellDictionary As Dictionary(Of Integer, String)
    Private Property ReverseSellDictionary() As Dictionary(Of Integer, String)
        Get
            Return _reverseSellDictionary
        End Get
        Set(ByVal value As Dictionary(Of Integer, String))
            _reverseSellDictionary = value
        End Set
    End Property

    Private _buyDictionary As Dictionary(Of String, Integer)
    Private Property BuyDictionary() As Dictionary(Of String, Integer)
        Get
            Return _buyDictionary
        End Get
        Set(ByVal value As Dictionary(Of String, Integer))
            _buyDictionary = value
        End Set
    End Property
    Private _reverseBuyDictionary As Dictionary(Of Integer, Trade)
    Private Property ReverseBuyDictionary() As Dictionary(Of Integer, Trade)
        Get
            Return _reverseBuyDictionary
        End Get
        Set(ByVal value As Dictionary(Of Integer, Trade))
            _reverseBuyDictionary = value
        End Set
    End Property

    Private _closeBuyTradeDictionary As Dictionary(Of Integer, String)
    Private Property CloseBuyTradeDictionary() As Dictionary(Of Integer, String)
        Get
            Return _closeBuyTradeDictionary
        End Get
        Set(ByVal value As Dictionary(Of Integer, String))
            _closeBuyTradeDictionary = value
        End Set
    End Property

    Private _closeSellTradeDictionary As Dictionary(Of Integer, String)
    Private Property CloseSellTradeDictionary() As Dictionary(Of Integer, String)
        Get
            Return _closeSellTradeDictionary
        End Get
        Set(ByVal value As Dictionary(Of Integer, String))
            _closeSellTradeDictionary = value
        End Set
    End Property

    Private _pairedSecurityTradeDictionary As Dictionary(Of Integer, TradePairSecurity)
    Private Property PairedSecurityTradeDictionary() As Dictionary(Of Integer, TradePairSecurity)
        Get
            Return _pairedSecurityTradeDictionary
        End Get
        Set(ByVal value As Dictionary(Of Integer, TradePairSecurity))
            _pairedSecurityTradeDictionary = value
        End Set
    End Property

    Private _closePairedSecurityTradeDictionary As Dictionary(Of Integer, TradePairSecurity)
    Private Property ClosePairedSecurityTradeDictionary() As Dictionary(Of Integer, TradePairSecurity)
        Get
            Return _closePairedSecurityTradeDictionary
        End Get
        Set(ByVal value As Dictionary(Of Integer, TradePairSecurity))
            _closePairedSecurityTradeDictionary = value
        End Set
    End Property

    Private _marketData As Dictionary(Of String, MarketDataItem)
    Public Property MarketData() As Dictionary(Of String, MarketDataItem)
        Get
            Return _marketData
        End Get
        Set(ByVal value As Dictionary(Of String, MarketDataItem))
            _marketData = value
        End Set
    End Property

#End Region

#Region "Public Methods"
    Public Sub StartTrader()
        AddHandler Analyzer.MultiLevelAnalysisReady, AddressOf Analyzer_MultiLevelAnalysisReady
        AddHandler TradingEngine.OrderCompleted, AddressOf TradingEngine_OrderCompleted
        AddHandler TradeTrackingEngineInstance.BuyWithoutCheck, AddressOf TradeTrackingEngine_BuyWithoutCheck
        AddHandler TradeTrackingEngineInstance.SellWithoutCheck, AddressOf TradeTrackingEngine_SellWithoutCheck
        SellDictionary = New Dictionary(Of String, Integer)
        BuyDictionary = New Dictionary(Of String, Integer)
        ReverseSellDictionary = New Dictionary(Of Integer, String)
        ReverseBuyDictionary = New Dictionary(Of Integer, Trade)
        CloseBuyTradeDictionary = New Dictionary(Of Integer, String)
        CloseSellTradeDictionary = New Dictionary(Of Integer, String)
        PairedSecurityTradeDictionary = New Dictionary(Of Integer, TradePairSecurity)
        ClosePairedSecurityTradeDictionary = New Dictionary(Of Integer, TradePairSecurity)
        SetupPairSecurities()
        TradingEngine.StartEngine()
        TradeTrackingEngineInstance.StartEngine()
    End Sub

    Public Sub StopTrader()
        RemoveHandler Analyzer.MultiLevelAnalysisReady, AddressOf Analyzer_MultiLevelAnalysisReady
        RemoveHandler TradingEngine.OrderCompleted, AddressOf TradingEngine_OrderCompleted
        RemoveHandler TradeTrackingEngineInstance.BuyWithoutCheck, AddressOf TradeTrackingEngine_BuyWithoutCheck
        RemoveHandler TradeTrackingEngineInstance.SellWithoutCheck, AddressOf TradeTrackingEngine_SellWithoutCheck
        TradingEngine.StopEngine()
        TradeTrackingEngineInstance.StopEngine()
    End Sub
#End Region

#Region "Private Methods"
<<<<<<< .mine
=======
    Private _timer As Timer
    Private Sub SetupPairSecurities()
        '_isPairSecuritySetup = False
        _timer = New Timer()

        Dim securities = DataLayer.GetPairSecurities()

        Dim timeSpan As TimeSpan
        If DateTime.Now.TimeOfDay < AppSettings.TradeOpenTime.TimeOfDay Then
            timeSpan = AppSettings.TradeOpenTime.TimeOfDay - DateTime.Now.TimeOfDay
            securities = Nothing
        Else
            If securities Is Nothing Then
                timeSpan = New TimeSpan(0, 0, 10)
            ElseIf securities.Count = 0 Then
                timeSpan = New TimeSpan(0, 0, 10)
            Else
                If securities(0).InitialChange > securities(1).InitialChange Then
                    SellPairSecurity = securities(0)
                    BuyPairSecurity = securities(1)
                Else
                    SellPairSecurity = securities(1)
                    BuyPairSecurity = securities(0)
                End If
                timeSpan = DateTime.Now.TimeOfDay - AppSettings.TradeCloseTime.TimeOfDay
                timeSpan = New TimeSpan(24, 0, 0) - timeSpan
            End If
        End If

        'If Not securities Is Nothing Then
        '    _isPairSecuritySetup = True
        'End If

        _timer.Interval = timeSpan.TotalMilliseconds
        AddHandler _timer.Tick, AddressOf Timer_Tick
        _timer.Start()


    End Sub

    Private Sub Timer_Tick(sender As Object, e As EventArgs)
        '_isPairSecuritySetup = False
        _timer.Stop()
        If SpyChange > -1000 And QqqChange > -1000 Then
            'SPY and QQQ Change Have been set from the main form
            If SpyChange > QqqChange Then
                SellPairSecurity = New PairSecurity()
                SellPairSecurity.Symbol = "SPY"
                SellPairSecurity.InitialChange = SpyChange
                BuyPairSecurity = New PairSecurity()
                BuyPairSecurity.Symbol = "QQQ"
                BuyPairSecurity.InitialChange = QqqChange
            Else
                SellPairSecurity = New PairSecurity()
                SellPairSecurity.Symbol = "QQQ"
                SellPairSecurity.InitialChange = QqqChange
                BuyPairSecurity = New PairSecurity()
                BuyPairSecurity.Symbol = "SPY"
                BuyPairSecurity.InitialChange = SpyChange
            End If

            DataLayer.SavePairSecurity(BuyPairSecurity)
            DataLayer.SavePairSecurity(SellPairSecurity)

            Dim timeSpan = DateTime.Now.TimeOfDay - AppSettings.TradeCloseTime.TimeOfDay
            timeSpan = New TimeSpan(24, 0, 0) - timeSpan

            _timer.Interval = timeSpan.TotalMilliseconds
        End If
        _timer.Start()
        '_isPairSecuritySetup = True
    End Sub

>>>>>>> .r198
    Private Sub BuyDecision(ByVal symbol As String, ByVal quantity As Integer)
        If TradeTrackingEngineInstance.ShouldBuy(symbol, quantity) Then
            mutexObj.WaitOne()
            If Not BuyDictionary.ContainsKey(symbol) Then
<<<<<<< .mine
                Dim orderId = TradingEngine.Buy(symbol, quantity)
                BuyDictionary.Add(symbol, orderId)
                ReverseBuyDictionary.Add(orderId, symbol)
=======
                Dim trade As New Trade()
                trade.TradeStatus = True
                trade.Symbol = symbol
                trade.TradePrice = MarketData(symbol).Last
                trade.TradeTime = DateTime.Now
                trade.TradeVolume = quantity
                trade.TradeType = TradeType.BuyLong

                If PairSecurityEnabled Then
                    BuyPairSecurity.CurrentPrice = MarketData(BuyPairSecurity.Symbol).Last
                    Dim qty As Integer = Math.Floor((MarketData(symbol).Last * quantity) / BuyPairSecurity.CurrentPrice)
                    Dim t = New TradePairSecurity()
                    t.PairSecurity = BuyPairSecurity

                    t.Trade = trade

                    Dim pairOrderId = TradingEngine.Sell(BuyPairSecurity.Symbol, qty)
                    PairedSecurityTradeDictionary.Add(pairOrderId, t)
                Else
                    Dim orderId = TradingEngine.Buy(symbol, quantity)
                    BuyDictionary.Add(symbol, orderId)
                    ReverseBuyDictionary.Add(orderId, trade)
                End If

>>>>>>> .r198
            End If
            mutexObj.ReleaseMutex()
        End If
    End Sub

    Private Sub SellDecision(ByVal symbol As String, ByVal quantity As Integer)
        If TradeTrackingEngineInstance.ShouldSell(symbol, quantity) Then
            mutexObj.WaitOne()
            If Not SellDictionary.ContainsKey(symbol) Then
                Dim orderId = TradingEngine.Sell(symbol, quantity)
                SellDictionary.Add(symbol, orderId)
                ReverseSellDictionary.Add(orderId, symbol)
            End If
            mutexObj.ReleaseMutex()
        End If
    End Sub

    

    Private Sub PairTradeCompleted(ByVal orderId As Integer, ByVal price As Double, ByVal quantity As Integer)
        mutexObj.WaitOne()
        Dim t = PairedSecurityTradeDictionary(orderId)
        t.Trade.PairedSecuritySymbol = t.PairSecurity.Symbol
        t.Trade.PairedSecurityQuantity = quantity
        t.Trade.PairedSecurityPrice = price

        If t.Trade.TradeType = TradeType.SellShort Then
            DataLayer.WriteTrade(t.Trade)
            TradeTrackingEngineInstance.BuyPairTradeCompleted(t.Trade, t.PairSecurity, price, quantity)
        Else
            Dim tradeOrderId = TradingEngine.Buy(t.Trade.Symbol, t.Trade.TradeVolume)
            BuyDictionary.Add(t.Trade.Symbol, tradeOrderId)
            ReverseBuyDictionary.Add(tradeOrderId, t.Trade)
            TradeTrackingEngineInstance.SellPairTradeCompleted(t.Trade, t.PairSecurity, price, quantity)
        End If

        PairedSecurityTradeDictionary.Remove(orderId)
        mutexObj.ReleaseMutex()
    End Sub

    Private Sub ClosePairTradeCompleted(ByVal orderId As Integer, ByVal price As Double, ByVal quantity As Integer)
        mutexObj.WaitOne()
        Dim t = ClosePairedSecurityTradeDictionary(orderId)
        t.Trade.PairedSecurityClosePrice = price
        If t.Trade.PairedSecurityQuantity <> quantity Then
            Throw New Exception("Invalid quantity for the closing of the paired security.")
        End If
        If t.Trade.TradeType = TradeType.BuyLong Then
            'Paired Security is Sell Short
            t.Trade.PairedSecurityProfitAmount = t.Trade.PairedSecurityPrice - t.Trade.PairedSecurityClosePrice
            t.Trade.PairedSecurityProfitPercent = ((t.Trade.PairedSecurityPrice - t.Trade.PairedSecurityClosePrice) / t.Trade.PairedSecurityPrice) * 100
            t.Trade.TotalProfitAmount = t.Trade.ProfitAmount + t.Trade.PairedSecurityProfitAmount
            t.Trade.TotalProfitPercent = Utilities.GetSellProfitPercent(t.Trade.TradePrice, t.Trade.ClosePrice, t.Trade.PairedSecurityPrice, t.Trade.PairedSecurityClosePrice) * 100
            't.Trade.TotalProfitPercent = (((t.Trade.PairedSecurityPrice - t.Trade.PairedSecurityClosePrice) + (t.Trade.ClosePrice - t.Trade.TradePrice)) / (t.Trade.PairedSecurityPrice + t.Trade.TradePrice)) * 100
            't.Trade.TotalProfitPercent = (t.Trade.ProfitPercent + t.Trade.PairedSecurityProfitPercent) / 2
        Else
            'Paired Security is Buy Long
            t.Trade.PairedSecurityProfitAmount = t.Trade.PairedSecurityClosePrice - t.Trade.PairedSecurityPrice
            t.Trade.PairedSecurityProfitPercent = ((t.Trade.PairedSecurityClosePrice - t.Trade.PairedSecurityPrice) / t.Trade.PairedSecurityPrice) * 100
            t.Trade.TotalProfitAmount = t.Trade.ProfitAmount + t.Trade.PairedSecurityProfitAmount
            t.Trade.TotalProfitPercent = Utilities.GetBuyProfitPercent(t.Trade.TradePrice, t.Trade.ClosePrice, t.Trade.PairedSecurityPrice, t.Trade.PairedSecurityClosePrice) * 100
            't.Trade.TotalProfitPercent = (((t.Trade.PairedSecurityClosePrice - t.Trade.PairedSecurityPrice) + (t.Trade.TradePrice - t.Trade.ClosePrice)) / (t.Trade.PairedSecurityPrice + t.Trade.TradePrice)) * 100
            't.Trade.TotalProfitPercent = (t.Trade.ProfitPercent + t.Trade.PairedSecurityProfitPercent) / 2
        End If
        DataLayer.WriteTrade(t.Trade)
        ClosePairedSecurityTradeDictionary.Remove(orderId)
        mutexObj.ReleaseMutex()
    End Sub
    Private Sub SellOrderCompleted(ByVal orderId As Integer, ByVal price As Double, ByVal quantity As Integer)
        mutexObj.WaitOne()
        If price > 0 And quantity > 0 Then
            TradeTrackingEngineInstance.Sold(ReverseSellDictionary(orderId), quantity, price)
            Dim trade As New Data.Trade()
            trade.TradeStatus = True
            trade.Symbol = ReverseSellDictionary(orderId)
            trade.TradePrice = price
            trade.TradeTime = DateTime.Now
            trade.TradeVolume = quantity
            trade.TradeType = Enums.TradeType.SellShort
            If PairSecurityEnabled Then
                SellPairSecurity.CurrentPrice = MarketData(SellPairSecurity.Symbol).Last
                Dim qty As Integer = Math.Floor((price * quantity) / SellPairSecurity.CurrentPrice)
                Dim pairOrderId = TradingEngine.Buy(SellPairSecurity.Symbol, qty)
                Dim t = New TradePairSecurity()
                t.PairSecurity = SellPairSecurity
                t.Trade = trade
                PairedSecurityTradeDictionary.Add(pairOrderId, t)
            Else
                DataLayer.WriteTrade(trade)
            End If
        End If
        SellDictionary.Remove(ReverseSellDictionary(orderId))
        ReverseSellDictionary.Remove(orderId)

        mutexObj.ReleaseMutex()
    End Sub
    Private Sub BuyOrderCompleted(ByVal orderId As Integer, ByVal price As Double, ByVal quantity As Integer)
        mutexObj.WaitOne()
        If price > 0 And quantity > 0 Then
            TradeTrackingEngineInstance.Bought(ReverseBuyDictionary(orderId).Symbol, quantity, price)
            Dim trade = ReverseBuyDictionary(orderId)
            trade.TradeStatus = True
            trade.TradePrice = price
            trade.TradeTime = DateTime.Now
            trade.TradeVolume = quantity
            DataLayer.WriteTrade(trade)
            'If UsePairSecurities And Not BuyPairSecurity Is Nothing And MarketData.ContainsKey(BuyPairSecurity.Symbol) Then
            '    BuyPairSecurity.CurrentPrice = MarketData(BuyPairSecurity.Symbol).Last
            '    Dim qty As Integer = Math.Floor((price * quantity) / BuyPairSecurity.CurrentPrice)
            '    Dim pairOrderId = TradingEngine.Sell(BuyPairSecurity.Symbol, qty)
            '    Dim t = New TradePairSecurity()
            '    t.PairSecurity = BuyPairSecurity
            '    t.Trade = trade
            '    PairedSecurityTradeDictionary.Add(pairOrderId, t)
            'Else

            'End If
        End If
        BuyDictionary.Remove(ReverseBuyDictionary(orderId).Symbol)
        ReverseBuyDictionary.Remove(orderId)
        mutexObj.ReleaseMutex()
    End Sub

    Private Sub CloseBuyOrderCompleted(ByVal orderId As Integer, ByVal price As Double, ByVal quantity As Integer)
        mutexObj.WaitOne()
        If price > 0 And quantity > 0 Then
            TradeTrackingEngineInstance.Bought(CloseBuyTradeDictionary(orderId), quantity, price)

            Dim trade = DataLayer.GetOpenTradeForSymbol(CloseBuyTradeDictionary(orderId))
            If trade Is Nothing Then
                Throw New Exception("A trade was closed but the corresponding open trade wasn't found in the database.")
            End If

            If trade.TradeVolume <> quantity Then
                Throw New Exception("Invalid quantity while closing the trade.")
            End If

            If trade.TradeType <> TradeType.SellShort Then
                Throw New Exception("Invalid open trade type for the closing trade")
            End If

            trade.ClosePrice = price
            trade.CloseTime = DateTime.Now
            trade.ProfitAmount = trade.TradePrice - trade.ClosePrice
            trade.ProfitPercent = ((trade.TradePrice - trade.ClosePrice) / trade.TradePrice) * 100

            If Not String.IsNullOrEmpty(trade.PairedSecuritySymbol) And trade.PairedSecurityQuantity > 0 Then
                If trade.PairedSecuritySymbol <> SellPairSecurity.Symbol Then
                    Throw New Exception("The paired security symbol for the trade being closed doesn't match the symbol for the correct paired security")
                End If
                Dim pairOrderId = TradingEngine.Sell(trade.PairedSecuritySymbol, trade.PairedSecurityQuantity)
                Dim t = New TradePairSecurity()
                t.PairSecurity = SellPairSecurity
                t.Trade = trade
                ClosePairedSecurityTradeDictionary.Add(pairOrderId, t)
            Else
                trade.TotalProfitAmount = trade.ProfitAmount
                trade.TotalProfitPercent = trade.ProfitPercent
                DataLayer.WriteTrade(trade)
            End If
        End If
        BuyDictionary.Remove(CloseBuyTradeDictionary(orderId))
        CloseBuyTradeDictionary.Remove(orderId)
        mutexObj.ReleaseMutex()
    End Sub

    Private Sub CloseSellOrderCompleted(ByVal orderId As Integer, ByVal price As Double, ByVal quantity As Integer)
        mutexObj.WaitOne()
        If price > 0 And quantity > 0 Then
            TradeTrackingEngineInstance.Sold(CloseSellTradeDictionary(orderId), quantity, price)

            Dim trade = DataLayer.GetOpenTradeForSymbol(CloseSellTradeDictionary(orderId))
            If trade Is Nothing Then
                Throw New Exception("A trade was closed but the corresponding open trade wasn't found in the database.")
            End If

            If trade.TradeVolume <> quantity Then
                Throw New Exception("Invalid quantity while closing the trade.")
            End If

            If trade.TradeType <> TradeType.BuyLong Then
                Throw New Exception("Invalid open trade type for the closing trade")
            End If

            trade.ClosePrice = price
            trade.CloseTime = DateTime.Now
            trade.ProfitAmount = trade.ClosePrice - trade.TradePrice
            trade.ProfitPercent = ((trade.ClosePrice - trade.TradePrice) / trade.TradePrice) * 100

            If Not String.IsNullOrEmpty(trade.PairedSecuritySymbol) And trade.PairedSecurityQuantity > 0 Then
                If trade.PairedSecuritySymbol <> BuyPairSecurity.Symbol Then
                    Throw New Exception("The paired security symbol for the trade being closed doesn't match the symbol for the correct paired security")
                End If
                Dim pairOrderId = TradingEngine.Buy(trade.PairedSecuritySymbol, trade.PairedSecurityQuantity)
                Dim t = New TradePairSecurity()
                t.PairSecurity = BuyPairSecurity
                t.Trade = trade
                ClosePairedSecurityTradeDictionary.Add(pairOrderId, t)
            Else
                trade.TotalProfitAmount = trade.ProfitAmount
                trade.TotalProfitPercent = trade.ProfitPercent
                DataLayer.WriteTrade(trade)
            End If
        End If
        SellDictionary.Remove(CloseSellTradeDictionary.Remove(orderId))
        CloseSellTradeDictionary.Remove(orderId)
        mutexObj.ReleaseMutex()
    End Sub
#End Region

#Region "Event Handlers"
    Private Sub Analyzer_MultiLevelAnalysisReady(ByVal symbol As String, ByVal result25 As Analysis.MarketAnalysisResult, ByVal result100 As Analysis.MarketAnalysisResult)
        If result25 Is Nothing Or result100 Is Nothing Then
            Return
        End If
        'Buy Condition
        If (result25.AtAsk + result25.AboveAsk) > AppSettings.BuySum25AtAskAboveAskMoreThan Then
            If result100.AtAsk > AppSettings.Buy100AtAskMoreThan Then
                'If result25.AtAsk > result100.AtAsk Then
                If result25.AverageTimeGap.Multiply(1.0) < result100.AverageTimeGap.Multiply(1.0) Then
                    'If MarketData(symbol).Change > SpyChange Then
                    'BuyDecision(symbol, Utilities.GetQuantity(AppSettings.QuantityPriceFactor, MarketData(symbol).Last))
                    'End If
                    If result25.AverageVolume > (result100.AverageVolume * 1.0) Then
                        'If ((MarketData(symbol).CallVolume / MarketData(symbol).PutVolume) > (MarketData(symbol).CallOpenInterest / MarketData(symbol).PutOpenInterest)) Or ((MarketData(symbol).PutVolume / MarketData(symbol).CallVolume) < 0.6) Then
                        If MarketData(symbol).PutVolume < MarketData(symbol).CallVolume Then
                            If SpyChange > 0 Then
                                If MarketData(symbol).Change > SpyChange * 1.3 Then
                                    BuyDecision(symbol, Utilities.GetQuantity(AppSettings.QuantityPriceFactor, MarketData(symbol).Last))
                                End If
                            ElseIf SpyChange <= 0 Then
                                If MarketData(symbol).Change > SpyChange / 1.3 Then
                                    BuyDecision(symbol, Utilities.GetQuantity(AppSettings.QuantityPriceFactor, MarketData(symbol).Last))
                                End If
                                'End If
                            End If
                        End If
                    End If
                    'End If
                    'If result25.AveragePrice > result100.AveragePrice Then
                    '    BuyDecision(symbol, Utilities.GetQuantity(AppSettings.QuantityPriceFactor, MarketData(symbol).Last))
                    'End If

                    'Comment out the below BuyDecision if you uncomment the above condition
                    'BuyDecision(symbol, Utilities.GetQuantity(AppSettings.QuantityPriceFactor, MarketData(symbol).Last))
                End If
                'End If
            End If
        End If


        'Sell Condition
        If (result25.AtBid + result25.BelowBid) > AppSettings.SellSum25AtBidBelowBidMoreThan Then
            If result100.AtBid > AppSettings.Sell100AtBidMoreThan Then
                'If result25.AtBid > result100.AtBid Then
                If result25.AverageTimeGap.Multiply(1.0) < result100.AverageTimeGap.Multiply(0.8) Then
                    'If MarketData(symbol).Change > SpyChange Then
                    'SellDecision(symbol, Utilities.GetQuantity(AppSettings.QuantityPriceFactor, MarketData(symbol).Last))
                    'End If

                    If result25.AverageVolume > (result100.AverageVolume * 1.0) Then
                        'If ((MarketData(symbol).PutVolume / MarketData(symbol).CallVolume) > (MarketData(symbol).PutOpenInterest / MarketData(symbol).CallOpenInterest)) Or ((MarketData(symbol).PutVolume / MarketData(symbol).CallVolume) > 0.8) Then
                        If MarketData(symbol).PutVolume > (MarketData(symbol).CallVolume * 0.8) Then
                            If SpyChange > 0 Then
                                If MarketData(symbol).Change < SpyChange / 1.3 Then
                                    SellDecision(symbol, Utilities.GetQuantity(AppSettings.QuantityPriceFactor, MarketData(symbol).Last))
                                End If
                            ElseIf SpyChange <= 0 Then
                                If MarketData(symbol).Change < SpyChange * 1.3 Then
                                    SellDecision(symbol, Utilities.GetQuantity(AppSettings.QuantityPriceFactor, MarketData(symbol).Last))
                                End If
                            End If
                        End If
                        'End If
                    End If

                End If
                'End If
                'If result25.AveragePrice < result100.AveragePrice Then
                '    SellDecision(symbol, Utilities.GetQuantity(AppSettings.QuantityPriceFactor, MarketData(symbol).Last))
                'End If

                'Comment out the below SellDecision if you uncomment the above condition
                'SellDecision(symbol, Utilities.GetQuantity(AppSettings.QuantityPriceFactor, MarketData(symbol).Last))
            End If
            'End If
        End If
    End Sub



    Private Sub TradingEngine_OrderCompleted(ByVal orderId As Integer, ByVal price As Double, ByVal quantity As Integer)
        'If price = -1 Or quantity = -1 Then
        '    SellDictionary.Remove(ReverseSellDictionary(orderId))
        '    ReverseSellDictionary.Remove(orderId)
        '    Return
        'End If

        If PairedSecurityTradeDictionary.ContainsKey(orderId) Then
            PairTradeCompleted(orderId, price, quantity)
        End If

        If ClosePairedSecurityTradeDictionary.ContainsKey(orderId) Then
            ClosePairTradeCompleted(orderId, price, quantity)
        End If

        If ReverseSellDictionary.ContainsKey(orderId) Then
            SellOrderCompleted(orderId, price, quantity)
        End If

        If ReverseBuyDictionary.ContainsKey(orderId) Then
            BuyOrderCompleted(orderId, price, quantity)
        End If

        If CloseSellTradeDictionary.ContainsKey(orderId) Then
            CloseSellOrderCompleted(orderId, price, quantity)
        End If

        If CloseBuyTradeDictionary.ContainsKey(orderId) Then
            CloseBuyOrderCompleted(orderId, price, quantity)
        End If
    End Sub

    Private Sub TradeTrackingEngine_SellWithoutCheck(ByVal symbol As String, ByVal quantity As Integer)
        If SellDictionary.ContainsKey(symbol) Then
            'Throw New Exception("Symbol was pending sell " & symbol)
            AdvancedMockTradingEngine.WriteToFile("Symbol was pending Closing Sell " & symbol)
            Return
        End If
        mutexObj.WaitOne()
        Dim orderId = TradingEngine.Sell(symbol, quantity)
        SellDictionary.Add(symbol, orderId)
        CloseSellTradeDictionary.Add(orderId, symbol)
        'ReverseSellDictionary.Add(orderId, symbol)
        mutexObj.ReleaseMutex()
    End Sub

    Private Sub TradeTrackingEngine_BuyWithoutCheck(ByVal symbol As String, ByVal quantity As Integer)
        If BuyDictionary.ContainsKey(symbol) Then
            'Throw New Exception("Symbol was pending buy " & symbol)
            AdvancedMockTradingEngine.WriteToFile("Symbol was pending Closing Buy " & symbol)
            Return
        End If
        mutexObj.WaitOne()
        Dim orderId = TradingEngine.Buy(symbol, quantity)
        BuyDictionary.Add(symbol, orderId)
        CloseBuyTradeDictionary.Add(orderId, symbol)
        'ReverseBuyDictionary.Add(orderId, symbol)
        mutexObj.ReleaseMutex()
    End Sub
#End Region

<<<<<<< .mine
=======
    Private Class TradePairSecurity
        Private _trade As Trade
        Public Property Trade() As Trade
            Get
                Return _trade
            End Get
            Set(ByVal value As Trade)
                _trade = value
            End Set
        End Property

        Private _pairSecurity As PairSecurity
        Public Property PairSecurity() As PairSecurity
            Get
                Return _pairSecurity
            End Get
            Set(ByVal value As PairSecurity)
                _pairSecurity = value
            End Set
        End Property
    End Class

>>>>>>> .r198
End Class




