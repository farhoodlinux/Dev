﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TradeTrackingEngine
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(TradeTrackingEngine))
        Me.AxTws1 = New AxTWSLib.AxTws()
        Me.dgvTrades = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtMaxOpenOrders = New System.Windows.Forms.TextBox()
        Me.btnMaxOpenOrdersApply = New System.Windows.Forms.Button()
        Me.chkProfitDelta = New System.Windows.Forms.CheckBox()
        Me.Symbol = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Price = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Action = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CurrentPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProfitPercent = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PairProfitPercent = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalProfitPercent = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.AxTws1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvTrades, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'AxTws1
        '
        Me.AxTws1.Enabled = True
        Me.AxTws1.Location = New System.Drawing.Point(143, 182)
        Me.AxTws1.Name = "AxTws1"
        Me.AxTws1.OcxState = CType(resources.GetObject("AxTws1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxTws1.Size = New System.Drawing.Size(100, 50)
        Me.AxTws1.TabIndex = 14
        '
        'dgvTrades
        '
        Me.dgvTrades.AllowUserToAddRows = False
        Me.dgvTrades.AllowUserToDeleteRows = False
        Me.dgvTrades.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvTrades.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Symbol, Me.Price, Me.Action, Me.CurrentPrice, Me.ProfitPercent, Me.PairProfitPercent, Me.TotalProfitPercent})
        Me.dgvTrades.Location = New System.Drawing.Point(12, 12)
        Me.dgvTrades.Name = "dgvTrades"
        Me.dgvTrades.ReadOnly = True
        Me.dgvTrades.RowHeadersVisible = False
        Me.dgvTrades.Size = New System.Drawing.Size(709, 507)
        Me.dgvTrades.TabIndex = 15
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(21, 529)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 13)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Max Open Orders"
        '
        'txtMaxOpenOrders
        '
        Me.txtMaxOpenOrders.Location = New System.Drawing.Point(116, 526)
        Me.txtMaxOpenOrders.Name = "txtMaxOpenOrders"
        Me.txtMaxOpenOrders.Size = New System.Drawing.Size(39, 20)
        Me.txtMaxOpenOrders.TabIndex = 17
        Me.txtMaxOpenOrders.Text = "1"
        '
        'btnMaxOpenOrdersApply
        '
        Me.btnMaxOpenOrdersApply.Location = New System.Drawing.Point(161, 525)
        Me.btnMaxOpenOrdersApply.Name = "btnMaxOpenOrdersApply"
        Me.btnMaxOpenOrdersApply.Size = New System.Drawing.Size(75, 23)
        Me.btnMaxOpenOrdersApply.TabIndex = 18
        Me.btnMaxOpenOrdersApply.Text = "Apply"
        Me.btnMaxOpenOrdersApply.UseVisualStyleBackColor = True
        '
        'chkProfitDelta
        '
        Me.chkProfitDelta.AutoSize = True
        Me.chkProfitDelta.Checked = True
        Me.chkProfitDelta.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkProfitDelta.Location = New System.Drawing.Point(242, 528)
        Me.chkProfitDelta.Name = "chkProfitDelta"
        Me.chkProfitDelta.Size = New System.Drawing.Size(204, 17)
        Me.chkProfitDelta.TabIndex = 19
        Me.chkProfitDelta.Text = "Maximum Profit Delta based decisions"
        Me.chkProfitDelta.UseVisualStyleBackColor = True
        '
        'Symbol
        '
        Me.Symbol.HeaderText = "Symbol"
        Me.Symbol.Name = "Symbol"
        Me.Symbol.ReadOnly = True
        '
        'Price
        '
        Me.Price.HeaderText = "Price"
        Me.Price.Name = "Price"
        Me.Price.ReadOnly = True
        '
        'Action
        '
        Me.Action.HeaderText = "Action"
        Me.Action.Name = "Action"
        Me.Action.ReadOnly = True
        '
        'CurrentPrice
        '
        Me.CurrentPrice.HeaderText = "CurrentPrice"
        Me.CurrentPrice.Name = "CurrentPrice"
        Me.CurrentPrice.ReadOnly = True
        '
        'ProfitPercent
        '
        Me.ProfitPercent.HeaderText = "Profit %"
        Me.ProfitPercent.Name = "ProfitPercent"
        Me.ProfitPercent.ReadOnly = True
        '
        'PairProfitPercent
        '
        Me.PairProfitPercent.HeaderText = "Pair Profit %"
        Me.PairProfitPercent.Name = "PairProfitPercent"
        Me.PairProfitPercent.ReadOnly = True
        '
        'TotalProfitPercent
        '
        Me.TotalProfitPercent.HeaderText = "Total Profit %"
        Me.TotalProfitPercent.Name = "TotalProfitPercent"
        Me.TotalProfitPercent.ReadOnly = True
        '
        'TradeTrackingEngine
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(733, 552)
        Me.Controls.Add(Me.chkProfitDelta)
        Me.Controls.Add(Me.btnMaxOpenOrdersApply)
        Me.Controls.Add(Me.txtMaxOpenOrders)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dgvTrades)
        Me.Controls.Add(Me.AxTws1)
        Me.Name = "TradeTrackingEngine"
        Me.Text = "TradeTrackingEngine"
        CType(Me.AxTws1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvTrades, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents AxTws1 As AxTWSLib.AxTws
    Friend WithEvents dgvTrades As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtMaxOpenOrders As System.Windows.Forms.TextBox
    Friend WithEvents btnMaxOpenOrdersApply As System.Windows.Forms.Button
    Friend WithEvents chkProfitDelta As System.Windows.Forms.CheckBox
    Friend WithEvents Symbol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Price As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Action As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CurrentPrice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProfitPercent As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PairProfitPercent As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TotalProfitPercent As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
