﻿Namespace Components
    Public Interface ITradingEngine
<<<<<<< .mine
        Function Buy(ByVal symbol As String, ByVal quantity As Integer) As Integer
        Function Sell(ByVal symbol As String, ByVal quantity As Integer) As Integer
=======
        'Function Buy(ByVal symbol As String, ByVal quantity As Integer, ByVal pairedSecurity As PairSecurity) As Integer
        'Function Sell(ByVal symbol As String, ByVal quantity As Integer, ByVal pairedSecurity As PairSecurity) As Integer
        Function Buy(ByVal symbol As String, ByVal quantity As Integer) As Integer
        Function Sell(ByVal symbol As String, ByVal quantity As Integer) As Integer
>>>>>>> .r198
        Sub StartEngine()
        Sub StopEngine()
        'Event OrderCompleted(orderId As Integer, price As Double, quantity As Integer, pairedSecurity As PairSecurity)
        Event OrderCompleted(orderId As Integer, price As Double, quantity As Integer)
    End Interface
End Namespace
