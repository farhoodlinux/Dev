﻿Imports System.Configuration
Imports TWSFramework.Data
Imports TWSFramework.Enums
Imports System.Data.OleDb
Imports TWSFramework

Public Class DataLayer
    Private ReadOnly Property ConnectionString() As String
        Get
            Return ConfigurationManager.ConnectionStrings("AccessConnectionString").ConnectionString
        End Get
    End Property

<<<<<<< .mine
=======
#Region "Pair Securities"
    Public Function GetPairSecurities() As List(Of PairSecurity)
        Dim pairSecurities As List(Of PairSecurity) = Nothing
        Dim queryString As String = "SELECT * FROM PairSecurities WHERE RecordDate=@recdate"
        Dim connection = New OleDbConnection(ConnectionString)
        Try
            connection.Open()
            Dim command = New OleDbCommand(queryString, connection)
            'queryString = queryString.Replace("@symbol", "'" & trade.Symbol & "'")

            command.Parameters.AddWithValue("@recdate", DateTime.Now.Date)

            Dim reader As OleDbDataReader = command.ExecuteReader()
            If reader IsNot Nothing And reader.HasRows Then
                pairSecurities = New List(Of PairSecurity)
                Do While reader.Read()
                    Dim trade1 = New PairSecurity()
                    trade1.Symbol = reader("Symbol").ToString()
                    trade1.InitialChange = CDbl(reader("Change"))
                    pairSecurities.Add(trade1)
                Loop
            End If
            reader.Close()
            connection.Close()
        Catch ex As Exception
            connection.Close()
        End Try
        Return pairSecurities
    End Function

    Public Sub SavePairSecurity(security As PairSecurity)
        Dim queryString As String = "INSERT INTO PairSecurities(RecordDate, Symbol, Change) VALUES(@recdate, @symbol, @change)"
        Dim connection = New OleDbConnection(ConnectionString)
        Try
            connection.Open()
            Dim command = New OleDbCommand(queryString, connection)

            command.Parameters.AddWithValue("@recdate", DateTime.Now.Date)
            command.Parameters.AddWithValue("@symbol", security.Symbol)
            command.Parameters.AddWithValue("@change", security.InitialChange)

            command.ExecuteNonQuery()
            connection.Close()
        Catch ex As Exception
            connection.Close()
        End Try
    End Sub
#End Region

>>>>>>> .r198
#Region "Scanner"
    Public Function GetScannersFromDatabase(ByVal onlyValid As Boolean) As List(Of ScannerSubscription)
        Dim scannerDataList As List(Of ScannerSubscription) = Nothing
        Dim queryString As String = "SELECT * FROM Scanner"
        If onlyValid Then
            queryString = queryString & " WHERE Enabled=True"
        End If
        Dim connection = New OleDbConnection(ConnectionString)
        Try
            connection.Open()
            Dim command = New OleDbCommand(queryString, connection)

            Dim reader As OleDbDataReader = command.ExecuteReader()
            If reader IsNot Nothing And reader.HasRows Then
                scannerDataList = New List(Of ScannerSubscription)
                Do While reader.Read()
                    Dim scanner = New ScannerSubscription()
                    scanner.RequestID = CInt(Fix(reader("RequestId")))
                    scanner.ScannerName = reader("ScannerName").ToString()
                    scanner.ScanCode = CType(CInt(Fix(reader("ScanCode"))), ScanCodeType)
                    scanner.Instrument = CType(CInt(Fix(reader("InstrumentType"))), InstrumentType)
                    'scanner.Location = CType(CInt(Fix(reader("LocationType"))), LocationType)
                    scanner.StockTypeFilter = CType(CInt(Fix(reader("StockTypeFilter"))), StockTypeFilter)
                    scanner.PriceAbove = CInt(Fix(reader("MinPrice")))
                    scanner.PriceBelow = CInt(Fix(reader("MaxPrice")))
                    scanner.MarketCapAbove = CInt(Fix(reader("MarketCapAbove")))
                    scanner.MarketCapBelow = CInt(Fix(reader("MarketCapBelow")))
                    '1,3,7,
                    If Not reader("LocationType") Is Nothing And Not String.IsNullOrEmpty(reader("LocationType").ToString()) Then
                        Dim locationTypeInts = reader("LocationType").ToString().Split(",".ToCharArray())
                        scanner.LocationTypes = New List(Of LocationType)
                        For Each locationTypeInt In locationTypeInts
                            scanner.LocationTypes.Add(CType(CInt(locationTypeInt), LocationType))
                        Next
                    End If

                    scanner.Enabled = True
                    scannerDataList.Add(scanner)
                Loop
            End If
            reader.Close()
            connection.Close()
            Return scannerDataList

        Catch ex As Exception
            connection.Close()
            Throw
            'Return Nothing
        End Try


    End Function

    Private Function GetInsertStatement(ByVal ss As ScannerSubscription) As String
        Dim query As String = "INSERT INTO Scanner(ScannerName, ScanCode, InstrumentType, LocationType, StockTypeFilter, MinPrice, MaxPrice, MarketCapAbove, MarketCapBelow, Enabled) VALUES ('{0}',{1},{2},'{3}',{4},{5},{6},{7},{8},{9})"
        Dim locationTypeString = String.Empty
        For Each locationTypeValue In ss.LocationTypes
            locationTypeString = locationTypeString & CInt(locationTypeValue).ToString() & ","
        Next
        locationTypeString = locationTypeString.Trim(",".ToCharArray())
        query = String.Format(query, ss.ScannerName, CInt(ss.ScanCode), CInt(ss.Instrument), locationTypeString, CInt(ss.StockTypeFilter), ss.PriceAbove, ss.PriceBelow, ss.MarketCapAbove, ss.MarketCapBelow, ss.Enabled.ToString())
        Return query
    End Function

    Private Function GetUpdateStatement(ByVal ss As ScannerSubscription) As String
        Dim query As String = "UPDATE Scanner SET ScannerName = '{0}', ScanCode={1}, InstrumentType={2}, LocationType='{3}', StockTypeFilter={4}, MinPrice={5}, MaxPrice={6}, MarketCapAbove={7}, MarketCapBelow={8}, Enabled={9} WHERE RequestId={10}"
        Dim locationTypeString = String.Empty
        For Each locationTypeValue In ss.LocationTypes
            locationTypeString = locationTypeString & CInt(locationTypeValue).ToString() & ","
        Next
        locationTypeString = locationTypeString.Trim(",".ToCharArray())
        query = String.Format(query, ss.ScannerName, CInt(ss.ScanCode), CInt(ss.Instrument), locationTypeString, CInt(ss.StockTypeFilter), ss.PriceAbove, ss.PriceBelow, ss.MarketCapAbove, ss.MarketCapBelow, ss.Enabled.ToString(), ss.RequestID)
        Return query
    End Function

    Public Sub WriteToDatabase(ByVal scannerSubscription As ScannerSubscription)
        Dim queryString As String = If(scannerSubscription.RequestID = 0, GetInsertStatement(scannerSubscription), GetUpdateStatement(scannerSubscription))
        Dim connection = New OleDbConnection(ConnectionString)
        Try
            connection.Open()
            Dim command = New OleDbCommand(queryString, connection)
            command.ExecuteNonQuery()
        Catch ex As Exception
            Throw
        Finally
            connection.Close()
        End Try
    End Sub

    Public Sub DeleteScanner(ByVal requestId As Integer)
        Dim queryString As String = "DELETE FROM Scanner WHERE RequestId=" & requestId.ToString()
        Dim connection = New OleDbConnection(ConnectionString)
        Try
            connection.Open()
            Dim command = New OleDbCommand(queryString, connection)
            command.ExecuteNonQuery()
        Catch ex As Exception

        Finally
            connection.Close()
        End Try
    End Sub
#End Region

<<<<<<< .mine
    Public Sub WriteTrade(ByVal trade As Trade)
        Dim queryString As String = "SELECT * FROM Trades WHERE Symbol=@symbol AND TradeStatus=1"
=======
#Region "Trades"
    Public Function GetOpenTrades() As List(Of Trade)
        Return GetOpenTrades(Nothing)
    End Function

    Private Function GetOpenTrades(ByVal symbol As String) As List(Of Trade)
        Dim queryString As String = "SELECT * FROM Trades WHERE TradeStatus=1"
        If Not String.IsNullOrEmpty(symbol) Then
            queryString = queryString & " AND Symbol=@symbol"
        End If
>>>>>>> .r198
        Dim connection = New OleDbConnection(ConnectionString)
        Dim tradeList As List(Of Trade) = New List(Of Trade)
        Try
            connection.Open()
            Dim command = New OleDbCommand(queryString, connection)
            If Not String.IsNullOrEmpty(symbol) Then
                command.Parameters.AddWithValue("@symbol", symbol)
            End If

<<<<<<< .mine
            command.Parameters.AddWithValue("@symbol", trade.Symbol)

=======
>>>>>>> .r198
            Dim reader As OleDbDataReader = command.ExecuteReader()
            If reader IsNot Nothing And reader.HasRows Then
                Do While reader.Read()
<<<<<<< .mine
                    Dim trade1 = New Trade()
                    trade1.TradeId = CInt(Fix(reader("TradeId")))
                    trade1.Symbol = reader("Symbol").ToString()
                    trade1.TradeType = CType(CInt(Fix(reader("TradeType"))), TradeType)
                    trade1.TradePrice = CDbl(reader("TradePrice"))
                    trade1.TradeVolume = CInt(Fix(reader("TradeVolume")))
                    trade1.TradeTime = CType(reader("TradeTime"), DateTime)
                    trade.TradeStatus = CType(CInt(Fix(reader("TradeStatus"))), TradeStatus)
                    trade1.ClosePrice = CDbl(reader("ClosePrice"))
                    trade1.CloseTime = CType(reader("CloseTime"), DateTime)
                    trade1.ProfitAmount = CDbl(reader("ProfitAmount"))
                    trade1.ProfitPercent = CDbl(reader("ProfitPercent"))
                    tradeList.Add(trade1)
=======
                    Dim trade = New Trade()
                    trade.TradeId = CInt(Fix(reader("TradeId")))
                    trade.Symbol = reader("Symbol").ToString()
                    trade.TradeType = CType(CInt(Fix(reader("TradeType"))), TradeType)
                    trade.TradePrice = CDbl(reader("TradePrice"))
                    trade.TradeVolume = CInt(Fix(reader("TradeVolume")))
                    trade.TradeTime = CType(reader("TradeTime"), DateTime)
                    trade.TradeStatus = CType(CInt(Fix(reader("TradeStatus"))), TradeStatus)
                    trade.ClosePrice = CDbl(reader("ClosePrice"))
                    trade.CloseTime = CType(reader("CloseTime"), DateTime)
                    trade.ProfitAmount = CDbl(reader("ProfitAmount"))
                    trade.ProfitPercent = CDbl(reader("ProfitPercent"))
                    trade.PairedSecuritySymbol = CStr(reader("PairedSecuritySymbol"))
                    trade.PairedSecurityQuantity = CInt(Fix(reader("PairedSecurityQuantity")))
                    trade.PairedSecurityPrice = CDbl(reader("PairedSecurityPrice"))
                    If trade.TradeTime.Date = DateTime.Now.Date Then
                        tradeList.Add(trade)
                    End If
>>>>>>> .r198
                Loop
            End If
            reader.Close()
            connection.Close()
        Catch ex As Exception
            connection.Close()
            Throw
        End Try

<<<<<<< .mine

=======
        Return tradeList
    End Function

    Public Function GetOpenTradeForSymbol(ByVal symbol As String) As Trade
        Dim tradeList = GetOpenTrades(symbol)

>>>>>>> .r198
        If tradeList.Count = 0 Then
            queryString = "INSERT INTO Trades(Symbol, TradeType, TradePrice, TradeVolume, TradeTime, TradeStatus, ClosePrice, CloseTime, ProfitAmount, ProfitPercent) VALUES(@symbol, @tradeType, @tradePrice, @tradeVolume, @tradeTime, 1, @closePrice, @closeTime, @profitAmount, @profitPercent)"
        ElseIf tradeList.Count = 1 Then
<<<<<<< .mine
=======
            Return tradeList(0)
        Else
            Throw New Exception("Database contains mulitple open trades for the symbol " & symbol)
        End If
    End Function

    Public Sub WriteTrade(ByVal trade As Trade)
        Dim queryString As String = "SELECT * FROM Trades WHERE Symbol=@symbol AND TradeStatus=1"
        Dim connection = New OleDbConnection(ConnectionString)

        'Dim t = GetOpenTradeForSymbol(trade.Symbol)

        If trade.TradeId = 0 Then
            queryString = "INSERT INTO Trades(Symbol, TradeType, TradePrice, TradeVolume, TradeTime, TradeStatus, ClosePrice, CloseTime, ProfitAmount, ProfitPercent, PairedSecuritySymbol, PairedSecurityQuantity, PairedSecurityPrice) VALUES(@symbol, @tradeType, @tradePrice, @tradeVolume, @tradeTime, 1, @closePrice, @closeTime, @profitAmount, @profitPercent, @pairedSecuritySymbol, @pairedSecurityQuantity, @pairedSecurityPrice)"
        Else
>>>>>>> .r198
<<<<<<< .mine
            queryString = "UPDATE Trades SET TradeStatus = 2, ClosePrice = @closePrice, CloseTime = @closeTime, ProfitAmount = @profitAmount, ProfitPercent = @profitPercent WHERE TradeId = @tradeId"
            trade.TradeId = tradeList(0).TradeId
            trade.ClosePrice = trade.TradePrice
            trade.CloseTime = trade.TradeTime
            If tradeList(0).TradeType = TradeType.BuyLong Then
                trade.ProfitAmount = trade.ClosePrice - tradeList(0).TradePrice
                trade.ProfitPercent = ((trade.ClosePrice - tradeList(0).TradePrice) / tradeList(0).TradePrice) * 100
            Else
                trade.ProfitAmount = tradeList(0).TradePrice - trade.ClosePrice
                trade.ProfitPercent = ((tradeList(0).TradePrice - trade.ClosePrice) / tradeList(0).TradePrice) * 100
            End If
=======
            queryString = "UPDATE Trades SET TradeStatus = 2, ClosePrice = @closePrice, CloseTime = @closeTime, ProfitAmount = @profitAmount, ProfitPercent = @profitPercent, PairedSecurityClosePrice = @pairedSecurityClosePrice, PairedSecurityProfitAmount = @pairedSecurityProfitAmount, PairedSecurityProfitPercent = @pairedSecurityProfitPercent, TotalProfitAmount = @totalProfitAmount, TotalProfitPercent = @totalProfitPercent WHERE TradeId = @tradeId"

            'trade.TradeId = t.TradeId
            'trade.ClosePrice = trade.TradePrice
            'trade.CloseTime = trade.TradeTime
            'If t.TradeType = TradeType.BuyLong Then
            '    trade.ProfitAmount = trade.ClosePrice - t.TradePrice
            '    trade.ProfitPercent = ((trade.ClosePrice - t.TradePrice) / t.TradePrice) * 100
            'Else
            '    trade.ProfitAmount = t.TradePrice - trade.ClosePrice
            '    trade.ProfitPercent = ((t.TradePrice - trade.ClosePrice) / t.TradePrice) * 100
            'End If
>>>>>>> .r198

        Else
            Throw New Exception("Database contains mulitple open trades for the symbol " & trade.Symbol)
        End If

        Try
            connection.Open()
            If trade.PairedSecuritySymbol Is Nothing Then
                trade.PairedSecuritySymbol = String.Empty
            End If
            queryString = queryString.Replace("@closeTime", "'" & trade.CloseTime.ToString() & "'")
            queryString = queryString.Replace("@tradeTime", "'" & trade.TradeTime.ToString() & "'")
            queryString = queryString.Replace("@closePrice", trade.ClosePrice)
            queryString = queryString.Replace("@profitAmount", trade.ProfitAmount)
            queryString = queryString.Replace("@profitPercent", trade.ProfitPercent)
            queryString = queryString.Replace("@symbol", "'" & trade.Symbol & "'")
            queryString = queryString.Replace("@tradeType", CInt(trade.TradeType))
            queryString = queryString.Replace("@tradePrice", trade.TradePrice)
            queryString = queryString.Replace("@tradeVolume", trade.TradeVolume)
            queryString = queryString.Replace("@pairedSecuritySymbol", "'" & trade.PairedSecuritySymbol & "'")
            queryString = queryString.Replace("@pairedSecurityQuantity", trade.PairedSecurityQuantity)
            queryString = queryString.Replace("@pairedSecurityPrice", trade.PairedSecurityPrice)
            queryString = queryString.Replace("@pairedSecurityClosePrice", trade.PairedSecurityClosePrice)
            queryString = queryString.Replace("@pairedSecurityProfitAmount", trade.PairedSecurityProfitAmount)
            queryString = queryString.Replace("@pairedSecurityProfitPercent", trade.PairedSecurityProfitPercent)
            queryString = queryString.Replace("@totalProfitAmount", trade.TotalProfitAmount)
            queryString = queryString.Replace("@totalProfitPercent", trade.TotalProfitPercent)
            queryString = queryString.Replace("@tradeId", trade.TradeId)

            Dim command = New OleDbCommand(queryString, connection)

            command.ExecuteNonQuery()
        Catch ex As Exception
            Throw
        Finally
            connection.Close()
        End Try
    End Sub
#End Region

#Region "App Settings"
    Private _appSettings As AppSettings

    Public Function GetAppSettings(ByVal reload As Boolean) As AppSettings
        If _appSettings Is Nothing Or reload = True Then
            _appSettings = New AppSettings()
            Dim queryString As String = "SELECT * FROM AppSettings"

            Dim connection = New OleDbConnection(ConnectionString)
            Try
                connection.Open()
                Dim command = New OleDbCommand(queryString, connection)

                Dim reader As OleDbDataReader = command.ExecuteReader()
                If reader IsNot Nothing And reader.HasRows Then
                    Do While reader.Read()
                        Select Case CStr(reader("SettingKey"))
                            Case "BuyLongCloseProfitAbove"
                                _appSettings.BuyLongCloseProfitAbove = Double.Parse(reader("SettingValue"))
                            Case "BuyLongCloseProfitBelow"
                                _appSettings.BuyLongCloseProfitBelow = Double.Parse(reader("SettingValue"))
                            Case "BuyLongDeltaCloseProfitBelow"
                                _appSettings.BuyLongDeltaCloseProfitBelow = Double.Parse(reader("SettingValue"))
                            Case "SellShortCloseProfitAbove"
                                _appSettings.SellShortCloseProfitAbove = Double.Parse(reader("SettingValue"))
                            Case "SellShortCloseProfitBelow"
                                _appSettings.SellShortCloseProfitBelow = Double.Parse(reader("SettingValue"))
                            Case "SellShortDeltaCloseProfitBelow"
                                _appSettings.SellShortDeltaCloseProfitBelow = Double.Parse(reader("SettingValue"))
                            Case "TradeCloseTime"
                                _appSettings.TradeCloseTime = DateTime.Parse(reader("SettingValue"))
                            Case "APIHostAddress"
                                _appSettings.APIHostAddress = CStr(reader("SettingValue"))
                            Case "APIPort"
                                _appSettings.APIPort = Integer.Parse(reader("SettingValue"))
                            Case "ScannerMinimumCommon"
                                _appSettings.ScannerMinimumCommon = Integer.Parse(reader("SettingValue"))
                            Case "ScannerNumberOfRows"
                                _appSettings.ScannerNumberOfRows = Integer.Parse(reader("SettingValue"))
                            Case "SnapshotGapMs"
                                _appSettings.SnapshotGapMs = Integer.Parse(reader("SettingValue"))
                            Case "Buy100AtAskMoreThan"
                                _appSettings.Buy100AtAskMoreThan = Double.Parse(reader("SettingValue"))
                            Case "BuySum25AtAskAboveAskMoreThan"
                                _appSettings.BuySum25AtAskAboveAskMoreThan = Double.Parse(reader("SettingValue"))
                            Case "Sell100AtBidMoreThan"
                                _appSettings.Sell100AtBidMoreThan = Double.Parse(reader("SettingValue"))
                            Case "SellSum25AtBidBelowBidMoreThan"
                                _appSettings.SellSum25AtBidBelowBidMoreThan = Double.Parse(reader("SettingValue"))
                            Case "QuantityPriceFactor"
                                _appSettings.QuantityPriceFactor = Double.Parse(reader("SettingValue"))
                            Case "SecuritySpecificDeltaProfitThreshold"
                                _appSettings.SecuritySpecificDeltaProfitThreshold = Double.Parse(reader("SettingValue"))
                            Case "SecuritySpecificDeltaProfitValue"
                                _appSettings.SecuritySpecificDeltaProfitValue = Double.Parse(reader("SettingValue"))
                        End Select
                    Loop
                End If
                reader.Close()
                connection.Close()

            Catch ex As Exception
                connection.Close()
                Throw
            End Try
        End If
        Return _appSettings
    End Function
#End Region

End Class
