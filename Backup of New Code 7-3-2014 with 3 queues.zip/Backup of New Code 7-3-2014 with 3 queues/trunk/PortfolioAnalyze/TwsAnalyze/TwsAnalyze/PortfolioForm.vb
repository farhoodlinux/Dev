﻿
Imports TwsAnalyzeFrameWork
Public Class PortfolioForm


#Region "Form Properties"

    Private ReadOnly Property APIHostAddress As String
        Get
            Return ""
        End Get
    End Property

    Private ReadOnly Property APIPort As Integer
        Get
            Return 7496
        End Get
    End Property

    Private ReadOnly Property APIClientID As Integer
        Get
            Return 4
        End Get
    End Property


#End Region

    Private lastMarketTickerId As Integer

    Private _marketRequestDataBuffer As Dictionary(Of Integer, TWSLib.IContract)
    Public Property MarketRequestDataBuffer As Dictionary(Of Integer, TWSLib.IContract)

        Get
            Return _marketRequestDataBuffer
        End Get
        Set(ByVal value As Dictionary(Of Integer, TWSLib.IContract))
            _marketRequestDataBuffer = value
        End Set
    End Property

    Private _marketDataBuffer As Dictionary(Of String, TWSLib.IContract)
    Public Property MarketDataBuffer As Dictionary(Of String, TWSLib.IContract)

        Get
            Return _marketDataBuffer
        End Get
        Set(ByVal value As Dictionary(Of String, TWSLib.IContract))
            _marketDataBuffer = value
        End Set
    End Property

    Private _portfolioBuffer As Dictionary(Of String, PortfolioUpdateResponse)

    Public Property PortfolioBuffer As Dictionary(Of String, PortfolioUpdateResponse)

        Get
            Return _portfolioBuffer
        End Get


        Set(ByVal value As Dictionary(Of String, PortfolioUpdateResponse))

            _portfolioBuffer = value

        End Set

    End Property



    Private Sub BtnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnStart.Click

        AxTws1.connect(APIHostAddress, APIPort, APIClientID)

        Dim updateRequest As New AccountUpdateRequest
        PortfolioBuffer = New Dictionary(Of String, PortfolioUpdateResponse)
        MarketRequestDataBuffer = New Dictionary(Of Integer, TWSLib.IContract)
        MarketDataBuffer = New Dictionary(Of String, TWSLib.IContract)

        updateRequest.AccountSubscribe = True
        updateRequest.AccountNumber = "U63389"
        SubscribeToUpdates(updateRequest)


    End Sub

    Private Sub SubscribeToUpdates(ByVal updateRequest As AccountUpdateRequest)

        Dim apiRequest = updateRequest.RevertToApiObject
        AxTws1.reqAccountUpdates(apiRequest.Subscribe, apiRequest.AcctCode)

    End Sub

    Private Sub SubscribeToMarketUpdates(ByVal updateRequest As MarketDataRequest)
        'AxTws1.reqMktData(updateRequest.TickerId, updateRequest.Contract.localSymbol, updateRequest.Contract.secType, updateRequest.Contract.expiry, updateRequest.Contract.strike, updateRequest.Contract.right, updateRequest.Contract.multiplier, updateRequest.Contract.exchange, updateRequest.Contract.primaryExchange, updateRequest.Contract.currency, updateRequest.GenericTicks, updateRequest.SnapShot)

        AxTws1.reqMktDataEx(updateRequest.TickerId, updateRequest.Contract, updateRequest.GenericTicks, updateRequest.SnapShot)

    End Sub

    Private Sub BtnStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnStop.Click

        AxTws1.disconnect()

    End Sub

    Private Sub AxTws1_errMsg(ByVal sender As System.Object, ByVal e As AxTWSLib._DTwsEvents_errMsgEvent) Handles AxTws1.errMsg
        TxtMessages.Text = TxtMessages.Text & e.errorCode & " " & e.errorMsg & vbCrLf
        TxtMessages.ScrollToCaret()
    End Sub

    Private Sub AxTws1_updatePortfolioEx(ByVal sender As System.Object, ByVal e As AxTWSLib._DTwsEvents_updatePortfolioExEvent) Handles AxTws1.updatePortfolioEx

        Dim objResponse As New PortfolioUpdateResponse
        objResponse.GetFromApiObject(e)

        If PortfolioBuffer.ContainsKey(objResponse.LocalSymbol) Then

            PortfolioBuffer(objResponse.LocalSymbol) = objResponse

        Else

            PortfolioBuffer.Add(objResponse.LocalSymbol, objResponse)

        End If

        If Not MarketDataBuffer.ContainsKey(objResponse.LocalSymbol) Then

            Dim marketDataRequestObject As New MarketDataRequest
            lastMarketTickerId = lastMarketTickerId + 1
            marketDataRequestObject.Contract = e.contract
            marketDataRequestObject.Contract.exchange = "SMART"
            'marketDataRequestObject.GenericTicks = "100,101,104,106,165,221,225,236"
            marketDataRequestObject.GenericTicks = "100,101,104,105,106,107,165,221,225,233,236,258,293,294,295,318"

            marketDataRequestObject.SnapShot = False
            marketDataRequestObject.TickerId = lastMarketTickerId

            MarketRequestDataBuffer.Add(lastMarketTickerId, marketDataRequestObject.Contract)
            MarketDataBuffer.Add(objResponse.LocalSymbol, marketDataRequestObject.Contract)

            SubscribeToMarketUpdates(marketDataRequestObject)

        End If


        Dim isFound = False
        For Each row As DataGridViewRow In dgvPortfolio.Rows

            If row.Cells("Description").Value.ToString() = objResponse.LocalSymbol Then
                row.Cells("Strike").Value = objResponse.Strike
                row.Cells("Position").Value = objResponse.Position

                'row.Cells("Price").Value = e.marketPrice
                isFound = True
            End If


        Next

        If Not isFound Then

            dgvPortfolio.Rows.Add(objResponse.LocalSymbol, "", "", objResponse.Strike, objResponse.Position, 0, " ")

        End If

    End Sub

    Private Sub PortfolioForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub AxTws1_tickOptionComputation(ByVal sender As System.Object, ByVal e As AxTWSLib._DTwsEvents_tickOptionComputationEvent) Handles AxTws1.tickOptionComputation

        If Not MarketRequestDataBuffer.ContainsKey(e.id) Then
            AxTws1.cancelMktData(e.id)
            Return
        End If
        Dim tickOptionData As New TickOptionComputationData
        tickOptionData.LoadFromObject(e)

        If Not tickOptionData.TickType = OptionTickType.Last Then
            Return
        End If

        Dim contract As TWSLib.IContract
        contract = MarketRequestDataBuffer(e.id)

        For Each row As DataGridViewRow In dgvPortfolio.Rows
            If row.Cells("Description").Value.ToString() = contract.localSymbol Then
                row.Cells("Price").Value = tickOptionData.OptionPrice.ToString("F2")
                'If tickOptionData.ImpVol <= 1 Then

                row.Cells("ImpVol").Value = tickOptionData.ImpVol.ToString("F2")
                row.Cells("Delta").Value = tickOptionData.Delta.ToString("F2")
                row.Cells("Gamma").Value = tickOptionData.Gamma.ToString("F2")

                'End If

                'If tickOptionData.Vega <= 1 Then
                row.Cells("Vega").Value = tickOptionData.Vega.ToString("F2")
                'End If
                'If tickOptionData.Theta <= 1 Then
                row.Cells("Theta").Value = tickOptionData.Theta.ToString("F2")
                ' End If

                row.Cells("UndPrice").Value = tickOptionData.UndPrice.ToString("F2")

            End If
        Next


    End Sub


    Private Sub AxTws1_tickPrice(ByVal sender As Object, ByVal e As AxTWSLib._DTwsEvents_tickPriceEvent) Handles AxTws1.tickPrice

        If Not MarketRequestDataBuffer.ContainsKey(e.id) Then
            AxTws1.cancelMktData(e.id)
            Return
        End If

        Dim tickData As New TickPriceData()
        tickData.LoadDataFromObject(e)

        If Not tickData.TickType = PriceTickType.Last Then
            Return
        End If

        'Dim contract = MarketRequestDataBuffer(e.id)
        Dim contract As TWSLib.IContract
        contract = MarketRequestDataBuffer(e.id)

        For Each row As DataGridViewRow In dgvPortfolio.Rows
            If row.Cells("Description").Value.ToString() = contract.localSymbol Then

                row.Cells("Price").Value = tickData.Price


            End If
        Next

    End Sub

    Private Sub dgvPortfolio_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvPortfolio.CellContentClick

    End Sub
End Class
